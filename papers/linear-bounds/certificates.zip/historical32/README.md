# Pełna półoś dla m=2r i 1 ≤ r ≤ 32

Niech $W_p(\Psi_m;t)=\det[\Psi_m^{(i+j)}(t)]_{0\le i,j<p}$, gdzie $\Psi_m$ jest $m$-krotną całką ogonową pełnego jądra theta. Potwierdzamy
$$
(-1)^{p(p-1)/2}W_p(\Psi_{2r};t)>0
\qquad(1\le p\le r\le32,\ t\ge0).
$$

Trzy zakresy pokrywają całą półoś. Dotychczasowe tabele obejmują $0\le t\le1/4$. Nowa tabela stosuje zmienną $X=\pi e^{4t}$ i dla każdego $2\le r\le32$ obejmuje $8\le X\le76(r-1)$. Początek nowej tabeli nachodzi na poprzedni zakres, ponieważ $8<\pi e$. Dowód analityczny w pliku ogon.md obejmuje $X\ge76(r-1)$. Przy $r=1$ wystarcza dodatniość każdego składnika jądra dla $t\ge0$.

Z Lematu 2.1 Nuttalla wynika regularność znakowa $RR_r$ dla jądra $\Psi_{2r}(u+v)$ oraz górna granica $m(r)\le2r$ w tym skończonym zakresie.

W certyfikacie w zmiennej $X$ są 8615 komórki. Dla $r=32$ użyto 515 komórek. Największa zapisana górna granica normy wynosi 0.874996571. Końce są wymierne. Sprawdzono dokładną zgodność granic sąsiednich komórek i pokrycie wymaganego przedziału osobno dla każdego rzędu.

W czterech punktach $X=8,64,512,2336$ sprawdzono momenty na 35 cyfr drugim rachunkiem, stosując kwadraturę Gaussa. W tych punktach dla $r=32$ bezpośredni wyznacznik potwierdził znak dla $p=1,2,8,16,24,32$. W ostatnim bloku rzędu 32 niezależne przebiegi w wersjach Python i GMP dały dokładnie identyczne komórki i normy.

## Macierz i zmienna x

Dla $j\ge0$ definiujemy
$$
 F_j(t)=\int_0^\infty \frac{s^j}{j!}\Phi(t+s)\,ds,
 \qquad F_{-1}(t)=\Phi(t).
$$
Wtedy $F'_j=-F_{j-1}$ dla $j\ge0$. Dla danego dodatniego punktu odniesienia $A$ przyjmujemy
$$
 t(X)=\tfrac14\log(X/\pi),\qquad
 G_j^A(X)=\frac{e^{X-t(X)}(4A)^{j+1}}{A^2}F_j(t(X)).
$$
Dla $m=2r$ i ustalonego $A$ macierz $[G_{m-1-i-j}^A(X)]_{0\le i,j<r}$ jest dodatnim skalowaniem i kongruencją diagonalną macierzy wrońskianu po usunięciu znaków $(-1)^{i+j}$. Dlatego wszystkie wiodące bloki odpowiadają kolejno rzędom $p\le r$. W każdej komórce używamy $A$ równego jej środkowi. Przy większych wartościach $X$ stosujemy dodatkową dodatnią kongruencję opisaną niżej. Wyliczona dolna baza trójkątna redukuje macierz w środku do przybliżonej przekątnej $J=\operatorname{diag}(1,-1,1,-1,\ldots)$. Współczynniki bazy są następnie ustalane jako dokładne liczby dyadyczne. Jeśli granica maksymalnej bezwzględnej normy wierszowej odchylenia od $J$ jest mniejsza od 1 na całej komórce, to każdy początkowy blok jest nieosobliwy i zachowuje znak odpowiadającego bloku $J$. Ten test używa iloczynów całkowitoliczbowych z jawną kontrolą zaokrągleń.

## Moment w punkcie odniesienia

Dla $u=A(e^{4s}-1)$ mamy
$$
 G_j^A(A)=\int_0^\infty
 \frac{[A\log(1+u/A)]^j}{j!}
 \frac{\sum_{n\ge1}n^2(1+u/A)\,[2n^2(1+u/A)-3/A]\,
                    e^{-n^2 u-(n^2-1)A}}
 {(1+u/A)^{3/4}}\,du.
$$
Przy tekstowym opisie rekurencji niżej niech $q=B/A$, gdzie $B$ jest kolejnym węzłem siatki. Rozdzielenie pierwotnej całki w punkcie $t(B)$ daje dokładnie
$$
 G_j^A(A)=G_{j,[A,B]}+
 e^{A-B}q^{5/4}\sum_{k=0}^j q^{-k}\frac{[A\log q]^{j-k}}{(j-k)!}G_k^B(B).
$$
Wszystkie współczynniki są dodatnie. Startujemy z przedziałem $[0,2^{90}]$ w $B=4096$ i przechodzimy od prawej do lewej. Ogon w $B=4096$ jest zachowany jako osobny błąd przedziałowy przez powyższą rekurencję.

Całki częściowe na $[A,B]$ liczymy dodatnią kwadraturą Clenshawa–Curtisa stopnia 600 w zmiennej $u$ na $[0,d]$, $d=B-A\le\min(32,A/16)$. Dla dysku $|u-d/2|\le2d$ mamy $|u|\le80$, $|u/A|\le 5/32$, $\Re u\ge-48$, $A+\Re u\ge(29/32)A$ i $|A\log(1+u/A)|<95$. Z oszacowania szeregu theta, $|y|^j/j!\le e^{|y|}$, i $\sum_{n\ge1}n^4 e^{-(n^2-1)(A+\Re u)}<2$ wynika granica $2^{220}$ na moduł całkowanej funkcji. Na panelu rzeczywistym iloraz odległości od środka do promienia dysku wynosi $1/4$. Z oszacowania reszty Taylora, dokładności kwadratury na wielomianach i dodatnich wag otrzymujemy błąd mniejszy niż $2d\,2^{220}4^{-601}/(1-1/4)$. Na osi rzeczywistej pominięte składniki theta zaczynają się od indeksu $n$ z $A(n^2-1)>1000$. Suma ich modułów, z czynnikiem momentu, jest całkowalna z granicą mniejszą od $2^{-900}$. Wystarcza $A\log(1+u/A)\le u$, $1+u/A\le1+u$, $n\ge2$ i
$$
\int_0^\infty (1+u)^2 e^{-n^2u}u^j/j!\,du
\le 1+2(j+1)+(j+1)(j+2),\quad j\le63.
$$
Dla pierwszego pominiętego indeksu $n\le13$, a od niego iloraz kolejnych $n^4e^{-(n^2-1)A}$ jest mniejszy od $1/2$. Wspólna granica obu błędów, przyjęta przez program, to $2^{-870}$. Liczby używane w kwadraturze są przedziałowe, a sumy węzłów i potęgi są zaokrąglane na zewnątrz.

## Zakres zespolony i rekurencja Taylora

Dla $z=(X-A)/A$ dysk $|z|\le1/2$ leży w prawej półpłaszczyźnie $X$. Wzór całkowy zachowuje postać powyżej ze zmianą wielomianu na $n^2(1+u/A)(1+z)[2n^2(1+u/A)(1+z)-3/A]$ i wykładnika na $-(1+z)[n^2u+(n^2-1)A]$. Jego moduł dla $0\le j\le63$ jest ograniczony przez
$$
20\int_0^\infty(1+u)^2\frac{u^j}{j!}e^{-u/2}\,du <2^{90}
$$
dla wszystkich $A\ge8$. Ta majoranta wystarcza również dla początkowego przedziału na brzegu $A=4096$. Wymiana sumowania i całkowania oraz analityczność wynikają z dominacji wykładniczej.

W zmiennej $z$ mamy dokładne równanie
$$
 (1+z)\frac{dG_j^A}{dz}
 =[A(1+z)-1/4]G_j^A-A G_{j-1}^A .
$$
Zatem dla współczynników Taylora otrzymujemy
$$
(k+1)c_{j,k+1}=(A-1/4-k)c_{j,k}+A c_{j,k-1}-A c_{j-1,k}.
$$
Dla $j=0$ używamy jawnego szeregu $G_{-1}^A(A(1+z))$. Każdy jego składnik jest wielomianem kwadratowym pomnożonym przez $e^{-A(n^2-1)(1+z)}$. Pierwszy pominięty indeks $N$ spełnia $A(N^2-1)>1804$ i $N\le16$. Na $|z|\le1/2$ moduł ogona jest najwyżej $24\cdot16^4e^{-902}<2^{-1120}$. Do współczynnika rzędu $k$ doliczamy na tej podstawie $2^{k-1120}$. Przesunięcie do środka komórki wykonujemy przedziałową metodą Hornera z szeregu stopnia 285. Błąd Cauchy’ego dla $|z|\le1/16$ obliczany jest dokładnie ze wzoru $2^{90}(2|z|)^{286}/(1-2|z|)$. Następnie zmieniamy skalę $A$ na środek i liczymy nowy szereg tą samą rekurencją.

Na blokach zaczynających się od $X≥128$ dodatkowo przeskalowujemy wpisy przez $Q_j=(1+z)^{j-1}G_j^A$. Jest to dodatni czynnik wspólny i kongruencja z przekątną $(1+z)^{-i}$, więc zachowuje znaki wszystkich wiodących wyznaczników. W środku komórki skala jest równa 1. Obliczamy $Q_1=G_1^A$ oraz pochodne $G_0^A$ jak wyżej. Dla $j≥2$ rekurencja ma postać
$$
(k+1)q_{j,k+1}=(A+j-5/4-k)q_{j,k}
                 +Aq_{j,k-1}-Aq_{j-1,k}-Aq_{j-1,k-1}.
$$
Wynika to z równania dla $G_j^A$ i różniczkowania czynnika $(1+z)^{j-1}$. W oszacowaniu reszty Cauchy’ego zastępujemy $2^{90}$ przez $2^{90+2r}$, gdyż $|(1+z)^{j-1}|≤(3/2)^{j-1}<2^{2r}$ dla używanych indeksów.

Dla komórki o promieniu względnym $\rho$ i obcięciu szeregu po stopniu $d$ błąd po kongruencji jest co najwyżej
$$
 r\|U\|_\infty\|U^\top\|_\infty 2^{90}
 \frac{(2\rho)^{d+1}}{1-2\rho}.
$$
Osobno sumujemy certyfikowane normy każdego zachowanego współczynnika. Jeśli suma wraz z resztą przekracza $7/8$, dzielimy komórkę na pół i powtarzamy test.

## Odtworzenie

    python luka.py --max-rank 32 --workers 8 --csv odtworzone.csv

Użyto Pythona 3.12 i mpmath 1.3. Można opcjonalnie skompilować rozszerzenie GMP i dodać flagę --gmp. Rozszerzenie wykonuje te same całkowitoliczbowe iloczyny macierzy i te same zaokrąglenia co wersja Python. Bez flagi potrzebny jest wyłącznie mpmath.

    gcc -O3 -shared -fPIC $(python3-config --includes) fastnorm.c -lgmp -o "fastnorm$(python3-config --extension-suffix)"
    python luka.py --gmp --max-rank 32 --workers 8 --csv odtworzone.csv

 W nowej tabeli końce $X$ są dokładnymi ułamkami, a granica normy jest pomnożona przez $10^9$ i zaokrąglona w górę. W poprzednich tabelach współrzędną jest $t$ i norma jest zapisana w skali $10^8$. Plik przedzial.py zachowuje poprzedni weryfikator dla $t\le1/4$.

[J. Nuttall, Wronskians, Cumulants, and the Riemann Hypothesis, Lemma 2.1](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf)
