# Podpisane wrońskiany pełnego jądra Nuttalla przy m=2r

Niech `p` oznacza rząd wrońskianu i `m` liczbę całkowań. Każdy wynik dla danego `r` obejmuje wszystkie `1 <= p <= r` przy ustalonym poziomie `m=2r`.

Analityczna granica dla dużego $t$ oraz jej dowód znajdują się w pliku ogon.md.
Dla odcinka $[0,1/16]$ dołączono tabelę poprzedniego przebiegu. Nowy przebieg certyfikuje odcinek $[1/16,1/4]$.

## Wyniki

- Pełne jądro theta ma dodatni podpisany wrońskian dla wszystkich 528 par $1\le p\le r\le32$ przy $m=2r$, na całym przedziale $0\le t\le 1/4$.
- Nowy przebieg używa 1845 komórek na $[1/16,1/4]$. Dla rzędu 32 jest ich 316. Najwyższa zapisana granica normy wynosi 0.74985709. Poprzednia tabela wypełnia $[0,1/16]$ w 459 komórkach.
- Dodatkowy rachunek w punkcie $t=1/4$ z niezależną kwadraturą Gaussa i bezpośrednim wyznacznikiem potwierdził znak przy $r=32$ dla $p=1,2,8,16,24,32$.
- Dowód analityczny obejmuje dowolny $p\ge2$ i $L=m-p\ge p$, gdy $\pi e^{4t}\ge38L$. Przy $m=2r$ wspólna granica dla wszystkich $p\le r$ wynosi $\pi e^{4t}\ge76(r-1)$ dla $r\ge2$. Dla $p=1$ dodatniość wynika z wyrazu szeregu theta.

## Redukcja do jednej macierzy

Niech
$$
 F_j(t)=\int_0^\infty\frac{s^j}{j!}\Phi(t+s)\,ds \quad(j\ge0),
 \qquad F_{-k-1}=(-1)^k\Phi^{(k)}\quad(k\ge0).
$$
Całkowanie przez części daje $F'_j=-F_{j-1}$ również dla $j=0$. Ponieważ $\Psi_m=F_{m-1}$, po usunięciu czynników $(-1)^{i+j}$ z wierszy i kolumn wrońskian rzędu $p$ jest wyznacznikiem pierwszego bloku rozmiaru $p$ macierzy Hankla
$$
 A_{ij}(t)=F_{m-1-i-j}(t),\qquad 0\le i,j<r.
$$
Dla każdego przedziału program proponuje dolną macierz trójkątną $U$ o dodatniej przekątnej. Przedtem skaluje $A$ przez dodatnią liczbę $(m-1)!$ i kongruencję diagonalną o przekątnej $c^{-i}$, gdzie $c=2^{1+\lfloor\log_2 r\rfloor}$. Mianem $A_*$ oznaczamy tak przeskalowaną macierz. Współczynniki macierzy $U$ są następnie ustalane jako dokładne liczby dwójkowe. Program weryfikuje jednostajnie na danym przedziale
$$
 \|U A_*(t)U^\top-J\|_\infty<1,\qquad J=\operatorname{diag}(1,-1,1,-1,\ldots).
$$
Norma oznacza największą bezwzględną sumę wiersza. Każdy początkowy blok spełnia to samo oszacowanie. Jego odcinek do odpowiedniego bloku $J$ składa się z macierzy odwracalnych. Znak wyznacznika bloku rzędu $p$ jest więc $(-1)^{p(p-1)/2}$. Trójkątność $U$ sprawia, że każda z tych kongruencji zachowuje wyznacznik odpowiedniego bloku z dokładnością do dodatniego czynnika.

## Przedziały momentów i pochodnych

Plik theta.py pochodzi z poprzedniego certyfikatu pełnego jądra. Funkcja raw_moments ujmuje pełne momenty w zerze. Na $[0,2]$ stosuje złożoną kwadraturę Clenshawa–Curtisa stopnia 648 na 32 panelach. Uwzględnia $n\le24$ w kwadraturze i dolicza oba ogony, w zmiennej $s$ i w indeksie theta. Wspólny promień błędu kwadratury dla surowego momentu stopnia $j$ wynosi co najwyżej $24\cdot46000\,3^j/8^{649}$. Na każdym zespolonym dysku promienia $1/4$ wokół środka panelu mamy $|s|<3$, a pojedynczy składnik theta ma moduł poniżej $10^4$. Z twierdzenia Cauchy'ego, stosunku promieni $1/8$ i dodatnich wag wynika podany błąd. Na rzeczywistym $s\in[0,2]$ ogon $n\ge25$ ogranicza szereg geometryczny z pierwszym wyrazem proporcjonalnym do $25^4 e^{-625\pi}$. Na $s\ge2$ suma składników jest co najwyżej $2\exp(-\pi e^{4s}/2)$. Każdy z tych dwóch ogonów dla $j\le319$ jest mniejszy niż $3^j2^{-1960}$. Do drugiego oszacowania wystarczy $(s/3)^j\le e^{171s}$ i styczna do $e^{4s}$ w punkcie 2. Wszystkie zaokrąglenia są skierowane na zewnątrz.

Dla zespolonego $w$ w dysku promienia $1/4$ wokół dowolnej rzeczywistej liczby $a\in[0,1/4]$ mamy
$$
 \Re(\pi n^2 e^{4w})\ge\pi n^2/e>1.15n^2.
$$
Aby to sprawdzić, weźmy $x+iy=4(w-a)$ i rozważmy $e^{-\sqrt{1-y^2}}\cos y$. Jego logarytm dla $0\le y\le1$ jest niemalejący, gdyż $\tan y\le y/\sqrt{1-y^2}$. Wartość przy $y=0$ to $e^{-1}$. Jeżeli $u=e^{4a}$, to $|\pi n^2e^{4w}|<9u n^2$ i $|e^w|<2$. Tak więc ogon $n\ge25$ funkcji $\Phi(w)$ jest ograniczony przez
$$
\sum_{n\ge25}1000n^4 u^2e^{-1.15u n^2}
\le\sum_{n\ge25}1000n^4 e^{-1.15n^2}<2^{-1000},
$$
gdyż $u\ge1$, a $u^2e^{-1.15u n^2}$ maleje na tej dziedzinie. Iloraz kolejnych wyrazów tej majoranty jest mniejszy od $1/2$ i wystarczy podwoić pierwszy wyraz. Zatem błąd obcięcia pochodnej rzędu $k$ jest co najwyżej $2^{-1000} k!4^k$. Współczynniki wielomianów opisujących pochodne wyznaczamy całkowitoliczbowo z rekurencji $P_0(X)=2X^2-3X$, $P_{k+1}=(1-4X)P_k+4X P'_k$.

Dla $j\ge0$ funkcja $F_j(w)$ na każdym takim dysku jest holomorficzna i ma moduł mniejszy niż $10^8$. Istotnie $s^j/j!\le e^s$. Dla $0\le s\le 2$, z $\Re X\ge |X|/2$ i $\Re(w+s)\le5/2$ wynika ograniczenie $10^4$ na każdy z pierwszych 24 składników, a suma pozostałych modułów jest poniżej 1. Dla $s\ge2$ mamy $|X|\ge \pi n^2 e^{4s-1}$. Czynnik wielomianowy z $|e^{w+s}|$ jest wtedy najwyżej $e^{|X|/4}$. Suma jest ograniczona przez $2e^{-\pi e^{4s-1}/4}$, co wraz z $e^s$ ma całkę od 2 mniejszą niż 1. Te dominacje uzasadniają przedłużenie holomorficzne przez całkowanie. W szczególności twierdzenie Cauchy'ego daje $|[h^k]F_j(a+h)|\le 10^8 4^k$.

Przedziałowe szeregi Taylora stopnia 380 budujemy kolejno w punktach $0,1/16,1/8,3/16$. W każdym z nich pochodne $\Phi$ obliczamy od nowa. Dodatnie indeksy $F_j$ w następnym punkcie wyliczamy przez podstawienie przesunięcia $1/16$ do szeregu z poprzedniego punktu, zachowując całe przedziały wejściowe i doliczając błąd Cauchy’ego $10^8(1/4)^{381}/(1-1/4)$. Środek każdej komórki otrzymuje wartości $F_j$ z jej lewego punktu odniesienia odległego o co najwyżej $1/16$. Wewnątrz każdej komórki o promieniu $\rho$ wartości $F_j$ i pochodne $\Phi$ w środku wyznaczają współczynniki macierzy względem $v=(t-a)/\rho\in[-1,1]$. Norma błędu po kongruencji jest ograniczona przez sumę norm współczynników i oszacowanie Cauchy'ego reszty. Po stopniu $d$ ta reszta jest co najwyżej
$$
r\|U\|_\infty\|U^\top\|_\infty (m-1)!10^8
\frac{(4\rho)^{d+1}}{1-4\rho}.
$$
Każdy iloczyn korzysta z dokładnych liczb całkowitych i jawnych błędów dwóch zaokrągleń. Przedział dzieli się na połowy, jeżeli granica normy nie jest wystarczająca. W punkcie $t=0$ wystarczą same momenty i kongruencja.

## Odtworzenie

    python przedzial.py --max-rank 32 --degree 60 --workers 8 --start 1/16 --end 1/4 --csv nowy_przedzial.csv
    python przedzial.py --max-rank 32 --degree 60 --workers 8 --start 0 --end 1/16 --csv poprzedni_przedzial.csv

Zależności to Python 3.10+ oraz mpmath. Użyto Pythona 3.12.14 i mpmath 1.3.0. W tabeli przedziałowej końce są dokładnymi ułamkami, a ostatnia kolumna stanowi górną granicę normy pomnożoną przez $10^8$ i zaokrągloną w górę.

[J. Nuttall, Wronskians, Cumulants, and the Riemann Hypothesis, lemat 2.1](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf)
