"""Verified sector coefficients and full theta determinant for m=2r, p=r, t=0.
Run with Python 3 and mpmath. See README.md for definitions and error bounds.
"""
import argparse
import csv
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from math import factorial
from mpmath import iv, mp

QUAD_DEGREE = 648
MOMENT_BITS = 1960
MAX_RANK = 160
MOMENTS = None


def lower_dyadic(endpoint, bits):
    """Floor a finite mpmath binary endpoint times 2**bits, exactly."""
    sign, mantissa, exponent, _ = endpoint
    mantissa = -mantissa if sign else mantissa
    shift = exponent + bits
    return mantissa << shift if shift >= 0 else mantissa >> -shift


def upper_dyadic(endpoint, bits):
    sign, mantissa, exponent, length = endpoint
    return -lower_dyadic((1-sign, mantissa, exponent, length), bits)


def clenshaw_curtis(degree):
    cosines = [iv.cos(iv.pi*j/degree) for j in range(degree+1)]

    def cosine(index):
        index %= 2*degree
        return cosines[min(index, 2*degree-index)]

    for j in range(degree+1):
        weight = 1-cosine(degree*j)/(degree**2-1)
        for k in range(1, degree//2):
            weight -= 2*cosine(2*j*k)/(4*k*k-1)
        weight /= degree*(2 if j in (0, degree) else 1)
        yield (1+cosines[j])/2, weight


def raw_moments(max_rank):
    bits, degree = MOMENT_BITS, QUAD_DEGREE
    iv.prec = bits+40
    scale = 1 << bits
    count = 2*max_rank
    lower = [[0]*count for _ in range(4)]
    upper = [[0]*count for _ in range(4)]
    nodes = list(clenshaw_curtis(degree))
    for panel in range(32):
        for point, weight in nodes:
            s = (panel+point)/16
            s_lo = max(0, lower_dyadic(s._mpi_[0], bits))
            s_hi = upper_dyadic(s._mpi_[1], bits)
            z = iv.pi*iv.exp(4*s)
            exponential = iv.exp(-z)
            common = weight*iv.exp(s)/16
            # Groups 1, 2, 3, and all n >= 4. Quadrature evaluates through 24.
            high_group = iv.mpf(0)
            power = exponential**16
            ratio = exponential**9
            ratio_step = exponential**2
            for n in range(4, 25):
                v = n*n*z
                high_group += v*(2*v-3)*power
                power *= ratio
                ratio *= ratio_step
            terms = (z*(2*z-3)*exponential, 4*z*(8*z-3)*exponential**4,
                     9*z*(18*z-3)*exponential**9, high_group)
            for mode, term in enumerate(terms):
                mass = common*term
                lo = max(0, lower_dyadic(mass._mpi_[0], bits))
                hi = upper_dyadic(mass._mpi_[1], bits)
                for j in range(count):
                    lower[mode][j] += lo
                    upper[mode][j] += hi
                    lo = lo*s_lo >> bits
                    hi = (hi*s_hi + scale-1) >> bits
    divisor = 8**(degree+1)
    quadrature = (24*46000*scale+divisor-1)//divisor
    for j in range(count):
        radius = (quadrature+2)*3**j
        for mode in range(4):
            lower[mode][j] -= radius
            upper[mode][j] += radius
    return lower, upper


def scaled_moments(raw, rank, bits):
    lower, upper = raw
    power = rank.bit_length()
    rank_factorial = factorial(rank)

    def endpoint(x, k, upwards):
        shift = bits-MOMENT_BITS+(k-rank)*power
        numerator = (x*rank_factorial) << max(shift, 0)
        denominator = factorial(k) << max(-shift, 0)
        return -((-numerator)//denominator) if upwards else numerator//denominator

    for mode in range(4):
        lows = [endpoint(lower[mode][k], k, False) for k in range(2*rank)]
        highs = [endpoint(upper[mode][k], k, True) for k in range(2*rank)]
        center = [(lo+hi)//2 for lo, hi in zip(lows, highs)]
        row_error = sum(highs[k]-center[k] for k in range(1, 2*rank))
        yield center, row_error


def trial_bases(entries, rank, bits):
    """Bordering suggests two triangular bases. The verifier checks their product."""
    scale = 1 << bits
    values = [mp.ldexp(mp.mpf(x), -bits) for x in entries]
    pivot = values[rank]
    first = last = [mp.mpf(1)]
    left, right, signs = [], [], []
    for k in range(1, rank+1):
        normalizer = scale/mp.sqrt(abs(pivot))
        left.append([int(x*normalizer) for x in reversed(first)])
        right.append([int(x*normalizer) for x in last])
        signs.append(1 if pivot > 0 else -1)
        if k == rank:
            break
        alpha = mp.fdot(last, (values[rank-j-1] for j in range(k)))/pivot
        beta = mp.fdot(first, (values[rank+k-j] for j in range(k)))/pivot
        shifted = [0]+last
        padded = first+[0]
        last = [x-alpha*y for x, y in zip(shifted, padded)]
        first = [y-beta*x for x, y in zip(shifted, padded)]
        pivot *= 1-alpha*beta
    if min(row[-1] for row in left+right) <= 0:
        raise ArithmeticError("Singular trial basis")
    return left, right, signs


def verify_product(left, data, right, bits):
    """Enclose Q_left A Q_right^T in max row-sum norm using integer products."""
    entries, row_error = data
    rank, scale = len(left), 1 << bits
    result = []
    for row in left:
        partial = [sum(x*entries[rank+i-j] for i, x in enumerate(row)) >> bits
                   for j in range(rank)]
        result.append([sum(x*y for x, y in zip(partial, column)) >> bits
                       for column in right])
    norm_left = max(sum(map(abs, row)) for row in left)
    norm_right_t = max(sum(abs(row[j]) for row in right[j:]) for j in range(rank))
    input_error = (norm_left*row_error*norm_right_t+scale**2-1)//scale**2
    rounding_error = (rank*norm_right_t+scale-1)//scale+rank
    return result, input_error+rounding_error


def sector_cut(rank, bits, left, right, delta):
    """Bound the sum of absolute masses of ALL inner configurations in units of I0."""
    if rank <= 20:
        return None  # The region S <= r**2/20 has zero volume.
    iv.prec = 180
    r, scale = rank, 1 << bits
    log = iv.ln
    logfac = lambda k: log(iv.mpf(factorial(k)))
    d = r*(r-1)//2
    nu, w = r+d, 3*d
    radius = iv.mpf(r*r)/20
    available = radius-r
    h = log(radius/r)/4
    U = log(radius)/4
    det_lower = (r*log(1-iv.mpf(delta)/scale) - r*logfac(r)
                 - sum(log(iv.mpf(row[-1])/scale) for row in left+right))
    log_I0_lower = (det_lower+logfac(r)+sum(logfac(r+i) for i in range(r))
                    +r*log(8/iv.pi)-d*log(4*iv.pi))
    # Selberg's simplex formula, alpha=1, gamma=1/2. Integer/half-integer
    # Gamma arguments only. Implement those with factorials and sqrt(pi).
    def log_gamma_half(n):
        if n % 2 == 0:
            return logfac(n//2-1)
        k = n//2
        return logfac(2*k)-logfac(k)-k*log(iv.mpf(4))+log(iv.pi)/2

    log_G = sum(log_gamma_half(3+j)+log_gamma_half(2+j)-log_gamma_half(3)
                for j in range(r))
    if not (nu-iv.pi*available > 0):
        raise ArithmeticError("Radial inequality outside its domain")
    log_z = (log_G-logfac(nu-1)+nu*log(available)-iv.pi*radius
             -log(nu-iv.pi*available))
    log_s = w*log(r*h/w)+sum(k*log(iv.mpf(k)) for k in range(r-1, 2*r-1))
    log_bound = (r*log(2*r+U)+3*iv.mpf(r)/4*log(radius/r)
                 +log_s+log_z-log_I0_lower)
    return upper_dyadic((log_bound/log(iv.mpf(10)))._mpi_[1], 0)


def initialize(raw):
    global MOMENTS
    MOMENTS = raw


def row_norm(matrix):
    return max(sum(map(abs, row)) for row in matrix)


def rational_interval(x):
    return iv.mpf(x.numerator)/x.denominator


def symmetric_ball(center, radius):
    return rational_interval(center)+iv.mpf([-1,1])*rational_interval(radius)


def first_coefficient(matrix, error, scale):
    rank = len(matrix)
    trace = Fraction(sum(matrix[i][i] for i in range(rank)), scale)
    return symmetric_ball(trace, rank*error)


def second_coefficient(matrix, error, scale):
    rank = len(matrix)
    if rank == 1:
        return iv.mpf(0)
    trace = sum(matrix[i][i] for i in range(rank))
    trace_square = sum(matrix[i][j]*matrix[j][i]
                       for i in range(rank) for j in range(rank))
    center = Fraction(trace**2-trace_square, 2*scale**2)
    norm = Fraction(row_norm(matrix), scale)
    radius = rank*(rank+1)*error*(2*norm+error)/2
    return symmetric_ball(center, radius)


def balance(total, majorant, error, bits):
    """Find and then verify a weighted row norm using positive powers of two."""
    rank, scale = len(total), 1 << bits
    for goal_power in (10, 6, 2):
        powers = [0]*rank
        for _ in range(40):
            sums = [sum(value << shift for value,shift in zip(row,powers))
                    for row in majorant]
            # Each new weight is the next power of two above its row requirement.
            updated = []
            for shift,mass in zip(powers,sums):
                needed = ((mass << goal_power)+scale-1)//scale
                updated.append(max(shift,(max(1,needed)-1).bit_length()))
            if updated == powers:
                break
            powers = updated
            if max(powers) > 200:
                break
        largest = max(powers)
        if largest > 200:
            continue
        new_bits = bits+largest
        weighted_majorant = max(sum(value << (largest+j-i)
                                    for j,value in zip(powers,row))
                                for i,row in zip(powers,majorant))
        new_error = error*(1 << (largest-min(powers)))
        bound = Fraction(weighted_majorant,1 << new_bits)+new_error
        if bound < 1:
            weighted = [[value << (largest+j-i) for value,j in zip(row,powers)]
                        for row,i in zip(total,powers)]
            return weighted,new_error,new_bits,bound
    raise ArithmeticError("Unable to verify a weighted row norm below one")


def full_ratio(matrix, input_error, bits, norm):
    """Verify the full ratio using integer LU factors and a measured residual."""
    rank = len(matrix)
    places = min(340, bits)
    unit = 1 << places
    reduced = [[(value >> (bits-places))+(unit if i == j else 0)
                for j, value in enumerate(row)] for i, row in enumerate(matrix)]
    factors = [row.copy() for row in reduced]
    for k in range(rank):
        pivot = factors[k][k]
        if pivot <= 0:
            raise ArithmeticError("Nonpositive trial pivot")
        for i in range(k+1, rank):
            multiplier = (factors[i][k] << places)//pivot
            factors[i][k] = multiplier
            for j in range(k+1, rank):
                factors[i][j] -= multiplier*factors[k][j] >> places
    # Below the diagonal are trial L entries, with implicit units on the diagonal.
    # On and above the diagonal are U entries. Check their product exactly.
    residual = 0
    for i in range(rank):
        row_error = 0
        for j in range(rank):
            product = sum(factors[i][k]*factors[k][j] for k in range(min(i,j+1)))
            if i <= j:
                product += unit*factors[i][j]
            row_error += abs(unit*reduced[i][j]-product)
        residual = max(residual,row_error)
    absolute_error = input_error+Fraction(rank,unit)+Fraction(residual,unit**2)
    relative_error = absolute_error/(1-norm)
    if relative_error >= 1:
        raise ArithmeticError("LU residual too large")
    det_factors = iv.mpf(1)
    for i in range(rank):
        det_factors *= iv.mpf(factors[i][i])/unit
    return det_factors/(1+iv.mpf([-1,1])*rational_interval(relative_error))**rank


DECIMALS = 65
SECTORS = ('one_two','two_twos','one_three','other_mixed','all_mixed')


def decimal_endpoint(value, upwards):
    """Convert a finite binary endpoint to a directed decimal, without floats."""
    sign, mantissa, exponent, _ = value
    numer = (-mantissa if sign else mantissa)*10**DECIMALS
    if exponent >= 0:
        integer = numer << exponent
    else:
        divisor = 1 << -exponent
        integer = -((-numer)//divisor) if upwards else numer//divisor
    digits = str(abs(integer)).zfill(DECIMALS+1)
    return ('-' if integer < 0 else '')+digits[:-DECIMALS]+'.'+digits[-DECIMALS:]


def rank_result(rank):
    bits = min(1890, 650+12*rank)
    scale = 1 << bits
    mp.prec = bits+60
    iv.prec = 400
    base, *higher = scaled_moments(MOMENTS,rank,bits)
    left,right,signs = trial_bases(base[0],rank,bits)
    C, error = verify_product(left,base,right,bits)
    delta = max(sum(abs(v-(signs[i]*scale if i == j else 0))
                    for j,v in enumerate(row)) for i,row in enumerate(C))+error
    if delta >= scale or signs.count(-1) % 2:
        raise ArithmeticError(f"Base sign unverified at rank {rank}")
    total = [[0]*rank for _ in range(rank)]
    majorant = [[0]*rank for _ in range(rank)]
    total_error = Fraction()
    coefficients = {}
    for group, data in zip((2,3,4),higher):
        E, enclosure_error = verify_product(left,data,right,bits)
        estimate = [[sign*v for v in row] for sign,row in zip(signs,E)]
        mid_norm = Fraction(row_norm(estimate),scale)
        # Compare C^{-1}E_exact with the frozen dyadic approximation J E_mid.
        error = (enclosure_error+delta*mid_norm)/(scale-delta)
        total_error += error
        for i,row in enumerate(estimate):
            total[i] = [x+y for x,y in zip(total[i],row)]
            majorant[i] = [x+abs(y) for x,y in zip(majorant[i],row)]
        if group == 2:
            coefficients['one_two'] = first_coefficient(estimate,error,scale)
            coefficients['two_twos'] = second_coefficient(estimate,error,scale)
        elif group == 3:
            coefficients['one_three'] = first_coefficient(estimate,error,scale)
    weighted,weighted_error,weighted_bits,norm_bound = balance(total,majorant,total_error,bits)
    full = full_ratio(weighted,weighted_error,weighted_bits,norm_bound)
    coefficients['all_mixed'] = full-1
    coefficients['other_mixed'] = full-1-sum(coefficients[k] for k in SECTORS[:3])
    cut_exponent = sector_cut(rank,bits,left,right,delta)
    iv.prec = 400
    eta = iv.mpf(0) if cut_exponent is None else iv.mpf(10)**cut_exponent
    if not (eta < 1):
        raise ArithmeticError(f"Cutoff comparison inconclusive at rank {rank}")
    output = [rank,decimal_endpoint(rational_interval(norm_bound)._mpi_[1],True),
              cut_exponent]
    for name in SECTORS:
        q = coefficients[name]
        for value in (q,q+iv.mpf([-1,1])*eta*(1+abs(q))/(1-eta)):
            output.extend((decimal_endpoint(value._mpi_[0],False),
                           decimal_endpoint(value._mpi_[1],True)))
    return output


FIELDS = ['r','higher_mode_norm_upper','inner_absolute_mass_log10_upper']
FIELDS += [f'{sector}_{region}_{direction}' for sector in SECTORS
           for region in ('whole','exterior') for direction in ('lo','hi')]


def run_table(raw,max_rank,workers,csvname):
    with ProcessPoolExecutor(workers,initializer=initialize,initargs=(raw,)) as pool:
        with open(csvname,'w',newline='',encoding='utf-8') as stream:
            writer = csv.writer(stream)
            writer.writerow(FIELDS)
            for row in pool.map(rank_result,range(1,max_rank+1)):
                writer.writerow(row)
                stream.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-rank',type=int,default=160)
    parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--csv',default='wyniki.csv')
    args = parser.parse_args()
    if not 1 <= args.max_rank <= MAX_RANK or args.workers < 1:
        parser.error("Use a maximum rank in 1..160 and at least one worker")
    run_table(raw_moments(args.max_rank),args.max_rank,args.workers,args.csv)


if __name__ == '__main__':
    main()
