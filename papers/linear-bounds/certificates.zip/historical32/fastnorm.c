#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <gmp.h>
#include <stdlib.h>

static int import_long(mpz_t dst, PyObject *input) {
    int sign=_PyLong_Sign(input);
    size_t n=(_PyLong_NumBits(input)+7)/8;
    if (!n) { mpz_set_ui(dst,0); return 0; }
    unsigned char *buf=malloc(n);
    PyObject *abs_value=sign<0 ? PyNumber_Negative(input) : Py_NewRef(input);
    if (!buf || !abs_value) { free(buf); Py_XDECREF(abs_value); PyErr_NoMemory(); return -1; }
    int rc=_PyLong_AsByteArray((PyLongObject*)abs_value,buf,n,1,0);
    Py_DECREF(abs_value);
    if (!rc) {
        mpz_import(dst,n,-1,1,0,0,buf);
        if(sign<0) mpz_neg(dst,dst);
    }
    free(buf);
    return rc;
}

static PyObject *export_long(mpz_t x) {
    size_t bytes=(mpz_sizeinbase(x,2)+7)/8, written=0;
    unsigned char *buf=calloc(bytes,1);
    if(!buf) return PyErr_NoMemory();
    mpz_export(buf,&written,-1,1,0,0,x);
    PyObject *out=_PyLong_FromByteArray(buf,bytes,1,0);
    free(buf);
    return out;
}

static PyObject *bound(PyObject *self,PyObject *args) {
    PyObject *basis,*entries,*diagonal;
    int bits;
    if(!PyArg_ParseTuple(args,"OOiO",&basis,&entries,&bits,&diagonal)) return NULL;
    Py_ssize_t r=PyList_GET_SIZE(basis);
    mpz_t *U=malloc(r*r*sizeof(mpz_t)),*H=malloc((2*r-1)*sizeof(mpz_t));
    mpz_t *T=malloc(r*sizeof(mpz_t));
    if(!U || !H || !T) { free(U);free(H);free(T);return PyErr_NoMemory(); }
    mpz_t value,sum,peak,unit; mpz_inits(value,sum,peak,unit,NULL);
    mpz_setbit(unit,bits);
    for(Py_ssize_t i=0;i<r*r;i++) mpz_init(U[i]);
    for(Py_ssize_t i=0;i<r;i++) mpz_init(T[i]);
    for(Py_ssize_t i=0;i<2*r-1;i++) mpz_init(H[i]);
    PyObject *out=NULL;
    for(Py_ssize_t i=0;i<2*r-1;i++) {
        if(import_long(H[i],PyList_GET_ITEM(entries,i))) goto cleanup;
    }
    for(Py_ssize_t i=0;i<r;i++) for(Py_ssize_t k=0;k<=i;k++) {
        if(import_long(U[i*r+k],PyList_GET_ITEM(PyList_GET_ITEM(basis,i),k))) goto cleanup;
    }
    for(Py_ssize_t i=0;i<r;i++) {
        for(Py_ssize_t j=0;j<r;j++) {
            mpz_set_ui(value,0);
            for(Py_ssize_t k=0;k<=i;k++) mpz_addmul(value,U[i*r+k],H[j+k]);
            mpz_fdiv_q_2exp(T[j],value,bits);
        }
        mpz_set_ui(sum,0);
        for(Py_ssize_t j=0;j<r;j++) {
            mpz_set_ui(value,0);
            for(Py_ssize_t k=0;k<=j;k++) mpz_addmul(value,T[k],U[j*r+k]);
            mpz_fdiv_q_2exp(value,value,bits);
            if(i==j && diagonal!=Py_None) {
                long sign=PyLong_AsLong(PyList_GET_ITEM(diagonal,i));
                if(sign==1) mpz_sub(value,value,unit);
                else mpz_add(value,value,unit);
            }
            mpz_abs(value,value);mpz_add(sum,sum,value);
        }
        if(mpz_cmp(sum,peak)>0) mpz_set(peak,sum);
    }
    out=export_long(peak);
cleanup:
    for(Py_ssize_t i=0;i<r*r;i++) mpz_clear(U[i]);
    for(Py_ssize_t i=0;i<r;i++) mpz_clear(T[i]);
    for(Py_ssize_t i=0;i<2*r-1;i++) mpz_clear(H[i]);
    free(U); free(T); free(H);
    mpz_clears(value,sum,peak,unit,NULL);
    return out;
}
static PyMethodDef methods[]={{"bound",bound,METH_VARARGS,"Exact rounded product row norm."},{NULL,NULL,0,NULL}};
static struct PyModuleDef module={PyModuleDef_HEAD_INIT,"fastnorm",NULL,-1,methods};
PyMODINIT_FUNC PyInit_fastnorm(void){return PyModule_Create(&module);}
