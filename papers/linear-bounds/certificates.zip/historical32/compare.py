"""Verify every saved rank, endpoint and rounded bound in the independent replay."""
import csv
from collections import Counter
from fractions import Fraction
from pathlib import Path

base=Path(__file__).resolve().parent
tasks=[('t_0_do_1_16.csv',1,0,lambda r:Fraction(1,16),10**8),
       ('t_1_16_do_1_4.csv',1,Fraction(1,16),lambda r:Fraction(1,4),10**8),
       ('certyfikat_X.csv',2,8,lambda r:76*(r-1),10**9)]
for name,first,left,right,scale in tasks:
    def read(path):
        with path.open() as f:
            reader=csv.reader(f)
            next(reader)
            return [(int(r),Fraction(a),Fraction(b),int(v)) for r,a,b,v in reader]
    old=read(base/name)
    new=read(base/('regenerated_X.csv' if first==2 else 'regenerated_'+name))
    if Counter(old)!=Counter(new):
        raise ValueError(f'Different replay for {name}')
    for r in range(first,33):
        cursor=left
        for _,a,b,v in sorted(row for row in new if row[0]==r):
            if a!=cursor or a>=b or v<0 or v>=scale:
                raise ValueError((r,a,b,v))
            cursor=b
        if cursor!=right(r):
            raise ValueError((r,cursor))
    print(f'{name}: {len(new)} cells, whole cover, all rounded bounds identical.')
