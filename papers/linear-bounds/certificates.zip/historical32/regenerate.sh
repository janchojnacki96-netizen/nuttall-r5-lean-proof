#!/bin/sh
set -eu
cd "$(dirname "$0")"
gcc -O3 -shared -fPIC $(python3-config --includes) fastnorm.c -lgmp -o "fastnorm$(python3-config --extension-suffix)"
python3 replay_t.py
python3 luka.py --gmp --max-rank 32 --workers 5 --csv regenerated_X.csv
python3 compare.py
