"""Replay the two archived covers at their exact rational cells. Optional GMP."""
import csv
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as Q
from pathlib import Path
import przedzial as p
import native

def main():
    if not __debug__:
        raise RuntimeError("Enable assertions")
    p.iv.prec=p.BITS+60
    moments=p.raw_moments(32)
    p.iv.prec=p.BITS+60
    anchors=p.anchored_series(moments,32)
    p.initialize(anchors)
    if native.bound is not None:
        p.transformed_magnitude=native.transformed_magnitude
    for name in ['t_0_do_1_16.csv','t_1_16_do_1_4.csv']:
        groups={}
        expected={}
        for r,l,u,v in list(csv.reader(open(name)))[1:]:
            r,l,u=int(r),Q(l),Q(u)
            groups.setdefault((l,u),[]).append(r)
            expected[r,l,u]=int(v)
        jobs=[(rs,l,u,60) for (l,u),rs in groups.items()]
        with ProcessPoolExecutor(3) as pool, open('regenerated_'+name,'w') as f:
            writer=csv.writer(f)
            writer.writerow(['r','t_from','t_to','norm_upper_times_1e8'])
            for result in pool.map(p.work,jobs):
                for r,l,u,val in result:
                    upper=-(-10**8*val.numerator//val.denominator)
                    assert upper==expected.pop((r,l,u)), (r,l,u,upper)
                    writer.writerow([r,l,u,upper])
        assert not expected
        print(name, 'recreated exactly',flush=True)
if __name__=='__main__': main()
