"""Certify every signed Wronskian through rank r on a subinterval of [0,1/4] with m=2r."""
import argparse
import csv
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from math import factorial
from mpmath import iv, mp
from theta import (raw_moments, lower_dyadic, upper_dyadic,
                   MOMENT_BITS)

BITS = 1150
H = 1 << BITS
DEGREE = 380
LOCAL_DEGREE = 52
MAJORANT = 10**8
CENTER_DATA = None


def dyadic_interval(a):
    return lower_dyadic(a._mpi_[0], BITS), upper_dyadic(a._mpi_[1], BITS)


def divide(a, b, d):
    return a//d, -((-b)//d)


def series_polynomials(k):
    """P_j where Phi_n^(j)(t) = exp(t-x) P_j(x)."""
    p = [0,-3,2]
    for _ in range(k):
        yield p
        p = [(1+4*i)*(p[i] if i < len(p) else 0)
             -(4*p[i-1] if i else 0) for i in range(len(p)+1)]


def phi_jets(t, count):
    """Intervals for Phi derivatives at t with the entire theta tail."""
    y = iv.pi*iv.exp(4*t)
    values = [(y*n*n,iv.exp(t-y*n*n)) for n in range(1,25)]
    weight_sums = []
    for _ in range(count+2):
        weight_sums.append(dyadic_interval(sum(weight for _,weight in values)))
        values = [(x,x*weight) for x,weight in values]
    jets = []
    for k,p in enumerate(series_polynomials(count)):
        lo,hi = 0,0
        for coefficient,(a,b) in zip(p,weight_sums):
            if coefficient < 0:
                a,b = b,a
            lo += coefficient*a
            hi += coefficient*b
        # Cauchy bounds the omitted derivatives on a complex disk of radius 1/4.
        tail = (H >> 1000)*factorial(k)*4**k
        jets.append((lo-tail,hi+tail))
    return jets


def signed_jets(t,count):
    return [(a,b) if k % 2 == 0 else (-b,-a)
            for k,(a,b) in enumerate(phi_jets(t,count))]


def origin_moments(moments, max_r):
    lower,upper = moments
    # Exact common scale. The four groups include the entire theta sum.
    return [divide(sum(v[j] for v in lower),sum(v[j] for v in upper),
                   (1 << (MOMENT_BITS-BITS))*factorial(j))
            for j in range(2*max_r)]


def anchor_series(start, anchor):
    negative = signed_jets(rational(anchor), DEGREE)
    series = []
    for j in range(len(start)):
        row = []
        for k in range(DEGREE+1):
            index = j-k
            a,b = start[index] if index >= 0 else negative[-index-1]
            if k % 2:
                a,b = -b,-a
            row.append(divide(a,b,factorial(k)))
        series.append(row)
    return series


def evaluate_series(coefficients, center):
    n,d = center.numerator,center.denominator
    a,b = coefficients[-1]
    for lo,hi in reversed(coefficients[:-1]):
        a = lo + n*a//d
        b = hi - ((-n*b)//d)
    # All centers satisfy 4*center <= 1/4. Cauchy remainder.
    tail = (4*MAJORANT*H + 3*4**(DEGREE+1)-1)//(3*4**(DEGREE+1))
    return a-tail,b+tail


def initialize(series):
    global CENTER_DATA
    CENTER_DATA = series


def hankel_basis(entries, rank, bits):
    """Propose one triangular basis for all leading blocks of the Hankel matrix."""
    scale = 1 << bits
    h = [mp.ldexp(mp.mpf(v),-bits) for v in entries]
    q,previous = [mp.mpf(1)],[]
    previous_pivot = 1
    basis, signs = [],[]
    for k in range(rank):
        def pair(offset):
            return mp.fdot(q,h[k+offset:k+offset+len(q)])
        pivot = pair(0)
        normalizer = scale/mp.sqrt(abs(pivot))
        basis.append([int(c*normalizer) for c in q])
        if basis[-1][-1] <= 0:
            raise ArithmeticError('singular trial basis')
        signs.append(1 if pivot > 0 else -1)
        if k+1 < rank:
            beta = pivot/previous_pivot
            alpha = (pair(1)-beta*mp.fdot(previous,h[k:k+len(previous)]))/pivot
            padded = previous + [0]*(k+2-len(previous))
            old = q+[0]
            shifted = [0]+q
            previous,q = q,[u-alpha*v-beta*w for u,v,w in zip(shifted,old,padded)]
            previous_pivot = pivot
    return basis,signs


def transformed_magnitude(basis, entries, bits, diagonal=None):
    """Bound the row norm after congruence via exact dyadic products."""
    scale = 1 << bits
    rank = len(basis)
    mid = [(a+b)//2 for a,b in entries]
    err = sum(b-c for (_,b),c in zip(entries,mid))
    max_row = 0
    for i,row in enumerate(basis):
        temp = [sum(x*mid[j+k] for k,x in enumerate(row)) >> bits
                for j in range(rank)]
        prod = [sum(x*y for x,y in zip(temp,v)) >> bits for v in basis]
        if diagonal is not None:
            prod[i] -= diagonal[i]*scale
        max_row = max(max_row,sum(map(abs,prod)))
    norm = max(sum(map(abs,row)) for row in basis)
    norm_t = max(sum(abs(row[i]) for row in basis[i:]) for i in range(rank))
    err = (err*norm*norm_t+scale**2-1)//scale**2
    rounding = (rank*norm_t+scale-1)//scale+rank
    return max_row+err+rounding,norm*norm_t


def anchored_series(moments,max_rank):
    moments = origin_moments(moments,max_rank)
    anchors = []
    for k in range(4):
        anchors.append(anchor_series(moments,Fraction(k,16)))
        if k < 3:
            moments = [evaluate_series(s,Fraction(1,16)) for s in anchors[-1]]
    return anchors


def cell_setup(center,max_rank,degree):
    iv.prec = BITS+60
    k = min(3,int(center*16))
    offset = center-Fraction(k,16)
    positive = [evaluate_series(s,offset) for s in CENTER_DATA[k][:2*max_rank]]
    negative = signed_jets(rational(center),degree)
    return positive,negative


def rational(x):
    return iv.mpf(x.numerator)/x.denominator


def verify(center,radius,rank,prepared,degree):
    bits = min(BITS,200+10*rank)
    scale = 1 << bits
    mp.prec = bits+60
    positive,negative = prepared
    m = 2*rank
    power = rank.bit_length()
    normalizer = factorial(m-1)

    def coefficient(k,weight):
        offsets = []
        for ell in range(m-1):
            index = m-1-ell-k
            a,b = positive[index] if index >= 0 else negative[-index-1]
            if k%2:
                a,b = -b,-a
            mul = normalizer*weight.numerator
            den = weight.denominator << (BITS-bits+ell*power)
            offsets.append(divide(a*mul,b*mul,den))
        return offsets

    constant = coefficient(0,Fraction(1))
    middle = [(a+b)//2 for a,b in constant]
    basis,signs = hankel_basis(middle,rank,bits)
    if signs != [(-1)**k for k in range(rank)]:
        raise ArithmeticError(f'unexpected midpoint pivot at r={rank}, t={center}')
    upper,product = transformed_magnitude(basis,constant,bits,signs)
    rho = 4*radius
    tail = Fraction(rank*product*MAJORANT*normalizer,scale**2)*rho/(1-rho)
    if upper*4 > 3*scale or Fraction(upper,scale)+tail*rho**degree > Fraction(3,4):
        return Fraction(1)
    weight = Fraction(1)
    for k in range(1,degree+1):
        if Fraction(upper,scale)+tail <= Fraction(3,4):
            return Fraction(upper,scale)+tail
        weight *= radius/k
        val,_ = transformed_magnitude(basis,coefficient(k,weight),bits)
        upper += val
        tail *= rho
        if upper*4 > 3*scale:
            return Fraction(1)
    return Fraction(upper,scale)+tail


def work(job):
    ranks,start,end,degree = job
    center,radius = (start+end)/2,(end-start)/2
    prepared = cell_setup(center,max(ranks),degree)
    return [(r,start,end,verify(center,radius,r,prepared,degree)) for r in ranks]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--max-rank',type=int,default=24)
    p.add_argument('--workers',type=int,default=8)
    p.add_argument('--csv',default='wyniki.csv')
    p.add_argument('--degree',type=int,default=LOCAL_DEGREE)
    p.add_argument('--start',type=Fraction,default=Fraction(1,16))
    p.add_argument('--end',type=Fraction,default=Fraction(1,4))
    args = p.parse_args()
    if not (1<=args.max_rank<=48 and 1<=args.degree<=80 and args.workers>=1):
        p.error('Supported ranks 1..48, degrees 1..80 and positive worker count')
    if not 0 <= args.start < args.end <= Fraction(1,4):
        p.error('Require 0 <= start < end <= 1/4')
    moments = raw_moments(args.max_rank)
    iv.prec = BITS+60
    series = anchored_series(moments,args.max_rank)
    run(series,args)


def run(series,args):
    edges = [args.start]+[Fraction(k,16) for k in range(1,4)
                           if args.start < Fraction(k,16) < args.end]+[args.end]
    pending = [(r,a,b,args.degree) for a,b in zip(edges,edges[1:])
               for r in range(1,args.max_rank+1)]
    with ProcessPoolExecutor(args.workers,initializer=initialize,initargs=(series,)) as pool:
        with open(args.csv,'w',newline='',encoding='utf-8') as stream:
            writer = csv.writer(stream)
            writer.writerow(['r','t_from','t_to','norm_upper_times_1e8'])
            while pending:
                print('cells in current batch',len(pending),flush=True)
                next_batch = []
                groups = {}
                for r,a,b,degree in pending:
                    groups.setdefault((a,b,degree),[]).append(r)
                jobs = [(ranks,a,b,degree) for (a,b,degree),ranks in groups.items()]
                for results in pool.map(work,jobs):
                    for r,a,b,norm in results:
                        if norm*4 <= 3:
                            cap = -((-10**8*norm.numerator)//norm.denominator)
                            writer.writerow([r,str(a),str(b),cap])
                            stream.flush()
                        else:
                            if b-a <= Fraction(1,2**18):
                                raise ArithmeticError(f'cell too small at r={r}, t={a}: {float(norm)}')
                            middle = (a+b)/2
                            next_batch.extend([(r,a,middle,args.degree),(r,middle,b,args.degree)])
                pending = next_batch


if __name__ == '__main__':
    main()
