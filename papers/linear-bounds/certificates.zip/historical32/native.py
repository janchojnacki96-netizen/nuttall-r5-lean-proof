"""Optional GMP evaluation of the same integer matrix products."""
try:
    from fastnorm import bound
except ImportError:
    bound = None


def transformed_magnitude(basis, entries, bits, diagonal=None):
    scale = 1 << bits
    rank = len(basis)
    center = [(a+b)//2 for a,b in entries]
    err = sum(b-c for (_,b),c in zip(entries,center))
    peak = bound(basis,center,bits,diagonal)
    norm = max(sum(map(abs,row)) for row in basis)
    norm_t = max(sum(abs(row[i]) for row in basis[i:]) for i in range(rank))
    err = (err*norm*norm_t+scale**2-1)//scale**2
    rounding = (rank*norm_t+scale-1)//scale+rank
    return peak+err+rounding,norm*norm_t
