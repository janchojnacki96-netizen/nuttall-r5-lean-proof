# Dodatniość wrońskianów Nuttalla dla dużego t

Niech $W_p(\Psi_m;t)=\det[\Psi_m^{(i+j)}(t)]_{0\le i,j<p}$, gdzie $\Psi_m$ jest $m$-krotną całką ogonową pełnego jądra theta. Piszemy $L=m-p$ i $X=\pi e^{4t}$. Dla $p\ge2$, $L\ge p$ i $X\ge38L$ zachodzi
$$
(-1)^{p(p-1)/2}W_p(\Psi_m;t)>0 .
$$
Dla $p=1$ wystarcza dodatniość każdego składnika jądra przy $t\ge0$. W szczególności przy $m=2r$, $r\ge2$, wszystkie rzędy $p\le r$ mają właściwy znak, gdy $X\ge76(r-1)$.

## Reprezentacja wyznacznika

Niech $g(u)=e^u\sum_{n\ge1}x_n(u)e^{-x_n(u)}$, gdzie $x_n(u)=\pi n^2e^{4u}$. Wtedy $2\Phi=-(g'+g)$. Oznaczmy przez $b_k^f$ całkę ogonową rzędu $k$ funkcji $f$. Podpisany wrońskian jest równy $\det[b_{L+1+i-j}^\Phi]_{0\le i,j<p}$. Wynika to z odwrócenia wierszy i usunięcia czynników $(-1)^{i+j}$ z macierzy pochodnych. Wpis w wierszu $i$ ma postać
$$
\frac1{2(L+i)!}\int_0^\infty s^{L+i-1}(L+i-s)(-1)^j g^{(j)}(t+s)\,ds .
$$
Istotnie $2b_{L+1+i}^\Phi=b_{L+i}^g-b_{L+1+i}^g$, a różniczkowanie względem $t$ daje pozostałe kolumny. Zbieżność wykładnicza uzasadnia różniczkowanie pod całką.

Z tożsamości Andréiefa, po pominięciu wspólnych dodatnich czynników, otrzymujemy znak całki
$$
\sum_{n_1,\ldots,n_p\ge1}\int
 P_L(s)\Delta(s)\Delta(v)\prod_i
 s_i^{L-1} e^{5s_i}n_i^2e^{-Xv_i}\,ds_i,
 \qquad v_i=n_i^2e^{4s_i},
$$
gdzie $\Delta$ to wyznacznik Vandermonde’a oraz $P_L(s)=\mathbb E\prod_i(T-s_i)$ dla $T\sim\mathrm{Gamma}(L,1)$. W pierwszym wyznaczniku Andréiefa kolumna $i$ jest równa $s^i(L+i-s)$. W rozwinięciu mogą pozostać jedynie składniki, które wybierają niższą potęgę w początkowych $k$ kolumnach i wyższą w pozostałych. Daje to $\Delta(s)\sum_k(-1)^{p-k}(L)_k e_{p-k}(s)$, gdzie $e_j$ jest elementarnym wielomianem symetrycznym. Momenty gamma dają $P_L$. W drugim wyznaczniku można rozwinąć szereg w wierszach. Znormalizowane pochodne $(-1)^j g_n^{(j)}$ mają czynniki wielomianowe w $v$ stopnia $j$ z dodatnim współczynnikiem wiodącym $(4X)^j$. Zmiana trójkątna w kolumnach daje $\Delta(v)$. Przejścia pod całką i sumą są uzasadnione szybkim zanikiem w $s$ i gaussowskim w $n$ dla każdego ustalonego rzędu.

## Wiersze z jedynką i małym s

Piszemy $b=L/8$. Za dobre uznajemy wiersze z $n=1$ i $s\le b$. Gdy wszystkie wiersze są dobre, wyznaczniki Vandermonde’a mają ten sam znak. Nierówność Paleya–Zygmunda dla $T$ daje
$$
\mathbb P(T\ge L/2)\ge \frac{L^2}{4(L^2+L)}\ge\frac18 .
$$
W tym zdarzeniu iloczyn jest co najmniej $(3L/8)^p$. Każdy ujemny wkład może pochodzić tylko z $T\le b$, gdzie moduł iloczynu jest co najwyżej $(L/8)^p$. Przy $p\ge2$ otrzymujemy
$$
P_L(s)\ge (3L/8)^p/8-(L/8)^p\ge (L/8)^p/8 .
$$
Globalnie $|P_L(s)|\le\prod_i(2L+s_i)$, ponieważ $(L)_j\le (2L)^j$ dla $j\le p\le L$.

Niech $J_0$ będzie masą z modułami wyznaczników po wszystkich dobrych wierszach, z pominięciem $P_L$. Jest ściśle dodatnia. Wkład dobrych wierszy do całki ze znakami jest zatem co najmniej $L^p J_0/(8\cdot8^p)$.

## Porównanie jednego wiersza

Przy ustalonych innych wierszach niech $\alpha_j=s_j\ge0$ i $\beta_j=v_j\ge1$ będą ich węzłami oraz niech $M=\prod_{j}(1+\alpha_j)(1+\beta_j)$. Część obu wyznaczników zależna od badanego wiersza to $\prod_j |s-\alpha_j|\,|n^2e^{4s}-\beta_j|$. Dla $s$ jednostajnego na $[1/16,1/8]$ zachodzi
$$
\mathbb E\log |s-\alpha|\ge\log(1+\alpha)-6,
\qquad
\mathbb E\log |e^{4s}-\beta|\ge\log(1+\beta)-5.
$$
Średnia logarytmu odległości od dowolnego rzeczywistego punktu na przedziale długości $\ell$ ma minimum $\log(\ell/2)-1$, w środku przedziału. To wystarcza dla $\alpha\le1$. Dla $\alpha>1$ odległość podzielona przez $1+\alpha$ przekracza $7/16$. Dla $1\le\beta\le4$ stosujemy nierówność $|e^{4s}-\beta|\ge4|s-\log(\beta)/4|$. Przy $\beta>4$ stosunek odległości do $1+\beta$ przekracza $(4-e^{1/2})/5$.

Z Jensena i wag dla dobrego wiersza na $[1/16,1/8]$ dostajemy dolną granicę jego warunkowej masy bez $P_L$,
$$
M\,16^{-L} e^{-11(p-1)-e^{1/2}X}\ge M e^{-14L-e^{1/2}X}.
$$
Przedział leży w $[0,b]$, ponieważ $L\ge2$.

Dla złego wiersza uwzględniamy czynnik $2+s/L$ z globalnego oszacowania $P_L$. Po podzieleniu przez $M$ i przed uwzględnieniem wykładnika $e^{-Xv}$ otrzymujemy górną granicę
$$
2^p e^{(L+5p)s}n^{2p}\le2^L e^{6Ls}n^{2L}\le e^{(3/2)Lv},
\qquad v=n^2e^{4s}.
$$
Pierwsza nierówność wynika z $|s-\alpha|\le(1+s)(1+\alpha)$, $|v-\beta|\le(1+v)(1+\beta)$, $1+v\le2v$ i $2+s/L\le2e^s$. Dla ostatniej nierówności używamy $6s\le(3/2)(e^{4s}-1)$ i $2\log n\le n^2-1$. Przy $X\ge12L$ pozostaje wykładnik $e^{-7Xv/8}$. Dla złego wiersza $v\ge e$ przy $s>b$, a $v\ge4$ przy $n\ge2$. W obu przypadkach $v\ge8/3$, zatem
$$
e^{-7Xv/8}\le e^{-13X/6}e^{-Xv/16}.
$$
Suma całek reszty po wszystkich wierszach jest co najwyżej $\sum_{n\ge1}4/(Xn^2)\le8/X\le1$. Korzystamy z $e^{4s}\ge1+4s$. Porównanie z dobrą masą daje iloraz nie większy niż
$$
\varepsilon=e^{14L-X/2},
$$
ponieważ $e^{1/2}<5/3$. Ograniczenie jest jednostajne względem pozostałych wierszy.

## Znak całej całki

Jeśli dobry wiersz pojawia się przy globalnej majorancie $|P_L|$, jego czynnik $2+s/L$ jest najwyżej $17/8$. Dla ustalonego niepustego zbioru $k$ złych pozycji zastępujemy je kolejno dobrymi z uzyskaną granicą warunkową. Całka bezwzględna dla tego zbioru pozycji jest najwyżej $L^p(17/8)^{p-k}\varepsilon^k J_0$. Suma po wszystkich zbiorach jest co najwyżej
$$
 L^p(17/8)^p[(1+\varepsilon)^p-1] J_0
 \le2p\varepsilon L^p(17/8)^p J_0 .
$$
Przy $X\ge38L$ mamy $\varepsilon\le e^{-5L}$, więc $p\varepsilon\le1$. Po podzieleniu przez dodatnią dolną granicę otrzymujemy iloraz najwyżej $16p\,17^p e^{-5L}<1$. Istotnie $p\le L$, $L\ge2$, $\log(16L)/L\le\log(32)/2<1.74$ i $\log17<2.84$. Wkład wszystkich dobrych wierszy dominuje zatem nad sumą modułów wszystkich pozostałych układów. Daje to ścisłą dodatniość podpisanego wrońskianu.

[J. Nuttall, Wronskians, Cumulants, and the Riemann Hypothesis](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf)
