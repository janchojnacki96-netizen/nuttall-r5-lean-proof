"""Interval proof in X=pi*exp(4*t) from 8 to the analytic tail."""
import argparse
import csv
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from math import isqrt
from mpmath import iv, mp
from theta import clenshaw_curtis, lower_dyadic, upper_dyadic
from przedzial import hankel_basis, transformed_magnitude, divide

MANTISSA = 1060
SCALE = 1 << MANTISSA
QUAD = 600
SERIES = 285
MAJORANT = 1 << 90
NODES = None
ANCHORS = None


def as_iv(q):
    q=Fraction(q)
    return iv.mpf(q.numerator)/q.denominator


def scaled_ball(value):
    return lower_dyadic(value._mpi_[0],MANTISSA),upper_dyadic(value._mpi_[1],MANTISSA)


def initialize(nodes=None,anchors=None,use_gmp=False):
    global NODES, ANCHORS, transformed_magnitude
    if use_gmp:
        import native
        if native.bound is None:
            raise RuntimeError("Build fastnorm first, or omit --gmp")
        transformed_magnitude=native.transformed_magnitude
    NODES,ANCHORS=nodes,anchors
    iv.prec=MANTISSA+60


def quadrature(job):
    A,B,max_rank=job
    a,d=as_iv(A),as_iv(B-A)
    lo=[0]*(2*max_rank); hi=lo.copy()
    # On the real axis discarded modes have a uniformly negligible tail.
    limit=min(24, 1+isqrt(1000//A))
    for v,w in NODES:
        u=d*v
        z=1+u/a
        r=a*iv.ln(z)
        phase=iv.exp(-a-u)
        base=iv.exp(-u)
        phi=iv.mpf(0)
        term=base
        ratio=phase**3
        step=phase**2
        for n in range(1,limit+1):
            x=n*n*z
            phi+=x*(2*x-3/a)*term
            term*=ratio
            ratio*=step
        q=phi*d*w/(z**(iv.mpf(3)/4))
        ql,qh=scaled_ball(q)
        rl,rh=scaled_ball(r)
        ql=max(0,ql); rl=max(0,rl)
        for j in range(2*max_rank):
            lo[j]+=ql;hi[j]+=qh
            den=SCALE*(j+1)
            ql,qh=divide(ql*rl,qh*rh,den)
    # Complex Taylor remainder plus omitted theta modes; uniform in j.
    error=1 << (MANTISSA-870)
    return A,[(a-error,b+error) for a,b in zip(lo,hi)]


def grid():
    points=[Fraction(8)]
    for k in range(3,12):
        a=Fraction(2**k)
        step=min(Fraction(2**k,16),Fraction(32))
        count=int(a/step)
        points.extend(a+j*step for j in range(1,count+1))
    assert points[-1]==4096
    return points


def moments_at_anchors(points,partials,max_rank):
    tail=[(0,MAJORANT*SCALE)]*(2*max_rank)
    anchors={}
    for A,B in reversed(list(zip(points,points[1:]))):
        x,y=as_iv(A),as_iv(B)
        v=x*iv.ln(y/x)
        q=iv.exp(x-y)*(y/x)**(iv.mpf(5)/4)
        powers=[iv.mpf(1)]
        for j in range(1,2*max_rank):
            powers.append(powers[-1]*v/j)
        factors=[scaled_ball(q*powers[j]) for j in range(2*max_rank)]
        mapped=[]
        decay=[scaled_ball((x/y)**k) for k in range(2*max_rank)]
        for k,(lo,hi) in enumerate(tail):
            dl,dh=decay[k]
            mapped.append(divide(max(0,lo)*dl,hi*dh,SCALE))
        keep=[]
        for j,(a,b) in enumerate(partials[A]):
            lo=hi=0
            for k in range(j+1):
                u,v=factors[j-k]
                c,d=mapped[k]
                lo+=max(0,u)*c
                hi+=v*d
            lo,hi=divide(lo,hi,SCALE)
            keep.append((max(0,a+lo),b+hi))
        anchors[A]=keep
        tail=keep
    return anchors


def phi_coefficients(A,count):
    """Taylor coefficients of G_{-1}(A*(1+z))."""
    a=as_iv(A)
    result=[iv.mpf(0) for k in range(count)]
    limit=min(24, 1+isqrt(1580//A))
    for n in range(1,limit+1):
        b=a*(n*n-1)
        c=iv.exp(-b)
        p0=2*n**4-3*n*n/a
        p1=4*n**4-3*n*n/a
        p2=2*n**4
        previous=penultimate=iv.mpf(0)
        for k in range(count):
            result[k]+=p0*c+p1*previous+p2*penultimate
            penultimate,previous,c=previous,c,-c*b/(k+1)
    # Dropped |G_-1| < 2^-1120 on the disk |z| <= 1/2.
    error_scale=Fraction(SCALE,1<<1120)
    out=[]
    for k,value in enumerate(result):
        lo,hi=scaled_ball(value)
        err=error_scale*(1<<k)
        out.append((lo-(-(-err.numerator//err.denominator)),
                    hi+(-(-err.numerator//err.denominator))))
    return out


def series(A,base,degree,moving=False):
    c=[[p] for p in base]
    phi=phi_coefficients(A,degree)
    a=Fraction(A)
    d=a.denominator
    for k in range(degree):
        mix0=a-Fraction(1,4)-k
        for j,row in enumerate(c):
            variable=moving and j>=2
            mix=mix0+(j-1 if variable else 0)
            lo,hi=row[k]
            if mix<0:
                lo,hi=hi,lo
            if k:
                prev=row[k-1]
            else:
                prev=(0,0)
            lower,upper=phi[k] if j==0 else c[j-1][k]
            if variable and k:
                p,q=c[j-1][k-1]
                lower+=p
                upper+=q
            x=lo*mix.numerator*d+a.numerator*mix.denominator*(prev[0]-upper)
            y=hi*mix.numerator*d+a.numerator*mix.denominator*(prev[1]-lower)
            row.append(divide(x,y,d*mix.denominator*(k+1)))
    return c


def evaluate(series_,z):
    """Evaluate G at 0 <= z <= 1/16 with certified Horner."""
    if z<0 or z>Fraction(1,16):
        raise ArithmeticError(f'unsupported anchor displacement {z}')
    n,d=z.numerator,z.denominator
    degree=len(series_[0])-1
    ratio=2*z
    error=SCALE*MAJORANT * ratio**(degree+1)/(1-ratio)
    cap=-(-error.numerator//error.denominator)
    result=[]
    for row in series_:
        lo,hi=row[-1]
        for a,b in reversed(row[:-1]):
            lo=a+lo*n//d
            hi=b-((-hi*n)//d)
        result.append((lo-cap,hi+cap))
    return result


def scaled_at_center(A,C,values):
    # Change from the (4A) gauge to the (4C) gauge. Common A^-2 becomes C^-2.
    ratio=as_iv(C/A)
    output=[]
    for j,(a,b) in enumerate(values):
        lo,hi=scaled_ball(ratio**(j-1))
        output.append(divide(max(a,0)*lo,b*hi,SCALE))
    return output


def verify(rank,coefficients,rho,degree,moving=False):
    bits=380+11*rank
    scale=1<<bits
    divisor=1<<(MANTISSA-bits)
    mp.prec=bits+70
    high=2*rank-1
    def diagonal(k,weight):
        den=weight.denominator*divisor
        mul=weight.numerator
        return [divide(a*mul,b*mul,den) for a,b in
                (coefficients[j][k] for j in range(high,0,-1))]
    entries=diagonal(0,Fraction(1))
    basis,signs=hankel_basis([(a+b)//2 for a,b in entries],rank,bits)
    if signs!=[(-1)**k for k in range(rank)]:
        raise ArithmeticError(f'wrong trial pivot for r={rank}')
    total,norm=transformed_magnitude(basis,entries,bits,signs)
    rr=2*rho
    majorant=MAJORANT << (2*rank if moving else 0)
    error=Fraction(rank*norm*majorant,scale**2)*rr/(1-rr)
    if Fraction(total,scale)+error*rr**degree>=1:
        return None
    weight=Fraction(1)
    for k in range(1,degree+1):
        if Fraction(total,scale)+error<=Fraction(7,8):
            return Fraction(total,scale)+error
        weight*=rho
        value,_=transformed_magnitude(basis,diagonal(k,weight),bits)
        total+=value
        error*=rr
        if total*8>7*scale:
            return None
    bound=Fraction(total,scale)+error
    return bound if bound<=Fraction(7,8) else None


def certify_block(job):
    A,B,max_rank,degree=job
    moving=A>=128
    # Every center is within a relative distance 1/16 of the left anchor.
    base=series(A,ANCHORS[A],SERIES)
    pending=defaultdict(list)
    ranks=[r for r in range(2,max_rank+1) if A<76*(r-1)]
    for r in ranks:
        pending[(A,min(B,Fraction(76*(r-1))))].append(r)
    results=[]
    while pending:
        onward=defaultdict(list)
        for (a,b),rs in sorted(pending.items()):
            C=(a+b)/2
            values=evaluate(base,(C-A)/A)
            c=series(C,scaled_at_center(A,C,values)[:2*max(rs)],degree,moving)
            for r in rs:
                bound=verify(r,c,(b-a)/(2*C),degree,moving)
                if bound is None:
                    if (b-a)/C < Fraction(1,1<<15):
                        raise ArithmeticError(f'unresolved rank {r}, X={C}')
                    onward[(a,C)].append(r)
                    onward[(C,b)].append(r)
                else:
                    v=bound*10**9
                    results.append((r,str(a),str(b),-((-v.numerator)//v.denominator)))
        pending=onward
    return A,results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers',type=int,default=8)
    parser.add_argument('--max-rank',type=int,default=32)
    parser.add_argument('--degree',type=int,default=85)
    parser.add_argument('--csv',default='wyniki.csv')
    parser.add_argument('--gmp',action='store_true')
    args=parser.parse_args()
    if not 2<=args.max_rank<=32 or not 1<=args.degree<=160 or args.workers<1:
        parser.error('Require rank 2..32, degree 1..160 and at least one worker')
    initialize()
    nodes=list(clenshaw_curtis(QUAD))
    points=grid()
    with ProcessPoolExecutor(args.workers,initializer=initialize,initargs=(nodes,)) as pool:
        partials={}
        for A,part in pool.map(quadrature,[(a,b,args.max_rank) for a,b in zip(points,points[1:])],chunksize=1):
            partials[A]=part
            if len(partials)%20==0:
                print('quadrature panels',len(partials),flush=True)
    anchors=moments_at_anchors(points,partials,args.max_rank)
    jobs=[(a,b,args.max_rank,args.degree) for a,b in zip(points,points[1:])
          if a<76*(args.max_rank-1)]
    with ProcessPoolExecutor(args.workers,initializer=initialize,initargs=(None,anchors,args.gmp)) as pool:
        with open(args.csv,'w',newline='') as stream:
            writer=csv.writer(stream)
            writer.writerow(['r','X_from','X_to','norm_upper_times_1e9'])
            for A,rows in pool.map(certify_block,jobs):
                writer.writerows(rows)
                stream.flush()
                print('X block completed',str(A),len(rows),flush=True)


if __name__=='__main__':
    main()
