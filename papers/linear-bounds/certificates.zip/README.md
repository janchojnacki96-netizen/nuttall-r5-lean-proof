# Computational supplement / Suplement obliczeniowy

Jan Chojnacki, *Linear bounds for the integration order of the Riemann theta kernel*  
*Liniowe ograniczenia na liczbę całkowań jądra theta Riemanna*

The directories below use the paths cited in Appendix B of both manuscripts.  
Katalogi mają nazwy użyte w dodatku B obu wersji artykułu.

| Directory | Contents / Zawartość |
|---|---|
| determinants | Proof notes on the strips and density result, and the independent scalar interval checker for Appendix C. Noty o zakresach i gęstości oraz rachunek przedziałowy do dodatku C. |
| small | Compact certificates for Φ through order 4, Ψ₁ through order 7 and Ψ₂ through order 8. Certyfikaty na przedziale zwartym dla Φ do rzędu 4, Ψ₁ do rzędu 7 i Ψ₂ do rzędu 8. |
| historical32 | Original and regenerated historical cell data, full generators and row-by-row comparison. Tabele pierwotne i odtworzone wraz z generatorami. |
| upper | The global upper-bound proof, analytic large-rank note, original midrange code and fresh replay. Dowód globalnej granicy górnej, duże rzędy i odtworzenie obliczeń rzędów pośrednich. |
| rank500 | Standalone C++ sources, Fourier-error derivations, archived grid outputs, point certificates and four moment caches. Świadek rzędu 500, pomiary na siatkach, oszacowania błędów oraz dane momentowe. |
| r5 | Earlier PL/EN order-five paper and compact Lean replay sources. Wcześniejsze artykuły i źródła zwartej części w Lean. |
| notes | Original lower-bound manuscript and additional local or model studies. Noty historyczne mają stan wiedzy z chwili powstania. Consult the present paper for the status of each principal result. |


## Fast checks / Szybka kontrola

Use Python 3.12, mpmath 1.3.0 and NumPy 2.3.5. Run from the unpacked directory without Python's optimization flag. SHA256SUMS lists each payload file except itself.

~~~sh
sha256sum -c SHA256SUMS
python verify_release.py
python small/certify.py
~~~

The quick audit recomputes the 64 cells for Φ and compares every row with `small/phi4_cells.csv`. To print the table separately, run `python small/check_phi4.py`. The largest upward-rounded bound is 637776742/10⁹. The program `small/certify.py` computes the 67 cells for Ψ₁ from fresh input. Its largest upward-rounded bound is 801559662/10⁹. These two covers extend from 0 to 1/2, including the endpoints. Section 2 supplies the Cauchy remainders and the proof for the infinite tail.

Szybki audyt przelicza 64 komórki dla Φ i porównuje każdy wiersz z `small/phi4_cells.csv`. Osobne polecenie `python small/check_phi4.py` wypisuje tę tabelę. Największa zaokrąglona w górę granica wynosi 637776742/10⁹. Program `small/certify.py` odtwarza z szeregu theta 67 komórek dla Ψ₁, z największą granicą 801559662/10⁹. Te dwa pokrycia obejmują [0, 1/2] wraz z końcami. Rozdział 2 zawiera oszacowania reszt Taylora i dowód na nieskończonym ogonie.

The quick audit also regenerates the order-eight witness at t = 5/64 and all 86 closed cells for Ψ₂, including their Taylor remainders. The largest bound is 823252099/10⁹. Section 2.3 gives the compact proof and section 2.4 proves the signs on the infinite tail. To reproduce the files separately, run

~~~sh
python small/check_order8.py > order8_replay.csv 2> order8_replay.log
diff -u small/order8.csv order8_replay.csv
diff -u small/order8.log order8_replay.log
~~~

Szybki audyt odtwarza także ujemny wyznacznik dla pierwszej całki w t = 5/64 i 86 domkniętych przedziałów dla Ψ₂ wraz z resztami Taylora. Największa granica wynosi 823252099/10⁹. Część 2.3 zawiera dowód dla przedziału zwartego, a część 2.4 dowód dla ogona. Powyższe polecenia pozwalają osobno porównać tabelę i protokół.

### Independent check for Φ / Dodatkowy rachunek dla Φ

Run `python small/check_phi4_direct.py` to check orders 1–4 on 52 cells spanning 3 ≤ X ≤ 16. Write z = exp(4s)−1, w = exp(4h)−1 in the bivariate Taylor series of Φ(t+s+h). As in the tail lemma, extracting positive-at-zero separable factors preserves the signs of leading determinants. With q = n² the residual summand is

```
q [2qX(1+z)(1+w)−3] exp[−(q−1)X(1+z+w)−qXzw].
```

The program evaluates the coefficients for n ≤ 7 and uses the permutation expansion for each leading determinant. On |z|,|w| ≤ 1/32 the modulus of the nth term for n ≥ 8 is at most 40n⁴ exp[−0.9(n²−1)X]. Cauchy's estimate for degrees up to 3 in each variable multiplies the tail by at most 32⁶. Successive majorants have ratio below 1/2, so its sum is at most 2·32⁶·40·8⁴ exp(−0.9·63·3) < 10⁻⁵⁵.

W tym dodatkowym teście program wylicza bezpośrednio współczynniki powyższego rozwinięcia w dwóch zmiennych. Dla n ≤ 7 sumuje je z zaokrągleniem na zewnątrz, po czym poszerza każdy wpis o 10⁻⁵⁵ w obie strony na podstawie oszacowania Cauchy’ego. Wzór permutacyjny sprawdza znaki na 52 przylegających komórkach dla 3 ≤ X ≤ 16. Pozostały zakres X ≥ 16 obejmuje lemat 2.2.

## Full computation / Pełny rachunek

~~~sh
sh historical32/regenerate.sh
python upper/sprawdz.py
(cd rank500 && sh build.sh)
python rank500/check_witness.py --rank 142
python rank500/check_witness.py --rank 500
python determinants/check_constants.py
~~~


Each witness run creates an empty directory and recomputes its moments. At rank 142 and t = 0 the expected codes are 142 at level 196 and 0 at level 197. At rank 500 and t = 15/8192 they are 500 at level 767 and 0 at level 768. A positive code identifies the first wrong sign. Zero means all requested signs passed at the given point. These runs require C++17 on GNU/Linux LP64, OpenMP, GMP/GMPXX and MPFR 4.

Każdy test świadka tworzy pusty katalog i od początku oblicza momenty. Dla rzędu 142 w zerze kody wynoszą 142 na poziomie 196 i 0 na poziomie 197. Dla rzędu 500 w punkcie 15/8192 wynoszą 500 na poziomie 767 i 0 na poziomie 768. Kod dodatni podaje pierwszy niewłaściwy znak, a zero potwierdza wszystkie wymagane znaki w tym punkcie. Polecenia dla siatek są w `rank500/README.md`.

## Scope of verification / Zakres weryfikacji

The archive includes the three compact certificates and the two point witnesses of section 5. The archive also contains the seven intermediate-rank runs from the upper-bound calculation and the original and regenerated tables for 10,919 historical cells. The quick audit checks their coverage, the maxima in the seven archived runs and the scalar inequalities of Appendix C. The commands above regenerate the numerical evidence. The order-five Lean sources concern an earlier proof on the compact interval. Section 5 gives the scope of the two point witnesses.

Archiwum zawiera trzy certyfikaty na przedziale zwartym oraz oba świadki punktowe z rozdziału 5. Archiwum zawiera siedem wcześniejszych przebiegów dla rzędów pośrednich oraz pierwotne i odtworzone tabele dla 10 919 komórek. Szybki audyt sprawdza ich pokrycie, maksima w siedmiu protokołach i stałe z dodatku C. Powyższe polecenia pozwalają powtórzyć obliczenia. Źródła Lean dotyczą wcześniejszego dowodu rzędu piątego na przedziale zwartym. Zakres obu świadków punktowych omawia rozdział 5.

The original upper-bound and rank-500 archives are preserved byte-for-byte in **original_packages**. Their earlier notes and logs predate the full historical replay and the new order-seven certificate. The main results can be reproduced without access to the earlier conversation or the private historical Lean repository.

Pierwotne archiwa granicy górnej i rzędu 500 zachowano bez zmian w **original_packages**. Pochodzą sprzed pełnego odtworzenia starszych komórek i nowego certyfikatu dla rzędu siedem. Główne wyniki można odtworzyć bez dostępu do rozmowy i prywatnego historycznego repozytorium Lean.

The revised sector checker uses 4.896 from Bellotti--Trudgian--Yang. It checks
both ends of the cutoff calculation for order 9,561,277,002,984. The historical
derivations in the nested archives document earlier bounds.
The quick audit validates the accepted blocks and their maxima in the seven saved
runs. Appendix B gives the commands for fresh computations.

Po zmianie stałej sektorowej na 4,896 skrypt sprawdza obie nierówności
wyznaczające rząd 9 561 277 002 984. W zagnieżdżonych archiwach zachowano
wcześniejsze wyprowadzenia. Szybki audyt kontroluje zaakceptowane bloki i ich
maksima w siedmiu zapisanych przebiegach. Polecenia do ponownego wykonania
obliczeń podano w dodatku B.

For the sector estimate, the verifier uses the full published zero height 3,000,175,332,800. The phase estimate uses the round height 3,000,000,000,000. For the strict-gap bound, Platt and Trudgian count 12,363,153,437,138 verified zeros, so the last shift with both required ordinates in range is 12,363,153,437,137. For the density of gap endpoints, the checker compares the fraction in Knausgård’s Theorem 1.3 with 0.6735. For Appendix C.5 the verifier checks that Sra's cited order 1,810,540,931,075 lies inside the sector range. The proof for arbitrary moment order uses Sra's Theorem 1.2 and the integral identity in the paper.

W rachunku sektorowym weryfikator wykorzystuje pełną opublikowaną wysokość 3 000 175 332 800. Dla oszacowania fazy przyjmuje wysokość 3 000 000 000 000. W oszacowaniu ścisłych luk liczba 12 363 153 437 138 zer zweryfikowanych przez Platta i Trudgiana daje ostatnie przesunięcie 12 363 153 437 137, przy którym obie potrzebne wysokości leżą w zweryfikowanym zakresie. Dla gęstości indeksów końcowych weryfikator porównuje ułamek z twierdzenia 1.3 Knausgårda z liczbą 0,6735. W dodatku C.5 sprawdzana liczbowo jest relacja między rzędem 1 810 540 931 075 z twierdzenia Sry a granicą sektorową. Dowód dla dowolnego rzędu wyznacznika opiera się na twierdzeniu 1.2 Sry i tożsamości całkowej podanej w pracy.
