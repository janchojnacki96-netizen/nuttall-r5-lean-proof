# Podwójne skalowanie liczby całkowań jądra Riemanna

## Wynik dla pełnego jądra

Piszemy \(X=\pi e^{4t}\), \(\epsilon_p=(-1)^{p(p-1)/2}\). Liczba \(m(r)\) oznacza minimalną liczbę całkowań ogonowych potrzebną do regularności \(RR_r\), a znaki wrońskianów sprawdzamy w ścisłej postaci z pytania. W tej nocie wyprowadzono
\[
 \epsilon_p W_p(\Psi_m;t)>0\qquad
 \bigl(r\ge2,\quad r+1\le m\le2r,\quad 1\le p\le r,\quad X\ge10r\bigr).
 \tag{1}
\]
Dla modelu z samym pierwszym składnikiem theta poziom \(m=r+1\) wystarcza na **całej** półosi dla dostatecznie dużego \(r\). Dla pełnego jądra i każdego \(1<c<2\) w reprezentacji Andréiefa przy \(m=\lfloor cr\rfloor\) istnieje rząd \(p\le r\), dla którego funkcja podcałkowa przybiera wartości obu znaków już przy pierwszym progu theta. W §2 wyznaczono granicę logarytmu normy pomocniczej macierzy w tym skalowaniu.

Nie udało się ustalić istnienia ani wartości \(\lim m(r)/r\). W szczególności żaden z tych wyników nie daje globalnego \(\limsup<2\) ani \(\liminf>1\). Poniższe dowody częściowe są roboczymi argumentami matematycznymi, niezależnymi od RH. Wynik (1), granica dla modelu i zmiana znaku funkcji podcałkowej nie zakładają wcześniejszych globalnych ograniczeń na \(m(r)\).

## 1. Tożsamość poniżej poziomu \(2r\)

Niech \(p\ge2,\ L=m-p\ge1,\ a_n=\tfrac12\log n\). Dla \(j\ge1\) połóżmy
\[
 f_j(v)=v^{j-1}/(j-1)!-v^j/j!,\qquad
 R_j(u)=\sum_{n:\ a_n<u}n^{-1/2}f_j(u-a_n).
\]
Wartość na samym progu można zmienić pod całką. Podpisany wrońskian ma znak całki z
\[
 I(\boldsymbol u)=
 \det[R_{L+j}(u_i)]_{1\le i\le p,\,0\le j<p}
 \Delta(e^{4u_1},\ldots,e^{4u_p})\prod_i e^{5u_i-Xe^{4u_i}}
 \tag{2}
\]
po dodatniej ortancie, gdzie \(\Delta(z)=\prod_{i<j}(z_j-z_i)\). Funkcja \(I\) jest symetryczna.

Warto sprawdzić dokładną dziedzinę tej tożsamości. Dla \(g(t)=\sum_n e^t x_n e^{-x_n}\) mamy \(2\Phi=-(g'+g)\). Po odwróceniu kolejności wierszy w wyznaczniku \(\Psi_m^{(i+j)}\) przywracamy znak przez \(\epsilon_p\). Wyłączenie znaków \((-1)^j\) z kolumn i odpowiadających im znaków z wierszy daje macierz, której wpis ma reprezentację
\[
 \frac{1}{2(L+i)!}\int_0^\infty s^{L+i-1}(L+i-s)(-1)^j g^{(j)}(t+s)\,ds .
\]
Istotnie zaczynamy od \(2\Psi^\Phi_{L+1+i}=\Psi^g_{L+i}-\Psi^g_{L+1+i}\) i różniczkujemy pod całką. Uzasadnia to wzór także wtedy, gdy pochodna rzędu \(j\) przekracza liczbę całkowań w danej pozycji. Wystarcza \(L+i\ge1\). Zanik podwójnie wykładniczy w \(s\) i gaussowski w indeksie \(n\) uzasadniają te operacje dla każdego ustalonego \(m,p,t\). W tożsamości Andréiefa pochodne pojedynczego składnika dają, po wyjęciu dodatniej wagi, wielomiany stopnia \(j\) w \(n^2 e^{4s}\) z dodatnimi współczynnikami wiodącymi. Ich wyznacznik to dodatnia stała razy Vandermonde. Zamiana \(u=s+a_n\) daje (2).

Jeżeli wszystkie węzły są poniżej \(a=a_2=\log(2)/2\), zostaje jedna funkcja \(f\) w każdej kolumnie. Dla uporządkowanych dodatnich węzłów mamy dokładnie
\[
 \det[f_{L+j}(u_i)]
  =\frac{\prod_i u_i^{L-1}\Delta(u)}{\prod_{j=0}^{p-1}(L+j)!}\,
    P_{p,L}(\boldsymbol u),\qquad
 P_{p,L}(\boldsymbol u)=\mathbb E\prod_{i=1}^p(Y-u_i),\quad
 Y\sim\mathrm{Gamma}(L,1).
 \tag{3}
\]
Po wyłączeniu potęg i silni kolumnami są \(u_i^j(L+j-u_i)\). Wybranie wyższej potęgi w jednej kolumnie i niższej w następnej daje powtórzony wykładnik. Pozostałe wyznaczniki alternujące po podzieleniu przez \(\Delta\) dają kolejne wielomiany elementarnie symetryczne. Współczynniki są \((L)_k=\mathbb E Y^k\), co daje (3).

## 2. Granica spektralna macierzy przesunięcia

W najwyższym bloku przy \(p=r\) poprzedni dowód używa \(M=m-2\) oraz macierzy \(C_d\) o indeksach \(0\le i,j<r\), której wpisy są współczynnikami
\([1-wz-d(1-w)(1-z)]^M\), podzielonymi przez
\(\sqrt{\binom Mi\binom Mj}\). Rozpatrujemy granicę od \(d<1\) do \(d=1\). To prawa granica wielomianowej reprezentacji dla nowo aktywnego składnika; nie wymaga istnienia wysokich klasycznych pochodnych na progu. Przy \(m=\lfloor cr\rfloor,\ 1<c<2\) niech \(\alpha=2-c\). Zachodzi
\[
 \lim_{r\to\infty}\frac1r\log\|C_1\|_2
  =\max_{0\le x\le\alpha}
   \left\{x\log2+\frac{c+x}{2}
           H\!\left(\frac{2x}{c+x}\right)\right\}>0,
 \qquad H(z)=-z\log z-(1-z)\log(1-z).
 \tag{4}
\]
Stosujemy \(0\log0=0\). Maksimum występuje przy \(x=\min(2-c,c/\sqrt2)\). Jest to próg dla konkretnej macierzy pomocniczej.

**Dowód.** Dla \(d=1\) wielomian bazowy wynosi \(w+z-2wz\). Przy \(q=i+j-M\ge0\) mamy
\[
 |(C_1)_{ij}|=2^q\sqrt{\binom iq\binom jq}.
\]
Dla \(q<0\) wpis znika. Jest to bezpośredni wzór wielomianowy z \(M-i,M-j,q\) czynnikami trzech rodzajów. Przy ustalonym \(q\) iloczyn jest największy, gdy \(i,j\) są tak bliskie sobie, jak pozwala parzystość. Wynika to z malejących kolejnych ilorazów \(\binom{n+1}{q}/\binom nq\). Wszystkie \(0\le q\le2r-m\) dopuszczają taki wybór. Norma jest między największym modułem wpisu a \(r\) razy tym modułem. Jednostajne oszacowanie \(\log\binom nk=nH(k/n)+O(\log(n+1))\), również na krańcach, daje (4) po wzięciu \(x=q/r\). Pochodna funkcji maksymalizowanej we wnętrzu ma postać \(\log(\sqrt{c^2-x^2}/x)\). W szczególności już ostatni wpis ma moduł \(2^{2r-m}\binom{r-1}{2r-m}\). Przy \(m=2r\) ma moduł 1, a przy \(m=2r-1\) ma moduł \(2(r-1)\). Dla \(1<c<2\) rośnie wykładniczo. Używanie wprost małej normy tego składnika w dawnych współrzędnych jest niemożliwe.

## 3. Rzeczywista zmiana znaku pod całką przy \(1<c<2\)

Dla parzystego \(p\ge4\) i \(1\le L<p\) istnieją otwarte zbiory uporządkowanych węzłów dowolnie blisko \((a,\ldots,a)\), na których (2) jest ujemne. Węzły pozostają poniżej \(a_3\), więc wystarczają dokładnie dwa pierwsze składniki theta. Na otwartym zbiorze węzłów poniżej \(a\) funkcja jest dodatnia.

Aby to zobaczyć, weźmy \(u_i=a+\varepsilon v_i\), przy ustalonych \(v_1<\dots<v_{p-1}<0<v_p\). Zmienia się wyłącznie ostatni wiersz macierzy z (3). Nieprzesunięty wyznacznik jest \(O(\varepsilon^{p(p-1)/2})\). Poprawka w kolumnie \(j\), numerowanej od zera, ma rząd \(O(\varepsilon^{L+j-1})\), a jej minor jest \(O(\varepsilon^{(p-1)(p-2)/2})\), ponieważ jest alternującym wielomianem w pierwszych \(p-1\) węzłach. Dla \(j=0\) współczynnik wiodący poprawki jest ściśle dodatni, a jej minor ma po podzieleniu przez wskazaną potęgę ściśle dodatnią granicę. Rzeczywiście (3) dla minora stosuje się z \(p-1,L+1\), a \(\mathbb E(Y-a)^{p-1}>0\). Dla \(Y\sim\mathrm{Gamma}(L+1,1)\) dodatnią część można ograniczyć od dołu przez \(e^{-2}(2-a)^{p-1}\), a ujemną z góry przez \(a^{p-1}\). Pierwsza jest większa.

Znak dopełnienia algebraicznego w kolumnie \(j=0\) wynosi \((-1)^{p+1}=-1\). Zatem dla \(A>0\), przy ustalonych \(p,L,v\), wyznacznik w (2) jest równy
\[
 -A\varepsilon^{(p-1)(p-2)/2+L-1}
 +o\big(\varepsilon^{(p-1)(p-2)/2+L-1}\big).
\]
Wykładnik jest mniejszy od \(p(p-1)/2\), dokładnie dlatego, że \(L<p\). Dla \(L=1\) rozumujemy jednostronnie poza węzłem progowym. Dodatni zbiór po drugiej stronie otrzymujemy z (3) i tego samego oszacowania gammy. W skalowaniu \(m=\lfloor cr\rfloor\) wystarczy wybrać największy parzysty \(p\le r\); dla dużego \(r\) mamy \(1\le L=m-p<p\). Istnienie konfiguracji dla każdego takiego \(r\) nie wymaga jednostajnego promienia \(\varepsilon\).

**Kontrola konkretnego przypadku.** Dla \(p=4,m=7,v=(-3,-2,-1,1)\) i \(\varepsilon=10^{-8}\) bezpośredni rozwój 24 składników wyznacznika w arytmetyce przedziałowej daje
\[
 -2{,}475\cdot10^{-9}
 < \varepsilon^{-5}\det[R_{3+j}(u_i)]
 < -2{,}474\cdot10^{-9}.
\]
Sama zmiana znaku pod całką nie przesądza o jej znaku. Następny wynik dowodzi tego dla tej samej rodziny wrońskianów.

## 4. Dowód (1) dla całego jądra po \(r+1\) lub więcej całkowaniach

Dla \(p=1\) znak wynika z dodatniości \(\Phi\) na półosi. Ustalmy \(2\le p\le r\) i \(r+1\le m\le2r\). Na węzłach \(0<u_i<a\) zachodzi \(P_{p,L}>0\). Istotnie prawdopodobieństwo \(Y\ge2\) jest co najmniej \(e^{-2}\) dla całkowitego \(L\ge1\), a ewentualny ujemny wkład ma moduł najwyżej \(a^p\). Mamy \(e^{-2}(2-a)^p>a^p\) dla \(p\ge2\). Dlatego składnik centralny (2) jest dodatni prawie wszędzie na sześcianie \((0,a)^p\).

Aby porównać go z resztą, ustalmy wszystkie węzły poza jednym. Z dokładnością do wspólnego czynnika funkcja jednej zmiennej w module ma postać
\[
 |f(u)|\prod_{j=1}^{p-1}|e^{4u}-e^{4v_j}|e^{5u-Xe^{4u}},
 \qquad f(u)=\sum_{j=0}^{p-1}c_j R_{L+j}(u).
\]
Zapiszmy \(b_j=c_j/(L+j)!\), \(F=\max|b_j|\), \(H_0=F\prod_j(1+e^{4v_j})\). Jeżeli \(F=0\), obie porównywane całki znikają. Na \(J=[0,1/4]\) mamy \(f(u)=u^{L-1}Q(u)\), gdzie \(Q(u)=\sum b_j u^j(L+j-u)\). Przynajmniej jeden współczynnik \(Q\) ma moduł \(\ge F\). Dla indeksu maksymalnego modułu wystarcza \((L+j)b_j-b_{j-1}\); gdy \(j=0\), współczynnik ma moduł \(L|b_0|\). Argument obejmuje \(L=1\).

Średnia logarytmu \(u\) na \(J\) jest \(-1-\log4\). Jeśli \(Q=A\prod(u-z)\), to \(|A|\prod(1+|z|)\ge F\). Średnia logarytmu \(|u-z|/(1+|z|)\) jest co najmniej \(-1-\log16\) dla każdego \(z\). Dla \(|z|\le1\) przesuwamy \(\Re z\) do środka przedziału, gdzie średnia logarytmu odległości jest najmniejsza, i dzielimy przez 2. Dla \(|z|>1\) wystarcza jednostajna dolna granica \(3/8\). Analogicznie \(|e^{4u}-e^{4v}|/(1+e^{4v})\ge \min(|u-v|,1/4)\), a średnia logarytmu prawej strony wynosi co najmniej \(-1-\log8\). Przez nierówność Jensena i \(L+p\le2r\) całka modułu po \(J\) jest co najmniej
\[
 \frac{H_0}{4}e^{-10r-e X}.
 \tag{5}
\]
Użyto \((L-1)(1+\log4)+p(1+\log16)+(p-1)(1+\log8)<10r\).

Dla \(u\ge a\), z \(\sum_{n\le e^{2u}}n^{-1/2}\le2e^u\) otrzymujemy \(|f(u)|\le2e^u pF(m+u)\max(1,u)^m\). Pozostałe czynniki Vandermonde’a po podzieleniu przez \(\prod(1+e^{4v_j})\) są najwyżej \(e^{4(p-1)u}\). Mamy \(\max(1,u)^m\le e^{m(u-a)}\), \(m+u\le(m+a)e^{u-a}\), a \(e^{4u}\ge 4+16(u-a)\). Po scałkowaniu od \(a\) i podzieleniu przez (5) stosunek całki ogonowej do całki po \(J\) jest co najwyżej
\[
 \eta=\frac{8p(m+a)}{16X-(4p+3+m)}
       \exp\{10r+(4p+2)a-(4-e)X\}.
 \tag{6}
\]
Dla \(X\ge10r,\ r\ge2\) mianownik przekracza \(150r\), \(m+a<2{,}2r\), a \(10(4-e)-10-4a>1{,}4\). Wynika stąd \(p\eta<0{,}24r^2e^{-1{,}4r}<1/2\). Nierówność jest jednostajna względem pozostałych węzłów. Sumując ją po wyborach współrzędnej i całkując, dostajemy \(\int_{\max u_i\ge a}|I|\le p\eta\int|I|\). Zatem \(\int I\ge(1-2p\eta)\int|I|>0\). Dowodzi to (1), łącznie z węzłami arbitralnie bliskimi sobie. W szczególności potencjalne naruszenie znaków przy \(m=\lfloor cr\rfloor,\ 1<c<2\) dla dużych \(r\) musi mieć miejsce przy \(0\le t<\tfrac14\log(10r/\pi)\).

## 5. Model z samym pierwszym składnikiem theta

Niech \(m_1(r)\) oznacza minimum dla \(\Phi_1(t)=e^t x_1(2x_1-3)e^{-x_1}\). Udowodnimy \(m_1(r)\le r+1\) dla wszystkich dostatecznie dużych \(r\). W (2) występuje teraz sam wyznacznik z (3) na **wszystkich** węzłach. Ustalmy \(m=r+1,\ B=\log r\), \(p\ge2\). Na sześcianie \(u_i\le B\) ujemna część iloczynu w definicji \(P_{p,L}\) ma moduł co najwyżej \(B^p\). Gdy \(p\ge6B\), zdarzenie \(Y\ge3B\) ma prawdopodobieństwo \(\ge e^{-3B}\), a jego dodatni wkład \(\ge e^{-3B}(2B)^p>B^p\). Gdy \(p<6B\), mamy \(L=r+1-p\ge10B\) dla dużych \(r\). Przez nierówność Paleya–Zygmunda \(\Pr(Y\ge L/2)\ge L/[4(L+1)]\ge1/8\). Wkład dodatni wynosi wtedy co najmniej \((4B)^p/8>B^p\).

Dla \(u\ge B\ge1\) dowód (6) działa po zastąpieniu \(\max(1,u)^m\) przez \(B^m e^{m(u-B)/B}\). Stosunek do (5) jest najwyżej
\[
 \frac{8p(m+B) B^m}{4X e^{4B}-(4p+3+m/B)}
 \exp\{10r+(4p+2)B-X(e^{4B}-e)\}.
\]
Ponieważ \(e^{4B}=r^4\), \(X\ge\pi\), \(m=r+1\) i \(p\le r\), już po pomnożeniu przez \(p\) prawa strona zmierza do zera jednostajnie w \(p,X\). Daje to dodatni znak po scałkowaniu. W szczególności \(\limsup m_1(r)/r\le1\). Dla tego modelu nie używamy dolnej granicy pełnego jądra opartej na wielu rozdzielonych składnikach theta.

## 6. Audyt wcześniejszych granic i kwestia istnienia granicy

- **Dolna granica.** W poprzednim dowodzie z \(RR_r\) uzyskuje się \(S(\Psi_m^{(j)})\le j\) dla \(j\le r-1\), gdzie \(S\) liczy ścisłe zmiany znaku. Wybór \(j=r-1,\ k=r-1-m\) oraz dolna granica na \(S(\Phi^{(k)})\) wykluczają wskazany poziom \(m\). Na kolejnych rozłącznych przedziałach argument siodłowy porównuje błąd **bezwzględny** z amplitudą w punktach, gdzie kosinus wynosi \(\pm1\). Nie wymaga względnej dokładności w pobliżu zer. W późniejszej nocie poszerzenie zakresu do \(n\le\sqrt{k}/\log k\) daje \(m(r)\ge r-Cr/\log r\) dla dowolnego \(C>\pi^2/2\), asymptotycznie. Przy \(m\ge r-1\) wszystkie testowane w tym argumencie funkcje mają stały znak, bo \((-1)^j\Psi_m^{(j)}=\Psi_{m-j}>0\) na półosi. Nawet lepsze oszacowanie liczby oscylacji \(\Phi^{(k)}\) w tej samej metodzie nie da współczynnika większego od 1.
- **Górna granica.** Analityczna nota dla \(m-2r\ge8\log^2m\) daje \(\limsup m(r)/r\le2\) niezależnie od skończonych tabel. Druga nota analityczna obejmuje dokładny poziom \(2r\) od \(r=10^{11}\). W pakiecie dla całego zakresu wykonałem oryginalny program sprawdzający. Siedem etapów dla \(33\le r<10^{11}\) zakończyło się powodzeniem. Dla \(r\le32\) ponownie sprawdzono pokrycie i zapisane granice 459, 1845 oraz 8615 komórek. Generatorów tych trzech starych tabel nie uruchamiano ponownie. Tekst wyodrębniony z obu kopii PDF o \(2r\) jest identyczny. To kontrola wyprowadzenia i powtórzenie wskazanych obliczeń, bez niezależnej formalizacji.
- **Istnienie granicy.** Przy wcześniejszych dowodach roboczych \(1\le\liminf m(r)/r\le\limsup m(r)/r\le2\). Monotoniczność \(m(r)\) tego nie poprawia. Przykładowo niemalejący ciąg \(2^{\lfloor\log_2 r\rfloor+1}\) mieści się w \([r,2r]\) i ma dwa różne skrajne punkty skupienia ilorazu przez \(r\), równe 1 i 2. To przykład logiczny, nie model dla jądra. Nie wyprowadzono subaddytywności ani innej relacji, która zmuszałaby oba krańce do równości.
- **Pozostała luka.** Dla każdego ustalonego \(1<c<2\) należałoby kontrolować podpisaną całkę (2) przy \(m=\lfloor cr\rfloor\), wszystkich potrzebnych \(p\), i \(\pi\le X<10r\), bądź wykazać niedodatniość odpowiedniego wrońskianu. W tym przedziale prawdziwa jest tożsamość (2), ale zawodzi punktowe kryterium poprzedniego dowodu, co wykazuje §3. Brak ilościowego porównania dodatniej i ujemnej masy. Sama obecność obszaru ujemnego nie daje dolnej granicy na \(m(r)\). Dodatniość całki dla jednego składnika i ustalenie granicy (4) również nie rozstrzygają między \(c=1,\ 1<c<2,\ c=2\) i brakiem granicy dla całego jądra.

[Dolna granica](https://chatgpt.com/library?file_id=libfile_4802a1b66a3081919f6906fab8cb984e&account_id=personal) · [Wzmocnienie ze stałą \(\pi^2/2\)](https://chatgpt.com/library?file_id=libfile_fde3_f-8fd176cd67a081918065c817f2d570bc_190e0645021881919deeacf23c4a3be0&account_id=personal) · [Dowód \(2r\) i dane do powtórzenia kontroli](https://chatgpt.com/library?file_id=libfile_fde3_f-b512d8842f1c81918f55d0784ab3d2b3_190e0645021881919deeacf23c4a3be0&account_id=personal) · [J. Nuttall, kryterium wrońskianowe, trwałość regularności i obliczenia](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf)
