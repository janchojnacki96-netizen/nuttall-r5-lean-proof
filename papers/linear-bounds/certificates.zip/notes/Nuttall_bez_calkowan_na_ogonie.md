# Pełne jądro Nuttalla bez całkowania na końcowej części półosi

Niech $X=\pi e^{4t}$ i $\epsilon_p=(-1)^{p(p-1)/2}$. Dla każdego $r\ge1024$ przy $X\ge5r/4$ zachodzi
\[
 \epsilon_p W_p(\Phi;t)>0\qquad(1\le p\le r).
\]
Ogólniej, dla każdej stałej $\lambda>8\log(4)/9$ te same znaki zachodzą przy $X\ge\lambda r$ od pewnego $r_0(\lambda)$. Dowód nie zakłada RH ani globalnego oszacowania $m(r)$. Stała jest progiem wystarczającym dla poniższego oszacowania.

## 1. Zmiana zmiennych w macierzy pochodnych

Rozważmy jądro $\Phi(t+s+h)$ i nowe współrzędne $u=\sqrt X(e^{4s}-1)$, $v=\sqrt X(e^{4h}-1)$. Piszmy $A(u)=1+u/\sqrt X$, $q=n^2$, $d=q-1$. Po podzieleniu przez wspólny dodatni w zerze czynnik $X e^t e^{s+h}A(u)A(v)e^{-X-\sqrt X(u+v)}$ otrzymujemy jądro analityczne w otoczeniu zera
\[
 \sum_{n\ge1}q e^{-dX}(2qX A(u)A(v)-3)
       e^{-d\sqrt X(u+v)}e^{-quv}.
\]
Wydzielony czynnik rozdziela się na iloczyn funkcji jednej zmiennej i dodatniej stałej. Zmiana zmiennych ma dodatnie pochodne w zerze. Zatem znak wrońskianu jest równy znakowi wyznacznika początkowego bloku współczynników Taylora powyższego jądra, po pomnożeniu wpisów $[u^iv^j]$ przez $\sqrt{i!j!}$. Operacje te to mnożenia macierzy przez trójkątne macierze o dodatnich przekątnych. Wszystkie szeregi można różniczkować lokalnie dla ustalonego $p,X$, bo na dostatecznie małym zespolonym otoczeniu $\Re(A(u)A(v))>1/2$.

W bazie $u^i/\sqrt{i!}$, $0\le i<p$, mnożenie przez $u$ reprezentuje dolne przesunięcie $S_{i,i-1}=\sqrt i$. Mnożenie i obcinanie do stopni poniżej $p$ jest dokładne, ponieważ wyższe stopnie nigdy nie wpływają na niższe. Połóżmy $P=I+S/\sqrt X$, $J=\mathrm{diag}((-1)^i)$, $D=\mathrm{diag}(q^{i/2})$, $T=e^{-d\sqrt X S}D$. Macierz wkładu $n$ to
\[
 B_n=q e^{-dX}(2qX P T J T^\top P^\top-3TJT^\top).
\]
Mamy $\det J=\epsilon_p$, zatem wystarczy wykazać dodatniość wyznacznika $(\sum B_n)J$.

## 2. Minimalny margines dla n=1

Przy $q=1$ mamy $T=I$ oraz
\[
 B_1J=(2X-3)I+2\sqrt X(S-S^\top)-2SS^\top .
\]
Część symetryczna jest diagonalna, z najmniejszym wpisem $2X-3-2(p-1)$. Jeżeli suma norm dalszych składników jest mniejsza od tej granicy, część symetryczna całej sumy po pomnożeniu przez $J$ jest dodatnio określona. Każda rzeczywista macierz o dodatnio określonej części symetrycznej ma dodatni wyznacznik: odcinek łączący ją z identycznością składa się z macierzy nieosobliwych.

## 3. Oszacowanie wszystkich dalszych składników

Kwadrat normy euklidesowej wiersza $i$ macierzy $T$ jest równy
\[
 q^i L_i(-d^2 X/q),\qquad L_i(-y)=\sum_{j=0}^i\binom ij y^j/j!.
\]
Wynika to z rozwinięcia wykładnika nilpotentnej macierzy $S$. Dla $0<z<1$ mamy
\[
 \sum_{i\ge0} z^i L_i(-y)=\frac1{1-z}\exp\big(yz/(1-z)\big),
\]
przez zamianę dwóch dodatnich sum. W szczególności, ograniczając kwadrat normy operatorowej przez sumę kwadratów wierszy i korzystając z $q^i\le q^{2(p-1)}q^{-i}$ dla $i<p$, otrzymujemy dla $q\ge4$
\[
 e^{-dX}\|T\|^2
 \le \frac{q^{2(p-1)}}{1-1/q}\exp[-(q-1)^2 X/q].
\]
Tutaj podstawiliśmy $z=1/q$ w szeregu. Ponieważ $\|P\|\le1+\sqrt{r/X}$, wynika
\[
 \|B_n\|\le \frac{q(2qX(1+\sqrt{r/X})^2+3)}{1-1/q}
             \exp[2r\log q-b(q)X],\qquad b(q)=(q-1)^2/q.
\]
Funkcja $2\log q/b(q)$ maleje dla $q\ge4$. Znak pochodnej jest znakiem $(q-1)-(q+1)\log q<0$. Jej maksimum to $\lambda_0=8\log4/9$. Stąd dla $X\ge\lambda r$, $\lambda>\lambda_0$, wykładnik jest co najwyżej $-(1-\lambda_0/\lambda)b(q)X$. Mamy $b(q)\ge9q/16$. Suma granic norm jest zatem $o(X)$ jednostajnie w $p\le r$ i $X\ge\lambda r$, gdy $r\to\infty$: po podzieleniu przez $X$ majoryzuje ją stała razy $\sum_{n\ge2} n^4\exp[-c_\lambda n^2 X]$, która dąży do zera. Najmniejszy wpis z części 2 jest co najmniej $2(1-1/\lambda)X-1$. Dowodzi to tezy asymptotycznej.

Dla $\lambda=5/4$ mamy $(1-\lambda_0/\lambda)9/16>1/128$ (wystarcza $\log4<1.3863$). Jeśli $r\ge1024$, to $X\ge1280$ i otrzymujemy
\[
 \sum_{n\ge2}\|B_n\|/X\le16\sum_{n\ge2}n^4e^{-10n^2}<1/100.
\]
Ostatnia granica wynika z wyrazu $16e^{-40}$ szeregu i ilorazu kolejnych wyrazów co najwyżej $(3/2)^4 e^{-50}<1/2$. Część symetryczna z części 2 ma dolną granicę $0.4X-1>X/100$. Kończy to dowód dla wszystkich podanych skończonych parametrów.

## 4. Znaczenie dla globalnej liczby całkowań

Ścisłe znaki wszystkich początkowych wrońskianów na $[T,\infty)$ utrzymują się przy każdym kolejnym całkowaniu ogonowym na tym przedziale. Krótki argument: dla $f(t)=\int_t^\infty g(s)ds$ w macierzy wrońskianu pierwszy wiersz jest całką z wiersza $(g(s),\ldots,g^{(p-1)}(s))$. Pozostałe wiersze są ujemnymi wierszami pochodnych $g$ w $t$. Przeniesienie pierwszego wiersza na koniec usuwa minusy. W podcałkowym wyznaczniku $p-1$ węzłów zlewa się w $t$, a ostatnim jest $s>t$. Jego znak przy $s\downarrow t$ wyznacza wrońskian rzędu $p$ funkcji $g$. Nie może on zniknąć dla $s>t$, gdyż niezerowe początkowe wrońskiany funkcji $g,\dots,g^{(p-1)}$ zapewniają własność rozszerzonego układu Czebyszewa. Własność ta wynika przez kolejne dzielenie przez pierwszą funkcję, różniczkowanie i twierdzenie Rolle’a z krotnościami. Całka ma więc właściwy ścisły znak.

W konsekwencji przy próbie globalnego $m=\lfloor1.98r\rfloor$ pozostaje $X<5r/4$ dla $r\ge1024$. Jeżeli przyjmuje się ponadto wcześniejszy roboczy globalny wynik o ścisłych znakach na poziomie $2p$, pozostają tylko $\lfloor0.99r\rfloor<p\le r$. W szczególności dla $r=8000$ otwarty zakres tej próby obejmuje rzędy 7921–8000 na $0\le t<\tfrac14\log(10000/\pi)$. Żaden z dowodów tej noty nie ustanawia globalnej granicy mniejszej od $2r$.
