# Nieparzyste momenty i znak wrońskianu przy \(m=2r-1\)

Niech \(a_n(t)=\Psi_{n+1}(t)=\int_0^\infty u^n\Phi(t+u)\,du/n!\), \(H_r(t)=[a_{i+j}(t)]_{0\le i,j<r}\) oraz \(\epsilon_p=(-1)^{p(p-1)/2}\). Odwracając oba porządki indeksów w macierzy pochodnych, otrzymujemy \(W_r(\Psi_{2r-1};t)=\det H_r(t)\). Dla tego samego poziomu całkowania wrońskian rzędu \(p<r\) jest wyznacznikiem końcowego bloku głównego rozmiaru \(p\) macierzy \(H_r(t)\). Czynniki \((-1)^{i+j}\) usuwają się przez jednoczesną zmianę znaków wierszy i kolumn.

## 1. Skąd biorą się momenty nieparzyste

Piszmy \(F(s)=\int_0^\infty\Phi(u)\cos(su)du=\xi(1/2+is/2)/8\). W porównaniu z notą o zerach argumentem jest teraz częstotliwość \(s\), a w poprzedniej nocie był nim jej kwadrat. Przy \(t=0\) klasyczny wzór na absolutne momenty rozkładu zastosowany do parzystego przedłużenia jądra daje
\[
 a_{2k+1}(0)=\frac{2}{\pi}(-1)^{k+1}
 \int_0^\infty
 \frac{F(s)-\sum_{j=0}^k(-1)^j a_{2j}(0)s^{2j}}{s^{2k+2}}\,ds.
\]
W szczególności \(a_1(0)=(2/\pi)\int_0^\infty(a_0(0)-F(s))s^{-2}ds\). Wszystkie momenty nieparzyste zależą więc od tej samej transformaty, której zera wykorzystywaliśmy wcześniej. Do wzoru wchodzą wartości między zerami. Znak i normalizację można sprawdzić na pojedynczym \(\cos(su)\): reszta po obcięciu ma stały znak po \(2k\)-krotnym całkowaniu \(1-\cos\), a \(2k\) całkowań przez części sprowadza wyraz do całki \(\int_0^\infty(1-\cos v)v^{-2}dv=\pi/2\) z czynnikiem \(1/(2k+1)!\). Potem stosujemy Tonellego. [Brown, wzór Hsu i von Bahra](https://doi.org/10.1017/S1446788700010648) · [Rodgers i Tao, wzory (1)–(3)](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/D4B85BA067E2D5A71D87E4FFB0D21E46/S2050508620000062a.pdf)

## 2. Oszacowanie dla wszystkich wektorów jednocześnie

Niech \(T=9632\), \(D=\operatorname{diag}(1,T,\ldots,T^{r-1})\), \(M_r(t)=D H_r(t)D\). Wprowadźmy rzeczywistą macierz symetryczną
\[
 (G_r(t))_{ij}=\frac{2e^{-2t}}{\pi}\Re\int_0^T
 \frac{F(s+2\mathrm i)e^{\mathrm i st}}{2-\mathrm i s}
 \left(\frac{T}{2-\mathrm i s}\right)^{i+j}ds.
\]
Litera \(\mathrm i\) oznacza jednostkę urojoną. Z równania funkcyjnego \(F(s+2\mathrm i)=\xi(3/2-\mathrm i s/2)/8\); tu szereg Dirichleta dla dzety jest bezwzględnie zbieżny. Wybór \(T\) jest bliski podwójnej wysokości zera \(4816{,}4517\ldots\) z poprzedniej noty. Samo oszacowanie obcięcia nie wymaga, by koniec przedziału był zerem.

**Twierdzenie.** Dla wszystkich całkowitych \(r\ge1\) i \(t\ge0\) zachodzi
\[
                    \|M_r(t)-G_r(t)\|_2<10^{-1625} e^{-2t}.
\]
W szczególności ogranicza to moduł błędu formy kwadratowej na każdym jednostkowym wektorze, w tym wektorze odpowiadającym najmniejszemu modułowi wartości własnej. Macierz \(H_r\) może mieć wartości własne obu znaków; interesuje nas liczba wartości ujemnych oraz odstęp widma od zera.

**Dowód.** Użycie pełnej prostej w całce zamiast \([-T,T]\) daje \(M_r\) dokładnie. Jest to odwrócenie Fouriera funkcji \(v\mapsto e^{2v}\Phi(v)\), o transformacie \(2F(s+2\mathrm i)\), a następnie całka z \(u^n e^{-(2-\mathrm i s)u}/n!\). Parzystość rzeczywistego jądra i elementarne oszacowania poniżej uzasadniają odwrócenie i zamianę całek.

Weźmy \(h=0{,}39\), \(c=\cos(4h)>0{,}01\). Szereg theta jest holomorficzny w \(|\Im v|<\pi/8\). Tożsamość \(\Phi(-v)=\Phi(v)\) przechodzi z rzeczywistej osi do pasa. W całce \(F(z)=\tfrac12\int_\mathbb R\Phi(v)e^{\mathrm i zv}dv\), przy \(z=s+2\mathrm i\), przesuwamy kontur o \(+\mathrm i h\) dla \(s>0\). Całki po pionowych bokach znikają przez podwójnie wykładniczy zanik, jednostajny na domkniętym podpasie. Ujemne \(s\) obejmuje sprzężenie. Otrzymujemy \(|F(s+2\mathrm i)|\le A e^{-h|s|}\), gdzie
\[
 A\le\int_0^\infty e^{2v}e^v\sum_{n\ge1}x_n(2x_n+3)e^{-cx_n}\,dv,
 \qquad x_n=\pi n^2e^{4v}.
\]
Aby podać jawną granicę, używamy \(e^{2v}\le(x_n/\pi)^{1/2}\), podstawiamy \(x=x_n\) i korzystamy z \(\sum_{n\le\sqrt{x/\pi}} n^{-1/2}\le2(x/\pi)^{1/4}\). Dostajemy
\[
 A\le\frac1{2\pi}\int_0^\infty x(2x+3)e^{-cx}dx
   =\frac{4c^{-3}+3c^{-2}}{2\pi}<642000.
\]

Dla \(n=i+j\) błąd wpisu ma zatem moduł co najwyżej
\[
 \frac{2Ae^{-2t}}\pi\int_T^\infty e^{-hs}(T/s)^n\frac{ds}{s}.
\]
Po podstawieniu \(x=T/s\) korzystamy z \(e^{-hT/x}\le x e^{-hT}\) dla \(0<x\le1\) i \(hT\ge1\). Wynika stąd granica \(2Ae^{-hT-2t}/[\pi(i+j+1)]\). Norma macierzy Hilberta \([1/(i+j+1)]\) jest co najwyżej \(\pi\), niezależnie od rozmiaru. Stosując tę nierówność do modułów współrzędnych wektorów, otrzymujemy \(\|M_r-G_r\|_2\le2Ae^{-hT-2t}<10^{-1625}e^{-2t}\). [Nierówność Hilberta dla normy operatora](https://eprints.lancs.ac.uk/136936/1/opineq.amm.pdf)

**Warunek wystarczający dla \(r=8000\).** Gdyby \(G_{8000}(0)\) miała dokładnie 4000 ujemnych wartości własnych i wszystkie wartości własne miały moduł większy od \(10^{-1625}\), nierówność Weyla i prawo bezwładności dałyby właściwy ścisły znak dla \(W_{8000}(\Psi_{15999};0)\). To warunek wystarczający. Dodatkowy błąd obliczenia skończonej całki również trzeba uwzględnić w marginesie. Sam rząd wielkości reszty Fouriera nie podaje wielkości najmniejszego modułu wartości własnej. Dla ogólnego \(r\) odpowiednia wystarczająca liczba ujemnych wartości wynosi \(\lfloor r/2\rfloor\). Przy innym skalowaniu macierzy należy również przeskalować oszacowanie błędu.

## 3. Niezależny test w punkcie \(t=0\)

W samym punkcie zero można uniknąć kwadratury oscylacyjnej. Obliczamy przedziały dla \(b_n=L^n a_n(0)\) do rzędu \(2R-2\), gdzie \(L=R\) jest maksymalnym sprawdzanym rzędem. To dodatnie skalowanie nie zmienia znaków minorów. Następnie w arytmetyce przedziałowej obliczamy wszystkie
\[
 d_{p,s}=\epsilon_p\det[b_{s+i+j}]_{i,j=0}^{p-1},
 \qquad p\le R,\quad 0\le s\le 2R-2p.
\]
Stosujemy tożsamość Desnanota–Jacobiego z warunkami początkowymi \(d_{0,s}=1,\ d_{1,s}=b_s\):
\[
 d_{p+1,s}
  =\frac{d_{p,s+1}^2-d_{p,s}d_{p,s+2}}{d_{p-1,s+2}}.
\]
Znak minus w liczniku po odwróceniu kolejności jest skutkiem \(\epsilon_{p+1}\epsilon_{p-1}=-\epsilon_p^2\). Każdy dzielnik ma wcześniej potwierdzoną dodatnią dolną granicę. Spośród tych liczb \(d_{p,2r-2p}\) daje znak dla \(W_p(\Psi_{2r-1};0)\).

**Kontrola błędów momentów.** Na \([0,2]\) stosujemy 32 segmenty długości \(1/16\) i dodatnią kwadraturę Fejéra typu pierwszego o \(N\) węzłach w każdym segmencie. Dla \(\theta_j=(2j+1)\pi/(2N)\) węzły na \([-1,1]\) to \(\cos\theta_j\), a wagi to
\[
 \frac2N\left(1-2\sum_{k=1}^{\lfloor(N-1)/2\rfloor}
                       \frac{\cos(2k\theta_j)}{4k^2-1}\right).
\]
Przez dyskretną ortogonalność cosinusów i całkowanie wielomianów Czebyszewa wzór jest dokładny do stopnia \(N-1\). Dodatniość wag wynika z \(\sum_{k=1}^K2/(4k^2-1)=1-1/(2K+1)\).

Na kole o promieniu \(1/4\) wokół środka każdego segmentu funkcja \(\Phi(z)(Lz)^j/j!\) ma moduł co najwyżej \(M=10000e^{9L/4}\). Istotnie \(|\arg x_n|\le1\), \(\Re x_n\ge |x_n|/2\), \(|x_n|\ge\pi n^2/e\) i \((2x^2+3x)e^{-x/4}<100\) dla \(x\ge0\); sumę \(\sum e^{-\pi n^2/(4e)}\) ogranicza 3. Połowa długości segmentu wynosi \(1/32\). Z oszacowania Cauchy’ego błąd przybliżenia wielomianem Taylora jest najwyżej \(M8^{-N}/(1-1/8)\). Dodatnia kwadratura i całka mają taką samą masę. Sumaryczny błąd jest mniejszy od \(5M8^{-N}\).

Na rzeczywistych węzłach wkład pominiętych wyrazów theta ogranicza szereg geometryczny, ponieważ \((2x^2+3x)e^{-x/8}<1000\) i \((k+1)^2-k^2\ge1\). Dla ogona \(u\ge2\) wystarcza \(\Phi\le2\phi_1\), \(\Phi'/\Phi\le13-4\pi e^{4u}\) i \((Lu)^j/j!\le e^{Lu}\). Dwie pierwsze nierówności wynikają z dodatniości składników, ich jawnej pochodnej i \(\phi_k/\phi_1\le2k^4e^{-(k^2-1)\pi e^{4u}}\). Kod uwzględnia sumę tego ogona, błąd kwadratury, obcięcie sumy theta i zaokrąglenia. Dodawanie wkładów węzłów do momentów odbywa się z jednostronnym zaokrągleniem na liczbach całkowitych. [Poprzednia nota o zerach i momentach](https://chatgpt.com/library?file_id=libfile_fde3_f-1e2ba484a9ac8191a12a7114d7c6fb92_190e0645021881919deeacf23c4a3be0&account_id=personal)

**Wynik obliczenia.** Przy \(R=160\) i \(N=520\) dolne końce przedziałów wszystkich \(160^2=25600\) badanych minorów są ściśle dodatnie. W szczególności
\[
 \epsilon_p W_p(\Psi_{2r-1};0)>0,\qquad 1\le p\le r\le160.
\]
Ten punktowy certyfikat korzysta z pełnego jądra theta i nie zakłada poprzedniego globalnego twierdzenia o \(2r\). Program podaje około \(2{,}743\cdot10^{-309}\) jako górne ograniczenie samego błędu kwadratury momentów po skalowaniu. Osobno dolicza pozostałe źródła błędu.

## 4. Próba dla rzędu 8000

W poprzedniej nocie wydzielony był ostatni wiersz. Korzystniej jest wydzielić pierwszy. Zapiszmy bez skalowania
\[
 H_r=\begin{pmatrix}a_0&b^\mathsf T\\ b&A\end{pmatrix},\qquad
 b=(a_1,\ldots,a_{r-1})^\mathsf T,\qquad
 A=[a_{i+j+2}]_{0\le i,j<r-1}.
\]
Wszystkie wielkości można rozpatrywać przy tym samym \(t\). Wyznacznik \(A\) jest dokładnie \(W_{r-1}(\Psi_{2r-1};t)\). Przy wcześniejszym roboczym wyniku dla poziomu \(2(r-1)\) i zachowaniu ścisłych znaków po jednym dodatkowym całkowaniu ma już znak \(\epsilon_{r-1}\). To jest jedyne miejsce, w którym używamy wcześniejszego globalnego wyniku. Dla \(r=8000\) potrzeba więc wykazać
\[
                        b^\mathsf T A^{-1}b>a_0 .
\]
Jeżeli \(x\) jest przybliżeniem rozwiązania \(Ax=b\), zaś \(v=b-Ax\), to dokładnie
\[
 b^\mathsf T A^{-1}b-a_0
 =2b^\mathsf T x-x^\mathsf T A x-a_0+v^\mathsf T A^{-1}v.
\]
Wystarczy zatem dodatnia dolna granica dla pierwszych trzech składników, przewyższająca \(\|v\|_2^2/\sigma_{\min}(A)\). W tej formule potrzebna jest najmniejsza wartość *singularna* macierzy symetrycznej \(A\). Jej wartości własne mogą mieć oba znaki. Tę samą procedurę można przeprowadzić na zgodnie przeskalowanych blokach macierzy \(M_r\). Wtedy oszacowanie z §2 działa w tej samej normie. Przybliżone rozwiązanie i certyfikat nierówności dla \(r=8000\) pozostają do wyznaczenia. Dla uzyskania globalnego oszczędzenia jednego całkowania potrzeba ponadto ciągłego przedziału \(t\) i nieograniczonego \(r\).

**Zmierzony margines.** Przy \(t=0\) dla kilku parzystych rzędów certyfikat obejmuje także względną różnicę \(g_r=(b^\mathsf T A^{-1}b-a_0)/a_0\). W obliczeniach jest ona równa \(d_{r,0}/(d_{r-1,2}b_0)\), gdzie \(b_0=L^0a_0\) jak w §3. Czynniki skali \(L\) w tym ilorazie znoszą się dokładnie.

| \(r\) | Ścisły przedział dla \(g_r\) |
|---:|---:|
| 16 | \((10^{-7},10^{-6})\) |
| 32 | \((10^{-11},10^{-10})\) |
| 64 | \((10^{-20},10^{-19})\) |
| 128 | \((10^{-35},10^{-34})\) |
| 160 | \((10^{-42},10^{-41})\) |

Wartości te mierzą różnicę w nierówności Schura. Nie są oszacowaniami najmniejszego modułu wartości własnej macierzy \(G_r\).

[Wcześniejsze uzasadnienie przejścia do jednej dodatkowej całki](https://chatgpt.com/library?file_id=libfile_fde3_f-b58fb0d8b67c81919737169e44aaaafc_190e0645021881919deeacf23c4a3be0&account_id=personal) · [Kwadratury Fejéra](https://people.math.ethz.ch/~waldvoge/Papers/fejer.pdf)

## Kod do powtórzenia certyfikatu

Python 3 z mpmath. Uruchomienie bez argumentów sprawdza przypadek \(R=160\), z \(N=520\) węzłami na segment. Arytmetyka przedziałowa obejmuje każdą operację analityczną używaną do akceptacji znaku. Liczby zmiennoprzecinkowe użyte do wyboru parametrów pomocniczych nie stanowią podstawy akceptacji. Sprawdzenie wymaga włączonych asercji Pythona.

~~~python
from mpmath import iv
import sys, math
r = int(sys.argv[1]) if len(sys.argv) > 1 else 160
L = r
N = int(sys.argv[2]) if len(sys.argv) > 2 else 520
P = math.ceil(N * 3.05) + 100
iv.prec = P + 50
I = iv.mpf
base = 1 << P

def ceil(a, b):
    return -(-a // b)

def floori(y):
    assert y.a >= 0
    return int(y.a)

def ends(y):
    return (floori(y * base), int((y * base).b) + 1)
cosines = [iv.cos(iv.pi * j / (2 * N)) for j in range(4 * N)]
nodes = [(1 + cosines[2 * j + 1]) / 32 for j in range(N)]
weights = []
for j in range(N):
    w = 1 - sum((2 * cosines[2 * k * (2 * j + 1) % (4 * N)] / (4 * k * k - 1) for k in range(1, (N - 1) // 2 + 1)))
    weights.append(w / (16 * N))
low = [0] * (2 * r - 1)
high = low.copy()
cut = int(math.ceil(math.sqrt((P * math.log(2) + 25) / math.pi))) + 2
theta_err = I(1000) * iv.exp(-7 * iv.pi * (cut + 1) ** 2 / 8) / (1 - iv.exp(-7 * iv.pi / 8))
for panel in range(32):
    for j in range(N):
        u = I(panel) / 16 + nodes[j]
        x = iv.pi * iv.exp(4 * u)
        z = iv.exp(-x)
        z2 = z * z
        power = z
        ratio = z2 * z
        s = I(0)
        for h in range(1, cut + 1):
            y = x * h * h
            s += y * (2 * y - 3) * power
            power *= ratio
            ratio *= z2
            if power.b < iv.ldexp(I(1), -P - 50):
                local = I(1000) * iv.exp(-7 * x * (h + 1) ** 2 / 8) / (1 - iv.exp(-7 * x / 8))
                s += I([0, local.b])
                break
        mass = weights[j] * iv.exp(u) * (s + I([0, theta_err.b]))
        vl, vh = ends(mass)
        ul, uh = ends(u * L)
        for k in range(2 * r - 1):
            low[k] += vl
            high[k] += vh
            vl = vl * ul // (k + 1) >> P
            vh = ceil(ceil(vh * uh, k + 1), base)
quaderr = 5 * I(10000) * iv.exp(I(9) * L / 4) / I(8) ** N
X = iv.pi * iv.exp(8)
tail = 4 * iv.exp(2 + 2 * L) * X ** 2 * iv.exp(-X) / (4 * X - 13 - L)
err = (quaderr + tail).b
vals = [I([I(lo) / base, I(hi) / base]) + I([-err, err]) for lo, hi in zip(low, high)]
print('moments', r, 'cut', cut, 'quaderr', float(quaderr.b) if quaderr.b > I('1e-310') else 'under 1e-310', flush=True)
prev = [I(1)] * (len(vals) + 2)
cur = vals
assert all((c.a > 0 for c in cur))
for p in range(2, r + 1):
    nxt = [(cur[k + 1] ** 2 - cur[k] * cur[k + 2]) / prev[k + 2] for k in range(len(cur) - 2)]
    if any((v.a <= 0 for v in nxt)):
        raise ArithmeticError(f'Insufficient enclosure at order {p}')
    if p in (16, 32, 64, 128, r):
        ratio = nxt[0] / (cur[2] * vals[0])
        exponent = int(iv.floor(iv.log10(ratio).a)) if hasattr(iv, 'floor') else math.floor(float(iv.log10(ratio).a))
        assert ratio.a > I(10) ** exponent and ratio.b < I(10) ** (exponent + 1)
        print('signed pivot divided by a0:', p, 'strict exponent bracket', exponent, exponent + 1, flush=True)
    prev, cur = (cur, nxt)
    if p == r:
        print('certified all signed leading minors through rank', p, flush=True)
~~~
