# Nieograniczony rząd dla całek ogonowych jądra Riemanna

Nota analityczna do niezależnego sprawdzenia • 25 listopada 2026

## 1. Teza i zakres

Niech $\Phi(t)=\sum_{n\ge1}e^t x_n(2x_n-3)e^{-x_n}$, gdzie $x_n=\pi n^2e^{4t}$, a $\Psi_m$ oznacza $m$ kolejnych całek od $t$ do nieskończoności. Niech $W_p(f;t)=\det[f^{(i+j)}(t)]_{i,j=0}^{p-1}$ oraz $\epsilon_p=(-1)^{p(p-1)/2}$. Przez $m(r)$ rozumiemy najmniejszą nieujemną liczbę całkowań, dla której jądro $K(u,v)=\Psi_m(u+v)$ jest regularne znakowo typu $RR_r$. Logarytmy są naturalne.

**Twierdzenie wyprowadzone w tej nocie.** Dla liczb całkowitych $r\ge2$, $m\ge64$ spełniających
$$h=m-2r\ge8(\log m)^2$$
zachodzi $\epsilon_p W_p(\Psi_m;t)>0$ dla każdego $1\le p\le r$ i każdego $t\ge0$. W szczególności
$$
m(r)\le 2r+\left\lceil32(\log(16r))^2\right\rceil
\quad(r\ge2),\qquad \limsup_{r\to\infty}\frac{m(r)}r\le2 .
$$

Istotnie dla $y=16r\ge32$ mamy $8\log y\le y$, więc podany wybór $m$ spełnia $64\le m\le y^2$ i $8\log^2m\le32\log^2 y$. Przejście do regularności znakowej i zachowanie jej przez dalsze całkowania podaje Nuttall w lemacie 2.1 i uwadze 4.1. Analityczność całek na dodatniej półosi wynika z lokalnie jednostajnej zbieżności szeregu theta i jego pochodnych na węższych pasach $|\Im t|<\pi/8$, a następnie z relacji $\Psi_m'=-\Psi_{m-1}$. Przypadek $p=1$ wynika bezpośrednio z dodatniości $\Phi$ na półosi.

## 2. Sumowanie indeksów przed całkowaniem

Ustalmy $2\le p\le r$, $L=m-p$, $X=\pi e^{4t}\ge\pi$ oraz $a_n=\tfrac12\log n$. Dla $k\ge2$ określmy
$$
R_k(u)=\sum_{a_n\le u} n^{-1/2}
\left(\frac{(u-a_n)^{k-1}}{(k-1)!}-\frac{(u-a_n)^k}{k!}\right).
$$
Podpisany wrońskian ma znak całki po $0<u_1<\cdots<u_p$ z funkcji
$$
\mathcal I(u)=
\det[R_{L+j}(u_i)]_{1\le i\le p,\,0\le j<p}
\ \Delta(e^{4u_1},\ldots,e^{4u_p})\prod_i e^{5u_i-Xe^{4u_i}},
\qquad \Delta(v)=\prod_{i<j}(v_j-v_i).
\tag{1}
$$

Dla sprawdzenia normalizacji znaku oznaczmy przez $b_k^f$ całkę ogonową rzędu $k$ funkcji $f$. Odwrócenie wierszy w macierzy pochodnych po usunięciu znaków $(-1)^{i+j}$ daje $\epsilon_pW_p=\det[b_{L+1+i-j}^\Phi]$. Dla $g_n(v)=e^v x_n(v)e^{-x_n(v)}$, $g=\sum_n g_n$, mamy $2\Phi=-(g'+g)$ oraz $2b_{L+1+i}^\Phi=b_{L+i}^g-b_{L+1+i}^g$. Różniczkując tę ostatnią całkę $j$ razy, dostajemy wpis
$$
\frac{1}{2(L+i)!}\int_0^\infty s^{L+i-1}(L+i-s)(-1)^jg^{(j)}(t+s)\,ds .
$$
W tożsamości Andréiefa najpierw całkujemy po całej dodatniej ortancie z czynnikiem $1/p!$. Drugi wyznacznik rozwijamy po indeksach $n_i$. Po wyjęciu $g_{n_i}(t+s_i)$ wiersz składa się z wielomianów w $n_i^2 e^{4s_i}$ stopni $j$, o dodatnich współczynnikach wiodących $(4X)^j$. Daje więc Vandermonde’a. W każdym wierszu podstawiamy $u_i=s_i+a_{n_i}$. Wspólna waga $e^{5u_i-Xe^{4u_i}}$ pozostawia od indeksu tylko $n_i^{-1/2}$. Po podziale kolumn pierwszego wyznacznika przez $(L+j)!$ otrzymujemy dokładnie funkcje $R_{L+j}$. Wszystkie pominięte stałe są dodatnie. Po zsumowaniu indeksów iloczyn obu wyznaczników jest symetryczny, co pozwala przejść do uporządkowanych węzłów w (1). Sumowanie, całkowanie i różniczkowanie są dopuszczalne przy ustalonych $p,m,t$ przez zanik podwójnie wykładniczy w $s$ i gaussowski w $n$, także po dołączeniu dowolnego z występujących skończonych stopni wielomianowych.

## 3. Znak wyznacznika węzłowego dla $0<u_i<B=\log m$

Rozpatrzmy początkowe wrońskiany funkcji $R_L,\ldots,R_{L+p-1}$. Dla bloku długości $k\le p$ połóżmy $N=L+k-1$ i $J=\operatorname{diag}((-1)^i)_{i=0}^{k-1}$. Po odwróceniu kolumn jego wyznacznik ma postać $\epsilon_k\det[R_N^{(i+j)}(u)]_{0\le i,j<k}$, gdyż $R_\ell'=R_{\ell-1}$ w potrzebnym zakresie. W progach $u=a_n$ obcięte potęgi są dostatecznie gładkie: $N-2\ge2k-2$ z zapasem wynikającym z $h$. Celem jest zatem zachowanie znaku $\det J$ przez tę ostatnią macierz symetryczną.

Wprowadzamy $v(w)=uw/(1-w)$. Bierzemy macierz współczynników $[w^i z^j]$ wyrażenia
$$
(1-w)^N(1-z)^N R_N(u+v(w)+v(z)).
$$
Jest to kongruencja macierzy pochodnych przez macierz dolną trójkątną z przekątną $u^i/i!$. Wystarczą skończone pochodne do rzędu $2k-2$, także na progach. Dalej dzielimy wiersze i kolumny przez $\sqrt{\binom Ni}$ oraz całą macierz przez dodatnie $u^{N-1}/(N-1)!$.

Dla przesunięcia $a=a_n\le u$ podstawmy $d=a/u$ i
$$Q_d(w,z)=1-wz-d(1-w)(1-z).$$
Wkład tej pozycji przed podziałem przez dwumiany ma wielomian
$$
(1-w)(1-z)Q_d^{N-1}-(u/N)Q_d^N. \tag{2}
$$

**Lemat o przesunięciu.** Niech $C_M(d)$ będzie macierzą współczynników $Q_d^M$ znormalizowaną przez $\sqrt{\binom Mi\binom Mj}$. Niech $[C_M]_k$ oznacza początkowy blok $k\times k$. Dla $0\le d<1$ oraz $M\ge2(k-1)$,
$$
\|[C_M(d)]_k\|_2
\le \left(\sqrt{\frac{1-d}{1+d}}\right)^{M-2(k-1)}
\le e^{-(M-2(k-1))d}.\tag{3}
$$
Norma jest normą operatorową w przestrzeni euklidesowej.

**Dowód.** Macierz współczynników $Q_d$ to
$$H_d=\begin{pmatrix}1-d&d\\d&-1-d\end{pmatrix}.$$
$C_M(d)$ jest ograniczeniem potęgi tensorowej $H_d^{\otimes M}$ do tensorów symetrycznych w ortonormalnej bazie. Istotnie współrzędne $(e_0+w e_1)^{\otimes M}$ w tej bazie to $\sqrt{\binom Mi}w^i$, a forma dwuliniowa dla dwóch takich wektorów daje $Q_d(w,z)^M$. Niech $s=\sqrt{(1-d)/(1+d)}$ i $D=\operatorname{diag}(1,s)$. Przekątna $DH_dD$ wynosi $(1-d,-(1-d))$, a element pozadiagonalny $ds$. Kwadrat macierzy jest dokładnie $s^2 I$. Zatem w stopniu $M$ norma po przemnożeniu wierszy i kolumn przez $s^i$ wynosi najwyżej $s^M$. Na bloku $i<k$ cofnięcie skalowania kosztuje najwyżej $s^{-2(k-1)}$. Ponadto $\log s=-\operatorname{artanh}(d)\le-d$. W $d=1$ korzystamy z ciągłości. W naszym zastosowaniu wykładniki są dodatnie, a blok wtedy znika. To dowodzi (3).

Mnożenie przez $1-w$ ze stopnia $N-1$ do stopnia $N$ w znormalizowanych współczynnikach odpowiada dolnej macierzy dwudiagonalnej $T=D_0-S$, gdzie
$$
(D_0)_{ii}=\sqrt{1-i/N},\qquad S_{i,i-1}=\sqrt{i/N}.
$$
Na początkowym bloku $\|T\|_2\le2$. Macierz dla (2) ma więc postać
$$T[C_{N-1}(d)]_k T^\top-(u/N)[C_N(d)]_k.$$

Przy $n=1$ obie macierze $C$ redukują się na bloku do $J$. Mnożymy od prawej przez $J$ i bierzemy część symetryczną. Ponieważ $JS^\top J=-S^\top$, z iloczynu $(D_0-S)(D_0+S^\top)$ pozostaje dokładnie $D_0^2-SS^\top$. Najmniejsza wartość własna części symetrycznej wkładu jedynek po tym mnożeniu wynosi zatem
$$
1-\frac{2(k-1)+u}{N}
=\frac{L-k+1-u}{N}\ge\frac{h+1-B}{N}\ge\frac1m. \tag{4}
$$

Dla $n\ge2$ mniejszy wykładnik z (3) wynosi $N-1-2(k-1)=L-k\ge h$. Mnożenie przez $J$ zachowuje normę. Suma norm pozostałych wkładów na całym $0<u\le B$ jest najwyżej
$$
 (4+u/N)\sum_{n\ge2} n^{-1/2-h/(2B)}
 \le10\,m^{-4\log 2}<1/m. \tag{5}
$$
Tutaj $N\ge m/2$, $B=\log m$, $h/(2B)\ge4\log m$, a dla $s\ge3$ mamy $\sum_{n\ge2} n^{-s}\le 2^{-s}[1+2/(s-1)]$. Z (4)–(5) pełna macierz po mnożeniu przez $J$ ma dodatnio określoną część symetryczną, więc dodatni wyznacznik: na odcinku łączącym ją z identycznością wszystkie części symetryczne są dodatnio określone. Przed mnożeniem jej znak wynosi $\det J=\epsilon_k$. Po przywróceniu kolejności kolumn otrzymujemy dodatni początkowy wrońskian funkcji $R_L,\ldots,R_{L+k-1}$.

Te nierówności dla wszystkich $k\le p$ dają dodatni wyznacznik wartości na każdych ściśle rosnących węzłach w $(0,B)$. Krótki dowód: dla rodziny $f_1,\ldots,f_k$ dzielimy przez $f_1>0$ i różniczkujemy. Początkowy wrońskian długości $j$ nowej rodziny $(f_2/f_1)',\ldots$ wynosi $W(f_1,\ldots,f_{j+1})/f_1^{j+1}>0$. Indukcja i twierdzenie Rolle’a wykluczają $k$ różnych zer nietrywialnej kombinacji. Wyznacznik wartości jest więc niezerowy, a jego znak wyznaczamy, zbliżając wszystkie węzły do jednego punktu i dzieląc przez dodatni iloczyn Vandermonde’a; granica jest dodatnim wrońskianem podzielonym przez iloczyn silni. W całej centralnej części całki (1) znak jest zatem dodatni.

## 4. Ilościowe porównanie całki centralnej i ogona

W centralnym obszarze zachowujemy prostokąt, na którym $u_i$ leży między $1/8+(i-1)/(8p)$ a tą samą liczbą powiększoną o $1/(16p)$. Są to węzły w $[1/8,1/4]$. Ponieważ $1/4<\log 2/2$, w (1) wszędzie pozostają same jedynki. Każda odległość w obu iloczynach Vandermonde’a jest co najmniej $1/(16p)$, a objętość prostokąta wynosi $(16p)^{-p}$.

Dokładnie
$$
 \det[R_{L+j}(u_i)]
 =\frac{\prod_i u_i^{L-1}\,\Delta(u)\, P_L(u)}
 {\prod_{j=0}^{p-1}(L+j)!},\qquad
 P_L(u)=\mathbb E\prod_i(Y-u_i),\quad Y\sim\operatorname{Gamma}(L,1).
$$
Po wyjęciu potęg i silni kolumna $j$ składa się z $u_i^j(L+j-u_i)$. W rozwinięciu wyznacznika tylko początkowy ciąg wyborów niższej potęgi nie powtarza wykładnika. Otrzymane współczynniki przy elementarnych funkcjach symetrycznych to momenty $(L)_a$ zmiennej $Y$, z odpowiednimi znakami.

Na prostokącie $P_L\ge1$: nierówność Paleya–Zygmunda daje $\Pr(Y\ge L/2)\ge1/8$. Na tym zdarzeniu iloczyn jest co najmniej $(L/2-1/4)^p$. Ujemny wkład może wystąpić jedynie dla $Y\le1/4$ i jego moduł jest najwyżej $(1/4)^p$. Korzystamy z $L\ge32$. Ponieważ $e^{4u_i}\le e$, całka centralna ma dolną granicę
$$
 (16p)^{-p^2}\,8^{-p(L-1)}(m!)^{-p}e^{-epX}
 \ge \exp[-5m^2\log(16m)-epX]. \tag{6}
$$

Na całej półosi mamy $|R_{L+j}(u)|\le 2e^{2u}(1+u)^m$ przez policzenie możliwych indeksów i ograniczenie potęg. Dla uporządkowanych węzłów $|\Delta(e^{4u_i})|\le\prod_i e^{4(p-1)u_i}$. Gdy co najmniej jeden $u_i>B$, z wagi wykładniczej wyjmujemy $e^{-X e^{4B}/2}=e^{-Xm^4/2}$. Po rozwinięciu wyznacznika i rozszerzeniu pozostałej dziedziny do całej dodatniej ortanty, masa bezwzględna tej części jest nie większa niż
$$
 p!2^p e^{-Xm^4/2}
 \left(\int_0^\infty e^{4mu-(\pi/2)e^{4u}}du\right)^p
 \le \exp[3m^2\log(16m)-Xm^4/2]. \tag{7}
$$
Wykorzystano $m+4p+7\le4m$, $X\ge\pi$ oraz podstawienie $y=e^{4u}$, dające całkę co najwyżej $m!$. Dla $m\ge64$ prawa strona (7) jest mniejsza od prawej strony (6). Rzeczywiście $m^4/2-ep\ge m^4/3$ i $8m^2\log(16m)<\pi m^4/3$ w tym zakresie. To kończy dowód ścisłej dodatniości, jednostajnie dla $t\ge0$.

## 5. Przykład i pytanie o dokładny poziom 2r

Dla $r=8000$ można wziąć $m=16757$. Wtedy $h=757$, a $8(\log 16757)^2<756{,}86$. Wniosek obejmuje wszystkie rzędy $p\le8000$ i całą półoś $t\ge0$. Liczba $16757$ jest oszacowaniem górnym na $m(8000)$.

Dla $m=2r$ i $p=k=r$ wykładnik tłumienia $L-k$ w (5) wynosi zero. Również margines w (4) redukuje się do $(1-u)/N$. Argument wymaga wówczas ostrzejszej kontroli pełnej macierzy przy ostatnich indeksach. Obecne oszacowanie dopuszcza zarówno $m(r)\le2r$, jak i przekroczenia poziomu $2r$ o wielkość podliniową.

Nota zawiera dowód analityczny do niezależnej weryfikacji. Nie wykonano formalizacji w Lean ani przeglądu pierwszeństwa wyniku.

[J. Nuttall, Wronskians, Cumulants, and the Riemann Hypothesis, lemat 2.1, §4.2 i uwaga 4.1](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf)
