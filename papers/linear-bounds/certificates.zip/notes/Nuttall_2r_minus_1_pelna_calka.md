# O jedno całkowanie mniej dla jądra Riemanna. Oszacowanie pełnej całki

Niech \(X=\pi e^{4t}\), \(m=2r-1\), \(\epsilon_p=(-1)^{p(p-1)/2}\). Jądro, iterowane całki ogonowe i wrońskiany mają normalizację z pytania. Niech \(Y\sim\Gamma(3/2,1)\) (parametr intensywności równy jeden), \(M_j(x)=\mathbb E(x-Y)^j\). Dla nieparzystego \(k\) oznaczmy przez \(\rho_k\) jedyne rzeczywiste zero \(M_k\), a przez \(k_r\) największą liczbę nieparzystą nieprzekraczającą \(r\).

**Twierdzenie robocze.** Dla pełnego jądra Riemanna, każdego całkowitego \(r\ge500\), wszystkich \(1\le p\le r\) oraz
\[
                  X\ge e^{-1/2500}\rho_{k_r}
\]
zachodzi \(\epsilon_p W_p(\Psi_{2r-1};t)>0\). To samo oszacowanie obowiązuje dla sumy dwóch pierwszych składników theta. Dla tej sumy przy każdym \(r\ge2\) wystarcza też \(X\ge\rho_{k_r}\). Wszystkie te znaki dotyczą całek po pełnej dziedzinie węzłów.

Przy \(b>0\) określonym przez \(b+1+\log b=0\) mamy \(\rho_k=bk+\frac b{1+b}\log k+O(1)\) dla nieparzystych \(k\). Stąd asymptotyczny współczynnik w wystarczającym progu dla \(X\) wynosi \(b e^{-1/2500}=0{,}2783531792\ldots\). Liczba ta opisuje zakres zmiennej \(X\). Wartość \(\lim m(r)/r\) pozostaje niewyznaczona. Twierdzenie nie korzysta z RH ani z prawdziwości roboczego globalnego \(m(r)\le2r\). Podajemy wyprowadzenie, ze skończonym rachunkiem przedziałowym w §3. Nie przeprowadzono formalizacji.

## 1. Inny rozkład pochodnych w tożsamości Andréiefa

Dla \(L=m-p\), \(a_n=\tfrac12\log n\), połóżmy
\[
 B_h(u)=\sum_{a_n<u}n^{-1/2}(u-a_n)^h/h!,\qquad z_i=Xe^{4u_i}.
\]
W modelu dwuskładnikowym sumujemy do dwóch. Z dokładnością do czynnika ściśle dodatniego podpisany wrońskian jest całką po \((0,\infty)^p\) z funkcji symetrycznej
\[
 I(\boldsymbol u)=\det[B_{L+j}(u_i)]_{1\le i\le p,\ 0\le j<p}
 \;\Delta(e^{4u})\;P_p(\boldsymbol z)\;\prod_i e^{5u_i-Xe^{4u_i}},
 \qquad P_p(\boldsymbol z)=\mathbb E\prod_i(z_i-Y).                 \tag{1}
\]
Tutaj \(\Delta(w)=\prod_{i<j}(w_j-w_i)\).

**Dowód.** Niech \(D=d/dt\), \(x=\pi e^{4t}\), \(g=e^t x e^{-x}\) i \(\phi_1=g(2x-3)\). W jądrze \(\phi_n(t)=n^{-1/2}\phi_1(t+a_n)\). Odwrócenie wierszy wrońskianu usuwa \(\epsilon_p\); znaki z różniczkowania odpowiadających ogonów i znaki \((-1)^j\) z kolumn dają wspólnie 1. Otrzymujemy macierz o wpisach \((-D)^j\Psi_{L+1+i}(t)\). W jej całkach przesunięcie \(u=s+a_n\) oddziela \(B_{L+i}(u)\) od \((-D)^j\phi_1(t+u)\). Stosujemy tożsamość Andréiefa. Różniczkowanie pod całką i zamianę sum z całkami uzasadniają, przy ustalonych indeksach, wykładniczy zanik w \(n^2\) oraz podwójnie wykładniczy zanik w zmiennej ogonowej.

Wielomiany \(Q_j\), dla których \((-D)^j\phi_1=gQ_j(x)\), spełniają
\[
 Q_0(x)=2x-3,\qquad Q_{j+1}(x)=(4x-5)Q_j(x)-4xQ'_j(x).
\]
Mają stopień \(j+1\), dodatni współczynnik wiodący \(2\cdot4^j\) i \(\mathbb E Q_j(Y)=0\). Ostatnia własność wynika przez części z \(\mathbb E[YQ'(Y)]=\mathbb E[(Y-3/2)Q(Y)]\) i \(\mathbb E Q_0(Y)=0\). W wyznaczniku wartości \(1,Q_0,\ldots,Q_{p-1}\) w punktach \(Y,z_1,\ldots,z_p\) całkujemy pierwszy wiersz. Z jednej strony otrzymujemy \(\det[Q_j(z_i)]\), z drugiej dodatnią stałą razy \(\Delta(z)\,\mathbb E\prod(z_i-Y)\). To dowodzi (1). [Wzór Andréiefa](https://webpages.ciencias.ulisboa.pt/~gruzza/introRMT.pdf)

## 2. Dokładny próg dla czynnika gamma

Parzyste momenty \(M_j\) są dodatnie; \(M'_j=jM_{j-1}\), więc każdy nieparzysty moment ma dokładnie jedno zero, dodatnie. Całkowanie przez części daje
\[
 M_0=1,\quad M_1=x-3/2,\quad
 M_{j+1}=(x-j-3/2)M_j+jxM_{j-1}.                            \tag{2}
\]
Dla \(x=j+3/2\) poprzednie kroki rekurencji mają nieujemne współczynniki i dają \(M_j(x)>0\). W punkcie \(\rho_j\) dla nieparzystego \(j\) jest więc \(M_{j+2}(\rho_j)=(\rho_j-j-5/2)M_{j+1}(\rho_j)<0\). Zera rosną ściśle w ciągu indeksów nieparzystych.

Po rozpisaniu \(z_i-Y=(z_i-x)+(x-Y)\) mamy
\[
 P_p(\boldsymbol z)=\sum_{A\subseteq\{1,\ldots,p\}}
        M_{p-|A|}(x)\prod_{i\in A}(z_i-x).                    \tag{3}
\]
Dla \(x=\rho_{k_r}\), \(p\le r\) i \(z_i>x\) wszystkie składniki są nieujemne, a składnik z \(|A|=p\) jest dodatni. Próg ten jest ostry dla punktowego testu na wszystkich rzędach. Gdy \(0<x<\rho_{k_r}\), wystarczy wziąć \(p=k_r\) i wszystkie \(z_i\) różne, dostatecznie bliskie \(x\) od góry. Wtedy \(P_p<0\).

Aby obliczyć asymptotykę zera nieparzystego momentu, podzielmy jego dodatnią i ujemną część przez \(x^k\). Dla \(x=bk+O(\log k)\) część dodatnia zbiega do \((1+1/b)^{-3/2}\) na mocy zbieżności zdominowanej, bo \((1-Y/x)_+^k\le1\). Moduł części ujemnej po podstawieniu \(Y=x+v\) jest dokładnie
\[
 \frac{e^{-x} k!}{x^k\Gamma(3/2)}\;\mathbb E\sqrt{x+G_{k+1}},
 \qquad G_{k+1}\sim\Gamma(k+1,1).
\]
Mamy \(G_{k+1}/k\to1\) w \(L^2\), zatem czynnik z pierwiastkiem jest asymptotycznie równy \(\sqrt{k(1+b)}\). Niech \(d=b/(1+b)\). Dla \(x=bk+d\log k+z\) przy ustalonym \(z\), wzór Stirlinga daje granicę modułu części ujemnej równą \(\sqrt{2\pi(1+b)}\,e^{-z/d}/\Gamma(3/2)\). Wyrazy liniowe w \(k\) znikają na mocy równania dla \(b\). Porównując obie granice przy \(z=z_0\pm\varepsilon\) i używając ścisłej monotoniczności, uzyskujemy
\[
 \rho_k=bk+d\log k+z_0+o(1),\qquad
 z_0=d\log\left(\frac{\sqrt{2\pi(1+b)}}{\Gamma(3/2)}
                          (1+1/b)^{3/2}\right).
\]
To twierdzenie dotyczy wielomianu pomocniczego.

Przyda się również \(0{,}26r<\rho_{k_r}<r/2\) dla \(r\ge500\). Dla \(x=0{,}26r\) mamy \(x/k_r<0{,}261\). Wzór na część ujemną i \(k!\ge(k/e)^k\) dają dolną granicę \(\sqrt x\exp[-k(0{,}261+1+\log0{,}261)]/\Gamma(3/2)>1\), podczas gdy część dodatnia jest co najwyżej 1. Dla \(x=r/2\) dodatnia część przekracza \(\Pr(Y\le1)(1-2/r)^r>e^{-3}/4\). Ujemna ma moduł co najwyżej \(e\sqrt{k(x+k+1)}\exp[k(\log2-1)-r/2]/\Gamma(3/2)<e^{-3}/4\), przez nierówność Jensena i \(k!\le e\sqrt{k}(k/e)^k\).

## 3. Znak wyznacznika przesuniętych potęg

W modelu dwuskładnikowym \(\det[B_{L+j}(u_i)]>0\) dla dowolnych \(0<u_1<\dots<u_p\), każdego \(r\ge2\) i \(p\le r\). Dla pełnego jądra wykażemy ten sam znak, gdy \(u_p<B=27/25\), \(r\ge500\).

Dla początkowego wrońskianu długości \(k\le p\) połóżmy \(M=L+k-1\). Wtedy \(M\ge r-1\) oraz \(M-2(k-1)=2r-p-k\ge0\). Po odwróceniu kolumn badamy macierz pochodnych \(B_M^{(i+j)}\) poza progami. Mnożymy funkcję tworzącą pochodnych w dwóch zmiennych przez \((1-w)^M(1-z)^M\), podstawiając do \(B_M\) argument \(u+uw/(1-w)+uz/(1-z)\). Jest to kongruencja dolnotrójkątna o przekątnej \(u^i/i!\). Po podzieleniu przez \(u^M/M!\) i normalizacji wierszy oraz kolumn przez \(\sqrt{\binom Mi}\) otrzymujemy macierz
\[
 J+\sum_{2\le n\le e^{2u}} n^{-1/2} C_{a_n/u},\qquad
 J_{ij}=(-1)^i\delta_{ij},\quad
 (C_d)_{ij}=\frac{[w^iz^j](1-wz-d(1-w)(1-z))^M}{\sqrt{\binom Mi\binom Mj}} .
\]
Jeśli norma sumy zaburzeń jest mniejsza od 1, odcinek od \(J\) do tej macierzy składa się z macierzy odwracalnych. Znak \(\det J\) znosi się z odwróceniem kolumn.

Dla \(0<d<1\) weźmy \(s=\sqrt{(1-d)/(1+d)},\ c=\sqrt{1-d^2}\). Mamy \((C_d)_{ij}=s^{M-i-j}T_{ij}\), gdzie \(T\) jest ortogonalną potęgą symetryczną stopnia \(M\) macierzy o wierszach \((c,d),(d,-c)\). Wynika to przez podstawienie \(sw,sz\) do wielomianu stopnia jeden i podzielenie przez \(s\). Z dwóch diagonalnych skalowań i \(i,j\le M/2\) wynika \(\|C_d\|_2\le1\), również dla \(d=1\) przez ciągłość. W modelu dwuskładnikowym norma zaburzenia jest zatem co najwyżej \(1/\sqrt2\) na całej półosi.

Dla pełnej sumy na \(u<B\) mamy \(K=\lfloor e^{2u}\rfloor\le8\). Najnowszy składnik \(K\ge2\) kosztuje co najwyżej \(K^{-1/2}\). Dla \(2\le n<K\) wykorzystamy
\[
 \|C_d\|_2\le \min\left(1,\frac{0{,}887}
 {(1-s^2)cd\sqrt{M-2h-2h^2}}+2s^h\right),\qquad h=9.       \tag{4}
\]
Oto wyprowadzenie. Część z co najmniej jednym indeksem \(M/2-i>h\) lub \(M/2-j>h\) ma normę co najwyżej \(2s^h\), przez zapis jako sumy dwóch bloków ze skalowaniem. W pozostałej części przyjmijmy \(i\ge j\), \(\beta=M/2-j\). Wpis \(T_{ij}\) jest współczynnikiem przy \(z^i\) w \((c+dz)^{M-j}(d-cz)^j\) pomnożonym przez \(\sqrt{\binom Mj/\binom Mi}\le1\). Na okręgu jednostkowym moduł iloczynu ma postać \((1-v^2)^{M/4-\beta/2}(1+v)^\beta\), gdzie \(v=2cd\cos\theta\). Średni wkład \((1\pm v)^\beta\) jest co najwyżej \(\cosh(\beta v)\le e^{\beta^2v^2/2}\). Nierówność Cauchy’ego na współczynnik daje granicę w postaci średniej \(e^{-A\cos^2\theta}\), z \(A=(M-2h-2h^2)c^2d^2\). Ta średnia jest co najwyżej \(\sqrt\pi/(2\sqrt A)<0{,}887/\sqrt A\) przez \(\sin v\ge2v/\pi\) na \([0,\pi/2]\). Norma Frobeniusa tablicy samych skalowań \(s^{M-i-j}\) nie przekracza \(1/(1-s^2)\), co daje (4).

Mamy \(M-2h-2h^2\ge319\). Dla ustalonej pary \((K,n)\) parametr \(d\) leży między \(a=\log n/\min(\log(K+1),2B)\) a \(b'=\log n/\log K\). W (4) bierzemy \(s=s(a)\) i minimum \(d\sqrt{1-d^2}\) na końcach tego przedziału. Poniższe granice dla sumy ważonych norm zaokrąglono w górę.

| \(K\) | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Granica | 0,708 | 0,710 | 0,747 | 0,805 | 0,871 | 0,942 | 0,997 |

Przejście od początkowych wrońskianów do wyznacznika w różnych węzłach obejmuje również przekraczanie progów. Dzielimy funkcje przez pierwszą dodatnią, odejmujemy sąsiednie wiersze wartości i stosujemy podstawowe twierdzenie rachunku całkowego. Zostaje całka wyznacznika kolejnych funkcji \((f_{j+1}/f_1)'\) na kolejnych odcinkach. Ich początkowe wrońskiany to wrońskiany poprzedniej rodziny o rząd wyższe podzielone przez dodatnią potęgę \(f_1\). Powtarzamy redukcję. Tu \(L\ge p-1\), więc pochodne do rzędu \(p-2\) są ciągłe i lokalnie absolutnie ciągłe. Wrońskiany niższych rzędów pozostają dodatnie na progach przez ciągłość i jednostajny odstęp od osobliwości po kongruencji. Na ostatnim etapie wystarcza dodatniość prawie wszędzie. Przypadek \(p=1\) jest bezpośredni. W ten sposób dowiedliśmy obu twierdzeń o znaku wyznacznika w §3. W szczególności (1) i (3) już dowodzą wyniku dla dwóch składników przy \(X\ge\rho_{k_r}\) dla każdego \(r\ge2\).

## 4. Kontrola obydwu końców całki, także gdy czynnik gamma zmienia znak

Ustalmy wszystkie współrzędne poza jedną. Moduł integrandu w zmiennej \(u\), z dokładnością do stałej, jest równy
\[
 |f(u)|\prod_{j=1}^{p-1}|e^{4u}-e^{4v_j}|\,|A+D e^{4u}|\,e^{5u-Xe^{4u}},
 \qquad f=\sum_{j=0}^{p-1}c_j B_{L+j}.                        \tag{5}
\]
Istnienie pojedynczego czynnika afinicznego wynika z (1). Poniższe porównania są jednostajne w pozostałych współrzędnych i współczynnikach. Przekroje tożsamościowo zerowe spełniają je automatycznie.

**Duże węzły.** Niech \(F=\max_j |c_j|/(L+j)!\), \(H=F\max(|A|,|D|)\prod_j(1+e^{4v_j})\). Na \(J=[1/8,1/4]\) mamy \(f(u)=u^L q(u)\), gdzie największy moduł współczynnika \(q\) wynosi \(F\). Jeśli \(q=a\prod(u-w)\), to \(|a|\prod(1+|w|)\ge F\). Średnia na \(J\) z \(\log(|u-w|/(1+|w|))\) wynosi co najmniej \(-1-\log32\): dla \(|w|\le1\) minimum średniej logarytmu odległości osiąga się w środku odcinka, a dla \(|w|>1\) iloraz jest co najmniej \(3/8\). Podobnie
\[
 |e^{4u}-e^{4v}|/(1+e^{4v})\ge\min(|u-v|,1/4),
\]
ze średnią logarytmu co najmniej \(-1-\log16\) na \(J\). Dla czynnika afinicznego średnia logarytmu po podzieleniu przez \(\max(|A|,|D|)\) jest co najmniej \(-5\). Istotnie dla jego pierwiastka \(w\) z \(|w|>2e\) iloraz \(|e^{4u}-w|/(1+|w|)\) przekracza \(1/3\); w przeciwnym razie, po rzucie \(\Re w\) na \(e^{4J}\), korzystamy z pochodnej \((e^{4u})'\ge4\) i średniej logarytmu odległości. Dostajemy granicę \(\log(4|J|/[2e(1+2e)])>-5\). Stały wielomian także spełnia oszacowanie.

Z Jensena, \(u^L\ge8^{-L}\) i \(2\log8+2+\log32+\log16<13\), całka z (5) po \(J\) jest co najmniej \(H e^{-5-13r-eX}/8\). Dla \(u\ge B\) mamy \(|f|\le2e^u pF u^{2r}\), gdyż \(\sum_{n\le e^{2u}}n^{-1/2}\le2e^u\). Każdy znormalizowany czynnik Vandermonde’a jest najwyżej \(e^{4u}\), a znormalizowany czynnik afiniczny ma moduł co najwyżej \(2e^{4u}\). Stosując
\[
 e^{4u}\ge e^{4B}(1+4(u-B)),\qquad u^{2r}\le B^{2r}e^{2r(u-B)/B},
\]
ograniczamy stosunek całki po \([B,\infty)\) do całki po \(J\) przez
\[
 \eta_\infty=
 \frac{32e^5 p}{4Xe^{4B}-(4p+6+2r/B)}
 \exp\{13r+(4p+6)B+2r\log B-(e^{4B}-e)X\}.
\]
Dla \(X\ge r/4,\ r\ge500\) mianownik jest większy od \(60r\); ponadto \((e^{4B}-e)/4-13-4B-2\log B>0{,}64\). Zatem \(\eta_\infty<e^{12-0{,}64r}\).

**Małe węzły.** Połóżmy \(\delta=10^{-4}\), \(l=1/16,\ h=5/16,\ J_*=[l,h]\). Przy \(0<u\le\delta\) oraz \(v\in J_*\) działa ten sam wielomian \(f(v)=v^Lq(v)\), gdyż \(h<a_2\). Porównamy wartość przekroju w \(u\) ze średnią geometryczną jego modułu na \(J_*\). Dla każdego pierwiastka zespolonego \(w\) średnia geometryczna ilorazu \(|v-w|/|u-w|\) jest co najmniej \(c_1=(h-l)/(4eh)\). Dla \(|u-w|\ge2h\) wystarcza granica \(1/2\); w przeciwnym razie średnia geometryczna licznika jest co najmniej \((h-l)/(2e)\). Gdy mianownik jest zerem, wartość porównywana w \(u\) znika.

Dla czynnika w zmiennej wykładniczej analogiczne ograniczenie to
\[
 c_2=\frac{e^{4l}(h-l)}{e(e^{4h}-1)}.
\]
Jeśli \(|e^{4u}-w|\ge2(e^{4h}-1)\), wystarcza granica \(1/2\). W przeciwnym razie używamy rzutu \(\Re w\) na przedział \([e^{4l},e^{4h}]\), pochodnej co najmniej \(4e^{4l}\) i tego samego oszacowania średniej logarytmu odległości. Oszacowanie obejmuje czynnik afiniczny i wszystkie czynniki Vandermonde’a. Na mocy wklęsłości logarytmu średnia geometryczna \(v\) jest co najmniej \(G=\sqrt{lh}\).

Przy \(X\le r/2\) całka przekroju po \(J_*\) jest zatem co najmniej jego modułem w punkcie \(u\) pomnożonym przez
\[
 |J_*|(G/\delta)^L c_1^{p-1}c_2^p\exp[-(r/2)(e^{4h}-1)].
\]
Tu \(L\ge r-1\), \(p\le r\), zaś \(\log(G/\delta)+\log(c_1c_2)-(e^{4h}-1)/2>0{,}33\). Całkując po \(0<u<\delta\), dostajemy stosunek do całki po \(J_*\) co najwyżej \((G/|J_*|)e^{-0{,}33r}<e^{-0{,}33r}=\eta_0\).

**Zakończenie.** Gdy \(e^{-4\delta}\rho_{k_r}\le X\le r/2\), na sześcianie \((\delta,B)^p\) mamy \(z_i>\rho_{k_r}\). Wzór (3) i §3 dają \(I>0\) dla parami różnych węzłów. Jednocześnie \(X>r/4\) na mocy końca §2. Sumując nierówności przekrojowe po wyborach współrzędnej, otrzymujemy
\[
 \int_{(0,\infty)^p\setminus(\delta,B)^p}|I| \le p(\eta_0+\eta_\infty)\int |I|<\tfrac12\int |I|.
\]
Dopełnienie rozumiemy w \((0,\infty)^p\). Całka z modułu jest dodatnia dzięki wnętrzu sześcianu. Stąd \(\int I>0\). Gdy \(X>r/2\), mamy już \(X>\rho_{k_r}\), bierzemy sześcian \((0,B)^p\) i wystarcza oszacowanie dużych węzłów. Domyka to znak na całym deklarowanym obszarze. Na pasie \(e^{-4\delta}\rho_{k_r}\le X<\rho_{k_r}\) czynnik gamma ma obszar ujemny dla \(p=k_r\), a mimo to pełna całka ma znak dodatni.

## 5. Dokładne kryterium dla dwóch składników na pozostałym odcinku

Istnieje też redukcja pełnej całki do rzeczywistych zer jednego wielomianu. Działa przy każdym \(X\ge\pi\). W (1) dokonajmy zmiany \(z=Xe^{4u}\) i połóżmy \(b_j(z)=B_{L+j}(\frac14\log(z/X))\). Na \(z>X\) miarą bazową jest \(w(z)\,dz=z^{1/4}e^{-z}\,dz\). Dla dwóch składników §3 pozwala znormalizować
\[
  \det[b_j(z_i)]\Delta(z)\prod_i w(z_i)\,dz_i
\]
do **dodatniej miary probabilistycznej** \(\nu\) na uporządkowanych węzłach. Zdefiniujmy moniczny wielomian \(q(y)=\mathbb E_\nu\prod_i(y-z_i)\). Wtedy \(\int_X^\infty q(y)b_j(y)w(y)\,dy=0\) dla \(0\le j<p\). Istotnie, dołączenie zmiennej \(y\) do Vandermonde’a i antysymetryzacja drugiego czynnika we wszystkich \(p+1\) zmiennych daje wyznacznik z powtórzoną kolumną \(b_j\).

Wszystkie \(p\) zer \(\xi_i\) wielomianu \(q\) są proste i należą do \((X,\infty)\). Gdyby było tylko \(s<p\) punktów zmiany znaku w tym przedziale, wyznacznik funkcji \(b_0,\ldots,b_s\) w tych punktach i w dowolnym ostatnim punkcie \(y\) dawałby kombinację liniową zmieniającą znak dokładnie w tych samych miejscach, na mocy §3 i przestawiania wierszy. Jej całka przeciw \(qw\) miałaby stały, ścisły znak, wbrew ortogonalności. Podstawiając \(Y\) i zmieniając kolejność całkowania w (1), otrzymujemy dokładną równoważność
\[
 \epsilon_p W_p(\Psi^{(1,2)}_{2r-1};t)>0
 \quad\Longleftrightarrow\quad
 \mathbb E_Y\prod_{i=1}^p(\xi_i-Y)>0.
\]
Zera \(\xi_i\) są wyznaczone przez \(p\) jednowymiarowych warunków ortogonalności powyżej. Dla \(X\) stałego oszacowanie oparte wyłącznie na \(\xi_i>X\) jest niewystarczające. Ilościowa informacja o rozmieszczeniu tych konkretnych zer może rozszerzyć dowód na pozostały odcinek.

## 6. Sprawdzenie liczb i otwarte pytanie

Kod poniżej odtwarza siedem granic przedziałowych, marginesy z §4 i dokładny test dla \(r=8000\). Rekurencja ze skalą całkowitą oblicza znak wielomianu przy argumencie wymiernym bez błędów zaokrąglania.

~~~python
from fractions import Fraction
from mpmath import iv

iv.dps = 45
I = iv.mpf
B = I(27)/25
upper_bounds = [708, 710, 747, 805, 871, 942, 997]
for K, upper in zip(range(2, 9), upper_bounds):
    score = 1/iv.sqrt(K)
    for n in range(2, K):
        a = (iv.log(n)/min(iv.log(K+1).b, (2*B).b)).a
        b = (iv.log(n)/iv.log(K)).b
        cd = min((z*iv.sqrt(1-z*z)).a for z in (a, b))
        s = iv.sqrt((1-a)/(1+a))
        term = I(887)/(1000*iv.sqrt(319)*cd*(1-s*s))+2*s**9
        score += min(I(1), term.b)/iv.sqrt(n)
    assert score.b < (I(upper)/1000).a
e = iv.exp(1)
assert ((iv.exp(4*B)-e)/4-13-4*B-2*iv.log(B)).a > I('.64').b
l, h = I(1)/16, I(5)/16
c1 = (h-l)/(4*e*h)
c2 = iv.exp(4*l)*(h-l)/(e*(iv.exp(4*h)-1))
assert (iv.log(10000*iv.sqrt(l*h)*c1*c2)-(iv.exp(4*h)-1)/2).a > I('.33').b

def moment_sign(k, x):
    scale = 2*x.denominator
    u = 2*x.numerator
    alpha = 3*scale//2
    previous, current = 1, u-alpha
    for j in range(1, k):
        previous, current = current, (u-alpha-scale*j)*current + j*u*scale*previous
    return (current > 0) - (current < 0)

assert moment_sign(7999, Fraction(2230147590, 10**6)) == -1
assert moment_sign(7999, Fraction(2230147591, 10**6)) == 1
xbound = iv.exp(-I(1)/2500)*I(2230147591)/10**6
assert xbound.b < I('2229.255711').a
assert (iv.log(xbound/iv.pi)/4).b < I('1.641174').a
~~~

Dla \(r=8000\), \(m=15999\) otrzymujemy wszystkie wymagane ścisłe znaki dla \(t\ge1{,}641174\). Otwarty jest dowód przy tym poziomie na pozostałym odcinku przy zerze. W zmiennej \(X\) jego zakres dla ogólnego \(r\ge500\) to \(\pi\le X<e^{-1/2500}\rho_{k_r}\) w sensie braku pokrycia przez obecne twierdzenie. Przy \(X\) stałym i rosnącym \(r\) powyższe porównanie pojedynczych współrzędnych nie zapewnia znaku na centralnym sześcianie. Do wykorzystania znoszenia w całym tym zakresie potrzeba kontroli łącznego rozkładu węzłów lub innego argumentu o znaku całki. Nawet globalne oszczędzenie jednego całkowania pozostawiłoby dotychczasową granicę \(\limsup m(r)/r\le2\).

[Poprzednia reprezentacja i zakres \(X\ge10r\)](https://chatgpt.com/library?file_id=libfile_fde3_f-3e2e47c29e4081919daa2a90fc0eee96_190e0645021881919deeacf23c4a3be0&account_id=personal) · [Poprzedni test wariancyjny](https://chatgpt.com/library?file_id=libfile_fde3_f-b58fb0d8b67c81919737169e44aaaafc_190e0645021881919deeacf23c4a3be0&account_id=personal) · [Kryterium wrońskianowe Nuttalla, wzory (3.27)–(3.28)](https://publish.uwo.ca/~jnuttall/cumanal_a.pdf)
