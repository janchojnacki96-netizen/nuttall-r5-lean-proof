# Ostra asymptotyka względnej reszty theta dla całek Nuttalla

Niech $f(t)=e^t x(2x-3)e^{-x}$, gdzie $x=\pi e^{4t}$, oznacza pierwszy składnik jądra. Niech $F_k$ będzie jego $k$-krotną całką ogonową, a $\Psi_k$ odpowiednią całką całego jądra. Dla $k\ge2$ połóżmy $E_k(t)=(\Psi_k(t)-F_k(t))/F_k(t)$. Wszystkie te funkcje są dodatnie na półosi.

**Wynik.** Dla każdego $k\ge2$ funkcja $E_k(t)$ jest nierosnąca dla $t\ge0$. Ponadto
\[
 \lim_{k\to\infty}\frac{\log k}{k}\log\sup_{t\ge0}E_k(t)=-2\log2.
\]
Wynik jest dla pełnej sumy po wszystkich $n\ge2$. Nie wymaga założenia o zerach dzety ani wcześniejszych oszacowań $m(r)$.

## Przesunięcia i najgorszy punkt

Niech $a_n=(\log n)/2$. Składnik theta o indeksie $n$ jest równy $n^{-1/2} f(t+a_n)$. Przesunięcie zmiennej w całce i twierdzenie Tonellego dają
\[
 E_k(t)=\mathbb E_{k,t}H_k(V),\qquad
 H_k(v)=\sum_{n\ge2}n^{-1/2}(1-a_n/v)_+^{k-1},
\]
gdzie $V$ ma gęstość proporcjonalną do $v^{k-1}f(t+v)$ na $v>0$, a $z_+=\max(z,0)$. Funkcja $H_k$ jest niemalejąca i ograniczona przez $2e^v$, ponieważ wchodzą do niej tylko $n\le e^{2v}$.

Z bezpośredniego różniczkowania $(\log f)''=-16x-96x/(2x-3)^2<0$. Dla $t_2>t_1$ iloraz $f(t_2+v)/f(t_1+v)$ jest więc malejący w $v$. Jego kowariancja z $H_k$ w rozkładzie dla $t_1$ jest niedodatnia. Wynika to przez zapis podwojonej kowariancji jako średniej iloczynu różnic na dwóch niezależnych próbach. Po podzieleniu przez średnią ilorazu otrzymujemy $E_k(t_2)\le E_k(t_1)$.

## Koncentracja i stała w wykładniku

Ustalmy $0<\delta<1$, $h=(\log k)/4$, $A=(1-\delta)h$, $B=(1+\delta)h$. Od tej chwili $t=0$ i $Z=\int_0^\infty v^{k-1}f(v)dv$. Poniższe szacunki obowiązują dla dostatecznie dużego $k$ przy ustalonym $\delta$. Na całej półosi, z dodatnimi stałymi bezwzględnymi,
\[
 c e^{9v-\pi e^{4v}}\le f(v)\le C e^{9v-\pi e^{4v}}.
\]
Istotnie $2-3/x$ mieści się między $2-3/\pi$ i 2. Niech $D=(1-\delta/2)h$. Całkowanie na $[D,D+1]$ daje $Z\ge cD^{k-1}\exp(-\pi e^4 k^{1-\delta/2})$. Masa na $[0,A]$ przed normalizacją wynosi najwyżej $A^{k-1}\int_0^\infty f$. Stąd $\Pr(V<A)\le e^{-c_\delta k}$, gdyż $A/D<1$.

Dla ogona z dodatkowym czynnikiem $e^v$ wykładnik w górnym ograniczeniu całkowanej funkcji to $G(v)=(k-1)\log v+10v-\pi e^{4v}$. Dla $v\ge B$ mamy $G'(v)\le-1$ od pewnego $k$. Całka jest zatem co najwyżej $C e^{G(B)}$. Po podzieleniu przez powyższą dolną granicę dla $Z$ logarytm jest najwyżej
\[
 (k-1)\log(B/D)+10B-\pi k^{1+\delta}+\pi e^4 k^{1-\delta/2}+O(1)
 \le -k^{1+\delta}.
\]
Tak więc $\mathbb E[e^V\mathbf1_{V>B}]\le e^{-k^{1+\delta}}$.

Na $v\le B$ zachodzi $H_k(v)\le\sum_{n\ge2}n^{-q}$, $q=1/2+(k-1)/(2B)$, z nierówności $1-y\le e^{-y}$ dla aktywnych składników. Suma jest najwyżej $2^{-q}(1+2/(q-1))$ przez porównanie z całką. Ogon $v>B$ wnosi najwyżej $2e^{-k^{1+\delta}}$. Po pomnożeniu logarytmu wyniku przez $(\log k)/k$ otrzymujemy górną granicę graniczną $-2\log2/(1+\delta)$.

Dla dolnego oszacowania wystarcza składnik $n=2$ na $V\ge A$. Daje on
\[
 E_k(0)\ge 2^{-1/2}(1-a_2/A)^{k-1}(1-e^{-c_\delta k}).
\]
Ponieważ $\log(1-a_2/A)=-a_2/A+O(A^{-2})$, dolna granica graniczna wynosi co najmniej $-2\log2/(1-\delta)$. Przejście z $\delta$ do zera kończy dowód. Jednostajność w $t$ wynika z dokładnego wskazania punktu maksimum przed rozpoczęciem asymptotyki.

## Co wynika dla wrońskianu

Dla $i+j\le m$ wpis wrońskianu jest, z czynnikiem $(-1)^{i+j}$, całką $\Psi_{m-i-j}(t)$. Nowe oszacowanie działa jednocześnie na wszystkich wpisach o $m-i-j\ge\eta r$ przy dowolnym ustalonym $\eta>0$. Ich względne błędy w modelu jednoskładnikowym są co najwyżej $\exp[-(2\eta\log2-o(1))r/\log r]$. Wynika to z monotoniczności $k/\log k$ dla $k>e$ i definicji granicy. Gdy $m=\lfloor cr\rfloor$, $1<c<2$, rzędy $i+j>m$ występują w prawym dolnym rogu macierzy $r\times r$ i wymagają pochodnych samego jądra. Liczba ostatnich wierszy, w których może zachodzić $m-i-j<\eta r$, jest co najwyżej $(2-c+\eta)r+O(1)$ przy $0<\eta<c-1$. To informacja o położeniu wpisów wymagających oddzielnej kontroli. Oszacowanie pozostałych wpisów również wymaga porównania z uwarunkowaniem odpowiedniego bloku, aby otrzymać znak wyznacznika.

Przy roboczej dolnej granicy $\liminf m(r)/r\ge1$ wykazanie całopółosiowego $m(r)\le(1+\varepsilon)r$ dla każdego ustalonego $\varepsilon>0$ i dostatecznie dużego $r$ dałoby granicę 1. Powyższy dowód ustala granicę dla $E_k$, a pytanie o istnienie i wartość granicy $m(r)/r$ pozostaje otwarte.
