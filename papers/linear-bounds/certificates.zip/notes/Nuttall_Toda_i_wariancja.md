# Jedno całkowanie mniej. Znak wrońskianu jako nierówność dla drugiej pochodnej

Niech \(r\ge2,\ m=2r-1,\ p=r-1\), \(X=\pi e^{4t}\) i \(f=\Psi_m\). Oznaczamy \(\tau_0=1\) oraz \(\tau_j=(-1)^{j(j-1)/2}\det[f^{(i+k)}]_{0\le i,k<j}\). Badamy, czy \(\tau_r>0\) na pozostałym przedziale \(\pi\le X<10r\).

## Kryterium dokładne

Tożsamość Desnanota–Jacobiego dla macierzy Hankela pochodnych ma postać
\[
 -(\log\tau_p)''=\frac{\tau_{p+1}\tau_{p-1}}{\tau_p^2}.
\]
Pochodne są względem \(t\). W niesygnowanych wyznacznikach pojawia się plus, a \(\epsilon_{p+1}\epsilon_{p-1}=-1\). Przy dodatnich \(\tau_p,\tau_{p-1}\) znak brakującego wrońskianu jest więc dokładnie znakiem \(-(\log\tau_p)''\). [Tożsamość Tody dla wyznaczników Hankela, wzór (1.5)](https://catalog.lib.kyushu-u.ac.jp/opac_download_md/3401/2007-3.pdf)

Dodatniość niższych rzędów wynika z wcześniejszego roboczego wyniku dla \(g=\Psi_{2r-2}\). Dla ścisłości, przejście do jednej dodatkowej całki zachowuje tu także ścisłe znaki wrońskianów. W macierzy dla \(f(t)=\int_t^\infty g(s)ds\) pierwszy wiersz jest całką po \(s>t\) z wiersza \((g(s),g'(s),\ldots)\), a pozostałe wiersze są ujemnymi wierszami kolejnych pochodnych \(g\) w \(t\). Przeniesienie pierwszego wiersza na koniec usuwa te znaki. Wyznacznik pod całką ma \(j-1\) węzłów zlewających się w \(t\) i ostatni węzeł \(s>t\). Jest niezerowy, ponieważ rodzina \(g,\ldots,g^{(j-1)}\) ma wszystkie początkowe wrońskiany niezerowe i jest rozszerzonym układem Czebyszewa (kolejne dzielenie przez pierwszą funkcję i twierdzenie Rolle’a z krotnościami). Znak wyznacza granica \(s\downarrow t\).

Niech \(Z(X)\) będzie całką Andréiefa rzędu \(p\) na uporządkowanych węzłach, z wagą \(H(u)e^{-XS(u)}\), gdzie
\[
 S(u)=\sum_{i=1}^p e^{4u_i},\qquad
 H(u)=\det[R_{L+j}(u_i)]_{i=1,\dots,p;\,j=0,\dots,p-1}
            \Delta(e^{4u})\,e^{5\sum_i u_i},\qquad L=m-p=p+1 .
\]
Funkcje \(R_k\) są sumą po \(n\) przesuniętych węzłami \(a_n=\frac12\log n\) różnic \(v_+^{k-1}/(k-1)!-v_+^k/k!\), z wagami \(n^{-1/2}\). W porównaniu z \(\tau_p\) usunięto dodatni czynnik o logarytmie liniowym w \(t\): każdy wiersz rozwinięcia theta wnosi \(e^tX\), a wielomiany pochodnych w Vandermondzie łącznie wnoszą \(X^{p(p-1)/2}\). Zatem \((\log\tau_p)''=(\log Z(X(t)))''\). Podwójnie wykładniczy zanik uzasadnia różniczkowanie pod całką. Pisząc \(Z_j=\int S^j H e^{-XS}\,du,\ Z=Z_0\), dostajemy warunek równoważny
\[
 X(ZZ_2-Z_1^2)< ZZ_1 .
\]
Pełna gęstość może mieć znak; interpretację probabilistyczną poniżej stosujemy tylko do wyraźnie dodatniej części. [Poprzednia nota i reprezentacja Andréiefa](https://chatgpt.com/library?file_id=libfile_fde3_f-3e2e47c29e4081919daa2a90fc0eee96_190e0645021881919deeacf23c4a3be0&account_id=personal)

## Nierówność udowodniona przed pierwszym progiem theta

Niech \(a=\log(2)/2,\ \Omega=\{0<u_1<\dots<u_p<a\}\), \(Z_\Omega=\int_\Omega H e^{-XS}du\). Symbole \(\mathbb E_\Omega,\operatorname{Var}_\Omega\) dotyczą znormalizowanej gęstości na \(\Omega\). Dla wszystkich \(p\ge1,\ X>0\) zachodzi
\[
 X\operatorname{Var}_\Omega(S)
 \le \frac{64X}{7p+64X}\,\mathbb E_\Omega S.
 \tag{1}
\]
W szczególności na całym przedziale \(\pi\le X\le10r\) prawa strona nie przekracza \(199\,\mathbb E_\Omega S/200\).

**Dowód.** Na \(\Omega\) obecny jest tylko pierwszy składnik theta. Z dokładnością do dodatniej stałej
\(H=\Delta(u)\Delta(e^{4u})\prod_i u_i^{L-1}e^{5u_i}P(u)\), gdzie
\(P=\mathbb E\prod_i(Y-u_i)\), \(Y\sim\mathrm{Gamma}(L,1)\). Niech \(P_*=\mathbb E Y^p=(L)_p\). W rozwinięciu \(P/P_*\) współczynnik dowolnego jednomianu bezkwadratowego stopnia \(j\) ma moduł \((L)_{p-j}/(L)_p\le L^{-j}\). Stąd
\[
 |P/P_*-1|\le e^{pa/L}-1\le\sqrt2-1,\qquad
 |\partial_i\partial_j P|/P_*\le e^{pa/L}/L^2\quad (i\ne j).
\]
Drugie pochodne po tej samej zmiennej znikają. W szczególności \(P>0\). Odejmując nieujemną formę z gradientu w hesjanie \(\log P\) i szacując normę przez maksymalną sumę modułów w wierszu, dostajemy \(\nabla^2\log P\preceq 3p L^{-2}I\).

Logarytmy obu czynników Vandermonde’a są wklęsłe na uporządkowanych węzłach. Dla drugiego korzystamy z \(e^{4v}-e^{4u}=2e^{2(v+u)}\sinh(2(v-u))\) i wklęsłości \(\log\sinh z\) na \(z>0\). Potęgi \(u_i^{L-1}\) wnoszą do \(-\nabla^2\log H\) co najmniej \((L-1)/a^2\) razy identyczność. Ponieważ \(L=p+1\), wynika \(-\nabla^2\log H\succeq7p I\).

Dla \(V=XS-\log H\) mamy \(\nabla^2V\succeq7p I+16X\operatorname{diag}(e^{4u_i})\). Nierówność wariancyjna Brascampa–Lieba na wypukłej komorze daje \(\operatorname{Var}(S)\le\mathbb E[\nabla S^\mathsf T(\nabla^2V)^{-1}\nabla S]\). Można ją zastosować najpierw z dodatkowymi wypukłymi barierami \(-\varepsilon\sum\log(\text{odległość od ściany})\), a następnie pozwolić \(\varepsilon\downarrow0\); wszystkie \(S\) i jego pierwsze pochodne są ograniczone na \(\Omega\). Ponieważ \(\partial_iS=4e^{4u_i}\) i \(e^{4u_i}\le4\), prawa strona po pomnożeniu przez \(X\) nie przekracza \([64X/(7p+64X)]\mathbb E_\Omega S\). Wreszcie \(r=p+1\le2p\), stąd \(7p/(7p+64X)\ge7/1287>1/200\) dla \(X\le10r\). [Nierówność wariancyjna Brascampa–Lieba](https://doi.org/10.1016/0022-1236(76)90004-5)

## Brakujący krok i znaczenie dla granicy

Niech \(R(t)=\log[Z(X(t))/Z_\Omega(X(t))]\). Rozkład logarytmu jest dokładny również przy dużym wkładzie obszaru zewnętrznego, o ile \(Z>0\), co zapewnia roboczy wynik o niższych rzędach. Z (1) wynika
\[
 -(\log Z_\Omega)''\ge16X\,\mathbb E_\Omega S\frac{7p}{7p+64X}.
\]
Do dowodu \(m(r)\le2r-1\) wystarczyłaby zatem nierówność
\[
 R''(t)<16X\,\mathbb E_\Omega S\,\frac{7p}{7p+64X}
 \quad(\pi\le X<10r).
\]
Jest to warunek wystarczający. Nie uzyskano go dla pełnego jądra. Nie ma podstaw, by zakładać, że \(R\) albo masa spoza \(\Omega\) są małe. Badaną wielkością jest druga pochodna względem \(t\); naturalnym pierwszym testem jest dodanie składnika \(n=2\), z zachowaniem wszystkich konfiguracji węzłów. Potem konieczny jest wspólny szacunek pozostałych składników. Dla samego celu asymptotycznego zysk jednego całkowania nie zmienia \(\limsup\); celem dalszego rozszerzenia jest dodatni ułamek \(r\) zaoszczędzonych całkowań.
