# Które zera dzety odpowiadają skali wrońskianu Nuttalla?

## Wyniki

W punkcie \(t=0\), przy \(m=2r-1\), najwyższy wrońskian jest wyznacznikiem macierzy \([a_{i+j}]_{0\le i,j<r}\), gdzie
\[
 \mu_n=\int_0^\infty u^n\Phi(u)\,du,\qquad a_n=\mu_n/n!=\Psi_{n+1}(0).
\]
Wynika to z \(\Psi_m^{(i+j)}=(-1)^{i+j}\Psi_{m-i-j}\) oraz odwrócenia kolejności wierszy i kolumn. Podpisany wrońskian jest tym wyznacznikiem pomnożonym przez \((-1)^{r(r-1)/2}\).

Dla \(r=8000\) potwierdzono przedziałowo zero na linii krytycznej na wysokości \(4816{,}4517<\gamma<4816{,}4518\). W dokładnym równaniu wyznaczonym przez to zero stosunek modułów składników z \(a_{15998}\) i \(a_{15996}\) należy do \((0{,}9999259,0{,}9999468)\). Składniki te mają przeciwne znaki. Dla nieograniczonego \(r\) wysokość odpowiadająca równej wadze tych dwóch najwyższych parzystych momentów jest asymptotycznie równa \(4r/\log r\).

Pierwsze dziesięć zer daje inny wynik. Przy dokładnych niższych momentach parzystych i dokładnych rzędnych zer otrzymujemy jednostronne przybliżenie \(a_{15998}\) z błędem względnym mniejszym od \(5{,}4\cdot10^{-44}\). Ta sama formuła silnie wzmacnia błędy danych wejściowych. Poniższy rachunek wyznacza to wzmocnienie oraz dokładnie wskazuje, czego jeszcze potrzeba do ustalenia znaku wrońskianu.

## 1. Dokładne równanie od każdego znanego zera

W normalizacji z pytania mamy
\[
 F(x)=\int_0^\infty\Phi(u)\cos(\sqrt{x}\,u)\,du
 =\frac18\xi\!\left(\frac12+\frac{i\sqrt x}{2}\right)
 =\sum_{j\ge0}(-1)^j a_{2j}x^j,\qquad x\ge0.
\]
Szereg jest bezwzględnie zbieżny dzięki podwójnie wykładniczemu zanikowi jądra. Dla każdego rzeczywistego \(\gamma\) z \(\zeta(1/2+i\gamma)=0\) mamy więc \(F(4\gamma^2)=0\). Użycie konkretnego zera na prostej nie wymaga założenia RH. To wzór dla pełnej sumy theta. Wielomian uzyskany przez pozostawienie dwóch składników theta w poprzedniej nocie ma oddzielnie zdefiniowane zera. [Rodgers i Tao, wzory (1)–(3)](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/D4B85BA067E2D5A71D87E4FFB0D21E46/S2050508620000062a.pdf) · [Nuttall, wzory (1.2)–(1.3), (4.3)](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf)

## 2. Wysokość odpowiadająca dwóm sąsiednim momentom

Weźmy \(n=2r-4\) dla \(r\ge2\) i oznaczmy \(s_n=\sqrt{\mu_{n+2}/\mu_n}\). Stosunek modułów składników szeregu z \(a_{n+2}\) i \(a_n\) przy \(x=4\gamma^2\) jest dokładnie równy \((\gamma/\gamma_*)^2\), gdzie
\[
 \gamma_*=\frac12\sqrt{a_n/a_{n+2}}=
 \frac{\sqrt{(n+1)(n+2)}}{2s_n}.
\]
Wysokość \(\gamma_*\) jest ustalana przez jądro. Poszukujemy potwierdzonych zer w jej pobliżu.

**Oszacowanie dla pełnej sumy.** Dla \(X=\pi e^{4u}\) mamy
\[
                    4X-13\le-\Phi'(u)/\Phi(u)\le4X,\qquad u\ge0.       \tag{1}
\]
Pochodna logarytmu pojedynczego składnika theta wynosi \(5+8x/(2x-3)-4x\), gdzie \(x=j^2 X\). Dla \(x\ge\pi\) suma dwóch pierwszych wyrazów mieści się między 9 i 13. Ponadto \(\phi_j/\phi_1\le 2j^4 e^{-(j^2-1)X}\). W średniej ważonej przy przejściu z \(X\) do \(j^2 X\) nadwyżka wynosi co najwyżej \(2X\sum_{j\ge2}j^6e^{-(j^2-1)X}\le 2X\,64e^{-3X}/(1-64e^{-3X})<0{,}04\), bo \(j\le2^{j-1}\), \(j^2-1\ge3(j-1)\), a górna granica maleje od \(X=\pi\). Stąd (1).

Nadajmy \(U\) gęstość \(u^n\Phi(u)/\mu_n\). Całkowanie przez części daje
\[
 n+1=\mathbb E[U(-\Phi'/\Phi)(U)]\ge s_n(4\pi e^{4s_n}-13).             \tag{2}
\]
Aby uzasadnić ostatni krok, rozwijamy \(U(e^{4U}-1)\) w dodatni szereg potęg od stopnia 2. Dla \(j\ge2\) mamy \(\mathbb E U^j\ge s_n^j\). Dla pozostałego wyrazu liniowego współczynnik \(4\pi-13\) jest ujemny, a \(\mathbb E U\le s_n\). W szczególności \(s_n<1{,}67\) dla wszystkich \(0\le n\le16018\) przez podstawienie w (2) i monotoniczność jego prawej strony dla \(s\ge1{,}67\).

Niech \(h_n>0\) będzie rozwiązaniem \(4\pi h_ne^{4h_n}=n\) dla \(n>0\). W metodzie siodła dla pierwszego składnika pojawia się ten sam punkt. Dla pełnego jądra można uzyskać
\[
       s_n=h_n+O(\log n/\sqrt n),\qquad
       \gamma_*(r)\sim\frac{4r}{\log r}.
\]
Jeżeli \(s_n>h_n\), to (2) daje najpierw \(s_n<h_n+1\) dla dużych \(n\), a następnie \(e^{4(s_n-h_n)}\le1+(1+13s_n)/n\). To dowodzi górnej granicy. Dla dolnej przyjmijmy \(\eta=\sqrt{16h_n\log n/n}\), \(a=h_n-\eta\), \(b=h_n-\eta/2\). Na \(0<u\le b\) logarytmiczna pochodna \(u^n\Phi(u)\) wynosi co najmniej \(n/b-4\pi e^{4b}\ge(n/h_n)(1-e^{-2\eta})\ge n\eta/h_n\) dla dużych \(n\). Przesuwając odcinek \([0,a]\) o \(b-a\) w prawo i porównując całki, dostajemy \(\Pr(U\le a)\le e^{-n\eta^2/(2h_n)}=n^{-8}\). Stąd \(s_n\ge a\sqrt{1-n^{-8}}\). Ostateczna równoważność wynika z \(h_n\sim(\log n)/4\) i \(n=2r-4\). [Punkt siodłowy w pracy Nuttalla, §3](https://publish.uwo.ca/~jnuttall/RHPart1p.pdf)

**Konkretny przypadek.** Dla \(n=15996\) program na końcu noty wykazuje \(4816{,}58<\gamma_*<4816{,}63\). W tym celu sprawdza ze znakiem całkę \(\int(u^2-(n+1)(n+2)/(4g^2))u^n\Phi(u)\,du\) na obu końcach przedziału dla \(g\). Na \([1{,}60,1{,}72]\) całkowanie przedziałowe wykorzystuje monotoniczność pochodnej logarytmu \(u^n\phi_1\). Wyższe składniki podnoszą wagę najwyżej o względny czynnik \(2\cdot16e^{-3X}/(1-16e^{-3X})\). Dwa ogony ograniczamy stycznymi do wklęsłego logarytmu pierwszej wagi oraz globalnym \(\Phi\le2\phi_1\). Usunięto wspólny dodatni czynnik. Przedziały otrzymane dla całek mieszczą się odpowiednio w \((-5{,}32,-1{,}32)\cdot10^{-7}\) i \((1{,}56,5{,}57)\cdot10^{-7}\).

Numeryczna lokalizacja przez funkcję zetazero wskazała zera o indeksach 4326 i 4327. Istnienie zera w każdym z przedziałów \((4816{,}4517,4816{,}4518)\) i \((4817{,}2328,4817{,}2329)\) zostało osobno sprawdzone przez przeciwne ścisłe znaki rzeczywistej funkcji Hardy’ego na końcach. Dowód istnienia nie korzysta z numeracji ani z kompletności listy. Wartości liczymy przez wzór Eulera–Maclaurina z \(L=4096\) i poprawką do \(B_{16}\). Z \(\sup |B_{16}(\{x\})|/16!\le4/(2\pi)^{16}\) wynika granica modułu błędu \(4\sqrt L\,[(t+17)/(2\pi L)]^{16}/(31/2)\) w tym zakresie. Faza Hardy’ego wynosi \(\Im\log\Gamma(1/4+it/2)-(t/2)\log\pi\). Dla niższego z tych zer amplitudy dwóch badanych składników mają iloraz między \(0{,}9999259\) a \(0{,}9999468\). Ponieważ pełny szereg znika, suma wszystkich pozostałych składników ma moduł mniejszy od \(0{,}000075\) modułu składnika z \(a_{15996}\). Nie otrzymujemy osobnej granicy dla pojedynczej sumy częściowej z pozostałych składników.

## 3. Co dają pierwsze dziesięć zer

Dla \(k\ge1\) i \(x>0\) zapiszmy
\[
 S_{k-1}(x)=\sum_{j<k,\ j\ge0}(-1)^ja_{2j}x^j,\qquad
 T_k(x)=\frac{F(x)-S_{k-1}(x)}{(-x)^k},\qquad T_k(0)=a_{2k}.
\]
Dla różnych znanych zer na prostej z dodatnimi rzędnymi \(\gamma_i\), przy \(x_i=4\gamma_i^2\), znamy dokładną wartość \(T_k(x_i)=(-1)^{k+1}S_{k-1}(x_i)/x_i^k\) jako funkcję niższych momentów. Niech \(\widehat a_{2k}\) będzie wartością w zerze wielomianu stopnia mniejszego od \(q\), interpolującego te wartości w \(q\) węzłach. Wówczas
\[
           |a_{2k}-\widehat a_{2k}|\le \left(\prod_{i=1}^q x_i\right)a_{2k+2q}.       \tag{3}
\]
Istotnie, \(\partial_x\cos(v\sqrt x)=-(v^2/2)\int_0^1\cos(sv\sqrt x)ds\). Powtarzanie tego wzoru daje \(|\partial_x^j\cos(v\sqrt x)|\le j!v^{2j}/(2j)!\), z granicą w zerze przez ciągłość. Zatem \(|F^{(j)}(x)|\le j!a_{2j}\) na dodatniej półosi. Reszta całkowa Taylora w zmiennej \(x\) daje \(T_k(x)=(-1)^k\int_0^1(1-s)^{k-1}F^{(k)}(sx)ds/(k-1)!\). Całka beta po \(q\) różniczkowaniach daje \(|T_k^{(q)}(x)|\le q!a_{2k+2q}\). Twierdzenie o reszcie interpolacji na przedziale zawierającym 0 oraz wszystkie \(x_i\) dowodzi (3).

Dla \(2k=15998\), \(q=10\), górne granice dziesięciu rzędnych to kolejno \(15,22,26,31,33,38,41,44,49,50\). Z (2) i \(a_{j+2}/a_j=s_j^2/[(j+1)(j+2)]\) dostajemy \((\prod x_i)a_{16018}/a_{15998}<5{,}4\cdot10^{-44}\). Znamy również znak błędu. W zerze \((-1)^q T_k^{(q)}(0)=q!a_{2k+2q}\), a na całym przedziale odchylenie tej pochodnej jest co najwyżej \(10^4(q+1)!a_{2k+2q+2}\) przez oszacowanie następnej pochodnej. Względne odchylenie jest mniejsze od \(0{,}002\) dzięki (2) dla \(j=16018\). Pochodna zachowuje znak, wobec czego \(0<a_{15998}-\widehat a_{15998}<5{,}4\cdot10^{-44}a_{15998}\). Są to dokładne nierówności przy dokładnych danych wejściowych. [Rzędne zer](https://numberdb.org/Zeros_of_the_Riemann_zeta_function?entry=1) · [Pochodzenie certyfikowanych danych o zerach](https://www.lmfdb.org/zeros/zeta/Source)

**Wrażliwość wzoru.** Jeśli zmienimy jedynie \(a_0\) w danych wejściowych do interpolacji, moduł współczynnika tej zmiany to wartość w zerze interpolantu funkcji \(x^{-k}\). Jest ona co najmniej \(x_1^{-k}\) dla węzłów rosnących. We wzorze Newtona każdy kolejny wyraz ma dodatni znak, ponieważ różnica dzielona rzędu \(j\) ma znak \((-1)^j\) i mnożymy ją przez \(j\) ujemnych czynników. Z (2) wynika przez mnożenie kolejnych nierówności \(a_n/a_0\le 1{,}67^n/n!\) dla parzystego \(n=15998\). Wzmocnienie błędu względnego w \(a_0\) względem docelowego \(a_n\) jest więc co najmniej
\[
 \frac{a_0}{a_n x_1^{n/2}}\ge\left(\frac{n}{e\cdot1{,}67\cdot30}\right)^n>10^{33000}.
\]
Ta wrażliwość dotyczy niezależnego błędu jednego wejścia w podanej formule. Nie wyklucza metody wykorzystującej wspólne ograniczenia na błędy lub inne współrzędne.

## 4. Co pozostaje do wykazania

Niech \(H_r=[a_{i+j}]\), \(A=H_{r-1}\), \(b=(a_{r-1},\ldots,a_{2r-3})^\mathsf T\). Gdy \(A\) jest odwracalna, zachodzi
\[
 \det H_r=\det A\,(a_{2r-2}-b^\mathsf T A^{-1}b).
\]
Zera dają powyższe relacje między parzystymi momentami. Do ustalenia znaku tą metodą potrzeba także znaku \(\det A\) i porównania \(a_{2r-2}\) z progiem zawierającym momenty obu parzystości. Ani równowaga dwóch składników, ani granica (3) nie dostarcza takiego porównania.

Dla \(t>0\) mamy dodatkowo dokładny początek rozszerzenia. Przy \(\lambda=2\gamma\), niech \(C_t=\int_0^\infty\Phi(t+v)\cos(\lambda v)dv\), \(S_t=\int_0^\infty\Phi(t+v)\sin(\lambda v)dv\). Podział całki w zerze dzety w punkcie \(t\) pokazuje, że
\[
 \cos(\lambda t) C_t-\sin(\lambda t)S_t=-\int_0^t\Phi(u)\cos(\lambda u)du .
\]
Oznacza to, że po przesunięciu pojawia się też transformata sinusowa. W tej nocie nie wykazano globalnej nierówności \(m(r)\le2r-1\) ani istnienia granicy \(m(r)/r\).

## Kod kontroli liczbowej

Python 3 z mpmath. Kod sprawdza przedział dla wysokości równych wag, oba zera przez zmianę znaku, stosunek amplitud i stałe w (3). Nie oblicza wrońskianu rzędu 8000.

~~~python
from mpmath import iv
from fractions import Fraction
from math import prod
iv.dps = 35
I = iv.mpf
n = 15996
def x(u):
    return iv.pi * iv.exp(4*u)
def log_weight(u):
    z=x(u)
    return n*iv.log(u)+u+iv.log(z)+iv.log(2*z-3)-z
def slope(u):
    z=x(u)
    return n/u+5+8*z/(2*z-3)-4*z
a, b = I('1.60'), I('1.72')
scale = log_weight(I('1.66'))
g =[I('4816.58'), I('4816.63')]
c2 = [(n+1)*(n+2)/(4*y*y) for y in g]
x_a=x(a)
theta_error=2*16*iv.exp(-3*x_a)/(1-16*iv.exp(-3*x_a))
assert theta_error.b < I('1e-100').a
theta = 1+I([0,theta_error.b])
N=24000
h=(b-a)/N
tot=[I(0), I(0)]
dl=slope(a)
for i in range(N):
    lo=a+h*i
    hi=a+h*(i+1)
    mid=(lo+hi)/2
    dr=slope(hi)
    rad=h*max(abs(dl).b,abs(dr).b)/2
    den=h*theta*iv.exp(log_weight(mid)-scale+I([-rad.b,rad.b]))
    for j in (0,1):
        tot[j]+=den*(I([lo.a,hi.b])**2-c2[j])
    dl=dr
for j in (0,1):
    d=-slope(b)
    assert a.b**2 < c2[j].a and c2[j].b < b.a**2
    errL=2*c2[j]*iv.exp(log_weight(a)-scale)/slope(a)
    errR=2*iv.exp(log_weight(b)-scale)*((b*b+c2[j])/d+2*b/d**2+2/d**3)
    tot[j]+=I([-errL.b,errR.b])
assert tot[0].b < 0 and tot[1].a > 0
print([str(z) for z in tot])
N0=15998
uppers=[15,22,26,31,33,38,41,44,49,50]
bound=prod(Fraction((2*u*167)**2, 100**2*(N0+2*j-1)*(N0+2*j)) for j,u in enumerate(uppers,1))
assert bound < Fraction(54,10**45)
assert (I('1.67')*(4*iv.pi*iv.exp(4*I('1.67'))-13)).a>16019
assert (I(N0)*iv.log10(I(N0)/(iv.exp(1)*I('1.67')*30))).a>33000
from math import factorial
def hardy_interval(t):
    # Euler-Maclaurin for the Dirichlet series tail; B_2,...,B_16.
    L=4096
    bern=[(1,6),(-1,30),(1,42),(-1,30),(5,66),(-691,2730),(7,6),(-3617,510)]
    s=iv.mpc(I(1)/2,t)
    total=sum(iv.exp(-s*iv.log(j)) for j in range(1,L))
    tail=iv.exp(-s*iv.log(L))
    total+=tail*(L/(s-1)+I(1)/2)
    rising=s
    for j,(num,den) in enumerate(bern,1):
        total+=tail*rising*I(num)/(den*factorial(2*j)*L**(2*j-1))
        rising*= (s+2*j-1)*(s+2*j)
    error=4*iv.sqrt(L)/(I(31)/2)*((t+17)/(2*iv.pi*L))**16
    theta=iv.loggamma(iv.mpc(I(1)/4,t/2)).imag -t*iv.log(iv.pi)/2
    return (iv.exp(iv.j*theta)*total).real+I([-error.b,error.b])
heights=['4816.4517','4816.4518','4817.2328','4817.2329']
zvals=[hardy_interval(I(t)) for t in heights]
print([str(z) for z in zvals])
assert (zvals[0]*zvals[1]).b < 0 and (zvals[2]*zvals[3]).b < 0
ratio=I([I(heights[0]).a,I(heights[1]).b])**2/I([g[0].a,g[1].b])**2
print(ratio)
assert ratio.a > I('.99992').b and ratio.b < 1
~~~
