# Całka Andréiefa po obu stronach pierwszego progu theta

## Teza

Niech $a=(\log 2)/2$, $0<\eta\le1$, $h=\exp(-16/\eta)$, $B=a+h$. Rozpatrujemy $p\ge2$, $L=m-p$, $\eta p\le L\le p$, $L$ całkowite, i $X=\pi e^{4t}$, $t\ge0$. W szczególności $L\ge1$ i $B<1/2<(\log 3)/2$. Wprowadzamy
\[
 f_k(u)=u^{k-1}(k-u)/k!\quad(u>0),\qquad
 R_k(u)=\sum_{n:\,a_n<u} n^{-1/2} f_k(u-a_n),\quad a_n=(\log n)/2.
\]
Niech $I$ będzie iloczynem wyznacznika o wierszach $(R_{L+j}(u_i))_{0\le j<p}$, czynnika Vandermonde’a $\Delta(e^{4u})=\prod_{i<j}(e^{4u_j}-e^{4u_i})$ oraz wagi $\prod_i e^{5u_i-Xe^{4u_i}}$. Przez $I_0$ oznaczamy ten sam wzór ze wszystkimi $R$ zastąpionymi przez $f$. Z wcześniejszego wyprowadzenia Andréiefa znak całki $I$ po całej dodatniej ortancie daje znak wymaganego podpisanego wrońskianu. Całka po pudełku stanowi jej część. Wartości na progach nie wpływają na całki.

Połóżmy $Q=[0,B]^p$. Dla wszystkich dostatecznie dużych $p$ zachodzi jednostajnie względem $L,X$
\[
    \int_Q |I-I_0|\le \big[(1+100p^2e^{-4p})^p-1\big]\int_Q I_0
       <\tfrac12\int_Q I_0.
\]
Stąd wkład całego pudełka jest ściśle dodatni. Oszacowanie obejmuje dowolną liczbę węzłów po dowolnej stronie progu, także konfiguracje o bardzo małych odstępach. Promień jest zachowawczy.

## Porównanie jednego wiersza

Ustalmy pozostałe wiersze, w dowolnej kombinacji wierszy nieprzesuniętych i przesuniętych. Ich dopełnienia algebraiczne dają współczynniki $c_j$. Część czynnika Vandermonde’a zawierającą zmienną $u$ bierzemy w module. Niech
\[
 F=\max_{0\le j<p}|c_j|/(L+j)!,\qquad H=F\prod_{i\ne k}(1+e^{4u_i}).
\]
Gdy $F=0$, obie całki w tym wierszu znikają. Dla $F>0$ oznaczmy przez $A$ całkę po $0<u<B$ z modułu kombinacji nieprzesuniętej $\sum c_j f_{L+j}(u)$ pomnożonego przez $\prod_{i\ne k}|e^{4u}-e^{4u_i}|e^{5u-Xe^{4u}}$.

Na $J=[0,1/4]$ kombinacja to $u^{L-1}P(u)$, gdzie $P(u)=\sum b_j u^j(L+j-u)$ i $b_j=c_j/(L+j)!$. Przynajmniej jeden współczynnik $P$ ma moduł $\ge F$: weźmy $j$ o największym $|b_j|$ i użyjmy współczynnika $(L+j)b_j-b_{j-1}$, przy $b_{-1}=0$. Stopień jest najwyżej $p$. Dla czynnika liniowego $u-z$ średnia na $J$ z $\log(|u-z|/(1+|z|))$ wynosi co najmniej $-1-\log16$. Istotnie dla $|z|\le1$ minimum średniej logarytmu odległości dla rzeczywistego środka przypada w połowie $J$, a dzielnik nie przekracza 2. Dla $|z|>1$ iloraz jest co najmniej $3/8$. Iloczyn $|\mathrm{lc}(P)|\prod(1+|z|)$ jest co najmniej największym modułem współczynnika $P$. Ponadto $|e^{4u}-e^{4v}|/(1+e^{4v})\ge\min(|u-v|,1/4)$ dla $u,v\ge0$. Dla $u\ge v$ używamy $e^{4(u-v)}-1\ge4(u-v)$, a dla $v>u$ nierówności $(1-e^{-4d})/2\ge\min(d,1/4)$, $d=v-u$. Średnia logarytmu prawej strony na $J$ wynosi co najmniej $-1-\log8$, co wynika przez przesunięcie $v$ do środka $J$. Średnia $\log u$ wynosi $-1-\log4$. Ponieważ $L\le p$, suma tych strat jest mniejsza niż $10p$. Nierówność Jensena daje
\[
 A\ge (H/4)e^{-10p-e X}.
\]

Na całym $[0,B]$ dostępne są jedynie indeksy theta 1 i 2. Nowy wiersz to suma starego wiersza i $2^{-1/2}\mathbf1_{u>a}(f_{L+j}(u-a))_j$. Dla $a<u<B$ kombinacja przesunięta ma moduł najwyżej $2p^2 F h^{L-1}$, gdyż $L+j<2p$, $0<u-a<h<1$. Czynniki z pozostałych węzłów po wyłączeniu $\prod(1+e^{4u_i})$ są w module co najwyżej $e^{2(p-1)}$, bo $B<1/2$. Waga jest co najwyżej $e^{5/2-4X}$. Całka z modułu wiersza przesuniętego z tymi samymi wagami jest zatem co najwyżej $2p^2 H h^L e^{2p+5/2-4X}$. Dzieląc przez poprzednią dolną granicę i używając $L\ge\eta p$, dostajemy iloraz co najwyżej
\[
 q_p=100p^2 e^{12p}h^L\le100p^2e^{-4p}.
\]

## Cały wyznacznik

Rozwijamy wyznacznik wieloliniowo po wierszach. Dla każdego zbioru $S$ wierszy przesuniętych moduł odpowiedniego składnika po scałkowaniu jest najwyżej $q_p^{|S|}\int_Q|I_0|$. Wynika to przez kolejne stosowanie porównania jednego wiersza i twierdzenia Tonellego. Kluczowa jest niezależność ilorazu od dopełnień algebraicznych i położeń pozostałych węzłów. Sumujemy po niepustych $S$.

Pozostaje równość $|I_0|=I_0$ prawie wszędzie na $Q$. Wyznacznik wierszy nieprzesuniętych to
\[
 \frac{\Delta(u)\prod u_i^{L-1}}{\prod_{j=0}^{p-1}(L+j)!}\,\mathbb E\prod_{i=1}^p(Y-u_i),\qquad Y\sim\mathrm{Gamma}(L,1).
\]
Tożsamość otrzymuje się przez rozwinięcie kolumn $u_i^j(L+j-u_i)$ i użycie momentów gammy $(L)_k$. Ponieważ $B<1/2$, zdarzenie $Y\ge2$ wnosi co najmniej $e^{-2}(2-B)^p$ (całkowity kształt $L\ge1$). Ujemna część ma moduł najwyżej $B^p$, gdyż może wystąpić tylko przy $Y<B$. Dla $p\ge2$ pierwsza granica jest większa od drugiej. Czynniki $\Delta(u)$ i $\Delta(e^{4u})$ mają ten sam znak, co kończy dowód.

## Zastosowanie i otwarta nierówność

Dla ustalonego $0<\varepsilon<1$, $m=\lfloor(1+\varepsilon)r\rfloor$, każdy brakujący rząd $m/2<p\le r$ spełnia $(\varepsilon/2)p\le L<p$ dla $r\ge2/\varepsilon$. Wystarcza więc $h=\exp(-32/\varepsilon)$ niezależne od $r,p,t$. Niższe rzędy są objęte wcześniejszym roboczym wynikiem na poziomie $2p$, jeśli się go przyjmie. Do dodatniości na całej ortancie wystarczyłoby teraz wykazać
\[
 \int_{\max u_i>B} I_-\,d\mathbf u < \int_Q I\,d\mathbf u +\int_{\max u_i>B} I_+\,d\mathbf u,
 \qquad I_\pm=\max(\pm I,0).
\]
Ta nierówność pozostaje otwarta. Dla $X$ stałego nie ma podstaw do pominięcia obszaru zewnętrznego. Z dowodu nie wynika globalna przewaga modelu jednoskładnikowego ani wartość granicy $m(r)/r$.
