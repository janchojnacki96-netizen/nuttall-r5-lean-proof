from fractions import Fraction
from math import factorial
from itertools import permutations
from mpmath import iv
iv.dps=36
fac=list(map(factorial,range(7)))
zero=iv.mpf(0)
one=iv.mpf(1)
tail=iv.mpf(['-1e-55','1e-55'])
perms={p:[(sigma,(-1)**sum(sigma[i]>sigma[j] for j in range(p) for i in range(j))) for sigma in permutations(range(p))] for p in range(1,5)}
def val(x):
    return iv.mpf(x.numerator)/x.denominator
def check(a,b):
    X=iv.mpf([val(a).a,val(b).b])
    mat=[[tail for j in range(4)] for i in range(4)]
    for n in range(1,8):
        q=n*n
        alpha=[one]; beta=[one]
        for j in range(1,4):
            alpha.append(alpha[-1]*(-(q-1)*X)/j)
            beta.append(beta[-1]*(-q*X)/j)
        weight=q*iv.exp(-(q-1)*X)
        G=[[sum((alpha[i-k]*alpha[j-k]*beta[k] for k in range(min(i,j)+1)),zero) for j in range(4)] for i in range(4)]
        for i in range(4):
            for j in range(i+1):
                a0=G[i][j]
                shifted=(G[i-1][j] if i else zero)+(G[i][j-1] if j else zero)+(G[i-1][j-1] if i and j else zero)
                mat[i][j]+=weight*((2*q*X-3)*a0+2*q*X*shifted)
                mat[j][i]=mat[i][j]
    for p in range(1,5):
        score=zero
        for sig,sgn in perms[p]:
            t=one*sgn
            for i in range(p):
                t*=mat[i][sig[i]]
            score+=t
        if not bool((score*((-1)**(p*(p-1)//2)))>0):
            return False
    return True
assert 2*32**6*40*8**4*iv.exp(-iv.mpf('0.9')*(64-1)*3)<iv.mpf('1e-55')
a=Fraction(3); b=Fraction(16)
todo=[(a,b)]; accepted=[]
while todo:
    l,r=todo.pop()
    if check(l,r):
        accepted.append((l,r))
    else:
        assert r-l>Fraction(1,10**12),(l,r)
        mid=(l+r)/2
        todo.extend([(mid,r),(l,mid)])
assert accepted[0][0]==a and accepted[-1][1]==b
assert all(x[1]==y[0] for x,y in zip(accepted,accepted[1:]))
print('checked closed adjacent cells',len(accepted),'X',a,b,'minimum width',min(r-l for l,r in accepted),flush=True)
