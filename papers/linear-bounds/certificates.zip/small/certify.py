"""Full-kernel interval proof for orders 5, 6, 7. Python 3 + mpmath 1.3.
Run inside this directory. Relative dependency: ../historical32/{przedzial,theta}.py.
Integers in the derivative oracle have scale 2^1150. No cached input is read.
"""
import csv
import sys
from fractions import Fraction as Q
from functools import lru_cache
from itertools import permutations
from math import factorial
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'historical32'))
import przedzial as p

JETS = 90
ORDER = 24
RANK = 7
BITS = 300
SCALE = 1 << BITS
M = 10**6

def ceil(q):
    return -(-q.numerator // q.denominator)

def negate(ab):
    a,b = ab
    return -b,-a

@lru_cache(maxsize=32)
def jets(c, count):
    """Derivatives of Phi at c. Enclose the omitted n >= 25 on radius 1/8."""
    t = p.rational(c)
    y = p.iv.pi*p.iv.exp(4*t)
    terms = [(y*n*n,p.iv.exp(t-y*n*n)) for n in range(1,25)]
    sums = []
    for _ in range(count+2):
        sums.append(p.dyadic_interval(sum(w for _,w in terms)))
        terms = [(x,x*w) for x,w in terms]
    out = []
    for k,pol in enumerate(p.series_polynomials(count)):
        a = sum(v*(l if v>=0 else u) for v,(l,u) in zip(pol,sums))
        b = sum(v*(u if v>=0 else l) for v,(l,u) in zip(pol,sums))
        err = (p.H >> 900)*factorial(k)*8**k
        out.append((a-err,b+err))
    return out

def integrate(phi,h):
    """Integral from c to c+h by the Taylor polynomial, with a Cauchy tail."""
    lo=hi=0
    w=h
    for j,(a,b) in enumerate(phi):
        l,u=p.divide(a*w.numerator,b*w.numerator,w.denominator)
        lo+=l
        hi+=u
        w*=h/(j+2)
    radius=ceil(p.H*h*M*(8*h)**len(phi)/(1-8*h))
    return lo-radius,hi+radius

def anchors():
    h=Q(1,32)
    current=(0,p.H >> 500)
    result={Q(2):current}
    for i in reversed(range(64)):
        c=i*h
        a,b=integrate(jets(c,JETS),h)
        current=(current[0]+a,current[1]+b)
        result[c]=current
    return result

def check_cell(l,u,base):
    c,h=(l+u)/2,(u-l)/2
    anchor=Q(int(32*c),32)
    a,b=integrate(jets(anchor,JETS),c-anchor)
    deriv=[(base[anchor][0]-b,base[anchor][1]-a)]
    deriv.extend(negate(ab) for ab in jets(c,2*RANK-2+ORDER))
    def entry(index,k):
        # Congruence by diag(16^-i); variable equals (t-c)/h.
        a,b=deriv[index+k]
        weight=h**k/factorial(k)
        den=(weight.denominator << (p.BITS-BITS+4*index))
        return p.divide(a*weight.numerator,b*weight.numerator,den)
    const=[entry(i,0) for i in range(2*RANK-1)]
    basis,signs=p.hankel_basis([(a+b)//2 for a,b in const],RANK,BITS)
    if signs != [(-1)**i for i in range(RANK)]:
        raise ArithmeticError(('midpoint',c,signs))
    bound,normprod=p.transformed_magnitude(basis,const,BITS,signs)
    # Each normalized entry has modulus <= 2*M*12! on |z-c|<=1/16.
    tail=Q(normprod*RANK*2*M*factorial(12),SCALE**2)*(16*h)**(ORDER+1)/(1-16*h)
    for k in range(1,ORDER+1):
        coeff,_=p.transformed_magnitude(basis,[entry(i,k) for i in range(2*RANK-1)],BITS)
        bound+=coeff
        if bound>=SCALE:
            return Q(1)
    return Q(bound,SCALE)+tail

def witness():
    # Strictly wrong fifth determinant of Phi alone at t=0, if its pivots certify.
    for a in range(65):
        c=Q(a,128)
        vals=jets(c,9)
        entries=[p.divide(l,u,1 << (p.BITS-BITS+4*i)) for i,(l,u) in enumerate(vals)]
        basis,sg=p.hankel_basis([(l+u)//2 for l,u in entries],5,BITS)
        bound,_=p.transformed_magnitude(basis,entries,BITS,sg)
        if bound<SCALE and sum(v<0 for v in sg)%2:
            return c,sg,ceil(Q(bound*10**9,SCALE))
    raise ArithmeticError('No certified fifth-order witness found')

def main():
    p.iv.prec=p.BITS+60
    p.mp.prec=BITS+80
    print("m=0 witness (t, pivots, norm upper times 1e9):",witness(),flush=True)
    raw=jets(Q(0),9)
    values=[p.iv.mpf([a,b])/p.H for a,b in raw]
    determinant=p.iv.mpf(0)
    for perm in permutations(range(5)):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(5) for j in range(i+1,5))
        term=p.iv.mpf(sign)
        for i,j in enumerate(perm):
            term*=values[i+j]
        determinant+=term
    lo=p.lower_dyadic(determinant._mpi_[0],0)
    hi=p.upper_dyadic(determinant._mpi_[1],0)
    if not lo<=hi<0:
        raise ArithmeticError('Invalid fifth determinant witness')
    print("W5(Phi;0) integer enclosure:",lo,hi,flush=True)
    base=anchors()
    print("Integrated 64 analytic panels",flush=True)
    pending=[(Q(i,128),Q(i+1,128)) for i in reversed(range(64))]
    maximum=0
    count=0
    with open(Path(__file__).with_name('cells.csv'),'w') as output:
        writer=csv.writer(output)
        writer.writerow(['t_from','t_to','rank','norm_upper_times_1e9'])
        while pending:
            l,u=pending.pop()
            bound=check_cell(l,u,base)
            cap=ceil(10**9*bound)
            if cap<=875000000:
                writer.writerow([l,u,RANK,cap])
                maximum=max(maximum,cap)
                count+=1
            else:
                if u-l<=Q(1,2**20):
                    raise ArithmeticError(('unresolved',l,u))
                mid=(l+u)/2
                pending.extend([(mid,u),(l,mid)])
    print('PASS',count,'cells covering [0,1/2]; maximum numerator:',maximum)
if __name__=='__main__':
    main()
