"""Check all leading Wronskians of the unintegrated kernel on [0, 1/2]."""
import csv
import sys
from fractions import Fraction
from math import factorial

sys.dont_write_bytecode = True
import certify as core

RANK = 4
MAX_DERIVATIVE = 2 * (RANK - 1)
SIGNS = [1, -1, 1, -1]
CELL_COUNT = 64


def scaled_diagonal(jets, half_width, degree):
    weight = half_width**degree / factorial(degree)
    entries = []
    for index in range(MAX_DERIVATIVE + 1):
        lower, upper = jets[index + degree]
        shift = core.p.BITS - core.BITS + 4 * index
        denominator = weight.denominator << shift
        entries.append(core.p.divide(lower * weight.numerator,
                                     upper * weight.numerator, denominator))
    return entries


def check_cell(left, right):
    centre = (left + right) / 2
    half_width = (right - left) / 2
    jets = core.jets(centre, MAX_DERIVATIVE + core.ORDER + 1)
    constant = scaled_diagonal(jets, half_width, 0)
    midpoints = [(lo + hi) // 2 for lo, hi in constant]
    basis, pivots = core.p.hankel_basis(midpoints, RANK, core.BITS)
    if pivots != SIGNS:
        raise ArithmeticError(f'Unexpected signs at {centre}: {pivots}')
    bound, norm_product = core.p.transformed_magnitude(basis, constant, core.BITS, SIGNS)
    for degree in range(1, core.ORDER + 1):
        diagonal = scaled_diagonal(jets, half_width, degree)
        coefficient_bound, _ = core.p.transformed_magnitude(basis, diagonal, core.BITS)
        bound += coefficient_bound

    # On |z-centre| <= 1/16 every entry of the scaled H_4 is <= 10^6 * 6!.
    ratio = 16 * half_width
    prefactor = Fraction(RANK * norm_product * core.M * factorial(MAX_DERIVATIVE),
                         core.SCALE**2)
    tail = prefactor * ratio**(core.ORDER + 1) / (1 - ratio)
    return Fraction(bound, core.SCALE) + tail


def main():
    core.p.iv.prec = core.p.BITS + 60
    core.p.mp.prec = core.BITS + 80
    writer = csv.writer(sys.stdout, lineterminator='\n')
    writer.writerow(['left', 'right', 'upper_bound_times_1e9'])
    largest = 0
    for i in range(CELL_COUNT):
        left = Fraction(i, 2 * CELL_COUNT)
        right = Fraction(i + 1, 2 * CELL_COUNT)
        bound = check_cell(left, right)
        if not 0 <= bound < 1:
            raise ArithmeticError(f'Uncertified cell [{left}, {right}]')
        numerator = core.ceil(10**9 * bound)
        largest = max(largest, numerator)
        writer.writerow([left, right, numerator])
    print(f'PASS: {CELL_COUNT} cells; largest upper bound {largest}/1000000000', file=sys.stderr)


if __name__ == '__main__':
    main()
