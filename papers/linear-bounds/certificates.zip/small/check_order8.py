"""Enclose the order-eight witness for Psi1 and the compact certificate for Psi2."""
from fractions import Fraction
from math import factorial
import sys

import certify as c

Q = Fraction
p = c.p
p.iv.prec = p.BITS + 60
p.mp.prec = c.BITS + 80
MATRIX_BOUND = 10**7 * factorial(14)
RANK = 8

def add(x, y):
    return x[0] + y[0], x[1] + y[1]

def multiply_positive(x, w):
    assert w >= 0
    return p.divide(x[0] * w.numerator, x[1] * w.numerator, w.denominator)

def back(left, right, right_data):
    step = right - left
    assert 0 <= step <= Q(1,32)
    phi = c.jets(left,c.JETS)
    first, second = right_data
    first_left = add(first,c.integrate(phi,step))
    integral = (0,0)
    for j, bounds in enumerate(phi):
        w = step**(j+2)/(factorial(j)*(j+2))
        integral = add(integral,multiply_positive(bounds,w))
    err = c.ceil(p.H*c.M*step**2*(8*step)**len(phi)/(1-8*step))
    second_left = add(add(second,multiply_positive(first,step)),add(integral,(-err,err)))
    return first_left,second_left

def hankel_entries(center, kmax, anchors):
    right = Q(c.ceil(32*center),32)
    first,second = back(center,right,anchors[right])
    return [second,c.negate(first)]+c.jets(center,kmax-1)

def scaled_entry(values, index, k, h):
    l,u=values[index+k]
    w=h**k/factorial(k)
    return p.divide(l*w.numerator,u*w.numerator,
                    w.denominator << (p.BITS-c.BITS+4*index))

def certify_cell(left, right, anchors):
    h=(right-left)/2
    values=hankel_entries(left+h, 2*RANK-2+c.ORDER,anchors)
    def entries(k):
        return [scaled_entry(values,j,k,h) for j in range(2*RANK-1)]
    constants=entries(0)
    basis,signs=p.hankel_basis([(l+u)//2 for l,u in constants],RANK,c.BITS)
    if signs != [(-1)**i for i in range(RANK)]:
        raise ArithmeticError(("wrong signs at midpoint",left+h,signs))
    bound,product=p.transformed_magnitude(basis,constants,c.BITS,signs)
    for k in range(1,c.ORDER+1):
        magnitude,_=p.transformed_magnitude(basis,entries(k),c.BITS)
        bound+=magnitude
        if bound>=c.SCALE:
            return Q(1)
    remainder=Q(RANK*product*MATRIX_BOUND,c.SCALE**2)*(16*h)**(c.ORDER+1)/(1-16*h)
    return Q(bound,c.SCALE)+remainder

def determinant_interval(entries):
    # Products in row k carry the common integer scale p.H**k.
    partial = {0: (1, 1)}
    for row in range(RANK):
        following = {}
        for used, (lo, hi) in partial.items():
            for col in range(RANK):
                if (used >> col) & 1:
                    continue
                a, b = entries[row + col]
                products = (lo*a, lo*b, hi*a, hi*b)
                term = (min(products), max(products))
                if (used >> (col + 1)).bit_count() % 2:
                    term = c.negate(term)
                mask = used | (1 << col)
                following[mask] = add(following.get(mask, (0, 0)), term)
        partial = following
    lo, hi = partial[(1 << RANK) - 1]
    return p.divide(lo, hi, p.H**RANK)

def main():
    assert __debug__
    t=Q(2)
    endpoint=(0,p.H >> 500)
    anchors={t:(endpoint,endpoint)}
    for i in reversed(range(64)):
        left=Q(i,32)
        anchors[left]=back(left,t,anchors[t])
        t=left
    witness=Q(5,64)
    vals=hankel_entries(witness,15,anchors)
    # At level one H has zeroth entry Psi1 and higher entries -Phi^(j-1).
    order1=[c.negate(z) for z in vals[1:16]]
    lo,hi=determinant_interval(order1)
    assert hi<0
    print("W8(Psi1;5/64) enclosed in [",lo,",",hi,"]",file=sys.stderr)
    entries=[scaled_entry(order1,j,0,Q(0)) for j in range(15)]
    basis,signs=p.hankel_basis([(a+b)//2 for a,b in entries],RANK,c.BITS)
    norm,_=p.transformed_magnitude(basis,entries,c.BITS,signs)
    assert signs==[1,-1,1,-1,1,-1,1,1] and norm<c.SCALE
    print("level 1 negative W8 at",witness,"norm upper /1e9",c.ceil(Q(norm*10**9,c.SCALE)),file=sys.stderr)
    todo=[(Q(i,128),Q(i+1,128)) for i in reversed(range(64))]
    accepted=[]
    while todo:
        l,r=todo.pop()
        score=certify_cell(l,r,anchors)
        if score < Q(7,8):
            accepted.append((l,r,c.ceil(score*10**9)))
        else:
            assert r-l>Q(1,2**20),(l,r)
            mid=(l+r)/2
            todo.extend([(mid,r),(l,mid)])
    cursor=Q(0)
    print("t_from,t_to,upper_bound_times_1e9")
    for l,r,v in accepted:
        assert l==cursor and r>l and v<10**9
        cursor=r
        print(f"{l},{r},{v}")
    assert cursor==Q(1,2)
    print("PASS level 2 cells",len(accepted),"maximum /1e9",max(row[2] for row in accepted),file=sys.stderr)

if __name__=="__main__":
    main()
