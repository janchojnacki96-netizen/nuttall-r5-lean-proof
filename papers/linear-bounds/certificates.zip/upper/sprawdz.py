"""Uruchomienie wszystkich nowych certyfikatów i sprawdzenie pokrycia starych tabel."""
import csv
import io
import subprocess
import sys
import zipfile
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

BASE = Path(__file__).resolve().parent

def small_tables():
    archive = BASE / 'poprzednie' / 'r_do_32.zip'
    ranges = [
        ('t_0_do_1_16.csv', 1, Fraction(0), lambda r: Fraction(1, 16), 10**8),
        ('t_1_16_do_1_4.csv', 1, Fraction(1, 16), lambda r: Fraction(1, 4), 10**8),
        ('certyfikat_X.csv', 2, Fraction(8), lambda r: Fraction(76*(r-1)), 10**9),
    ]
    with zipfile.ZipFile(archive) as z:
        for name, start, left, right, scale in ranges:
            rows = defaultdict(list)
            with io.TextIOWrapper(z.open(name), encoding='utf-8') as data:
                reader = csv.reader(data)
                next(reader)
                for rank, lo, hi, bound in reader:
                    assert 0 <= int(bound) < scale
                    rows[int(rank)].append((Fraction(lo), Fraction(hi)))
            assert set(rows) == set(range(start, 33))
            for r, intervals in rows.items():
                intervals.sort()
                cursor = left
                for lo, hi in intervals:
                    assert lo == cursor and hi > lo
                    cursor = hi
                assert cursor == right(r)
            print(name, sum(map(len, rows.values())), 'OK', flush=True)

def main():
    assert __debug__, 'Uruchom bez opcji -O.'
    small_tables()
    jobs = [('layers.py', 33, 649, 1, 0), ('layers.py', 650, 1449, 0, 0),
            ('verify.py', 1450)]
    jobs.extend(('corner.py', a, b) for a, b in
                [(33, 100), (101, 220), (221, 400), (401, 649)])
    for script, *args in jobs:
        subprocess.run([sys.executable, str(BASE / 'kod' / script),
                        *map(str, args)], check=True)
    print('Wszystkie nowe zakresy przeszły. Tabele r<=32 pokrywają swoje przedziały.')

if __name__ == '__main__':
    main()
