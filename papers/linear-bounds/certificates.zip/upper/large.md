# Dokładnie 2r całkowań jądra Riemanna dla r ≥ 10¹¹

Nota robocza do niezależnego sprawdzenia, 25 listopada 2026 r.  
Poniższe wyprowadzenie powstało w rozmowie z ChatGPT. Nie przeszło niezależnej weryfikacji ani formalizacji w Lean.

## Wynik

Niech $x_n=\pi n^2e^{4t}$, $\Phi(t)=\sum_{n\ge1}e^t x_n(2x_n-3)e^{-x_n}$, $\Psi_0=\Phi$, $\Psi_{m+1}(t)=\int_t^\infty\Psi_m(v)\,dv$. Piszemy $W_p(f;t)=\det[f^{(i+j)}(t)]_{0\le i,j<p}$, $\epsilon_p=(-1)^{p(p-1)/2}$. Liczba $m(r)$ jest najmniejszym poziomem całkowania, przy którym jądro $\Psi_m(u+v)$ ma regularność znakową typu $RR_r$ na półosi.

Dla każdego całkowitego $r\ge10^{11}$, wszystkich $1\le p\le r$ i $t\ge0$ zachodzi
\[
\epsilon_pW_p(\Psi_{2r};t)>0.
\]
W konsekwencji $m(r)\le2r$ w tym zakresie. Drugi, odrębny wniosek to $m(8000)\le16008$. Przy $m=16000$ ten sam test daje wszystkie rzędy $p\le7996$. Ogólne twierdzenie $m(r)\le2r$ dla każdego $r$ pozostaje do wykazania.

## 1. Całka, której znak trzeba ustalić

W całym dowodzie $p\le m/2$, $L=m-p$, $X=\pi e^{4t}\ge\pi$, $a_n=\frac12\log n$. Wystarczy rozpatrzyć $p\ge2$, bo dla $p=1$ zachodzi $\Phi>0$ na półosi. Dla $\ell\ge2$ piszemy
\[
 R_\ell(u)=\sum_{a_n\le u}n^{-1/2}
 \left(\frac{(u-a_n)^{\ell-1}}{(\ell-1)!}-\frac{(u-a_n)^\ell}{\ell!}\right).
\]
Wrońskian ze znakiem ma znak całki z symetrycznej funkcji
\[
 I(\mathbf u)=
 \det[R_{L+j}(u_i)]_{1\le i\le p,\ 0\le j<p}\,
 \Delta(e^{4u_1},\ldots,e^{4u_p})
 \prod_i e^{5u_i-Xe^{4u_i}}
 \tag{1}
\]
po całej dodatniej ortancie, gdzie $\Delta(y)=\prod_{i<j}(y_j-y_i)$.

Dla uzasadnienia niech $b_\ell^g$ oznacza całkę ogonową rzędu $\ell$ z $g$. Funkcja $g=\sum_n e^t x_ne^{-x_n}$ spełnia $2\Phi=-(g'+g)$. Po odwróceniu wierszy i usunięciu znaków pochodnych mamy $\epsilon_pW_p=\det[b_{L+1+i-j}^{\Phi}]$. W kolumnie $j$ można różniczkować $j$ razy pod znakiem całki, korzystając z $2b_{L+1+i}^{\Phi}=b_{L+i}^g-b_{L+1+i}^g$ i uwzględniając $(-1)^j$. To daje funkcje $s^{L+i-1}(L+i-s)/(L+i)!$ oraz $(-1)^jg^{(j)}(t+s)$ w tożsamości Andréiefa. Po rozwinięciu drugiego wyznacznika względem indeksów theta i wyjęciu wspólnych dodatnich czynników z wierszy zostają wielomiany stopnia $j$ w $n_i^2 e^{4s_i}$ o dodatnim współczynniku wiodącym. Drugi wyznacznik jest więc dodatnią stałą razy Vandermonde. Przesunięcie $u_i=s_i+a_{n_i}$ daje (1) po zsumowaniu $n_i$. Zbieżność bezwzględną i różniczkowanie przy ustalonych parametrach zapewnia czynnik $e^{-Xn^2e^{4s}}$.

## 2. Kontrola jednego węzła ogona

Po ustaleniu wszystkich węzłów poza jednym, moduł (1) jako funkcja pozostałej zmiennej $u$ ma, z dokładnością do stałego czynnika, postać
\[
 |f(u)|\,\prod_{j=1}^{p-1}|e^{4u}-e^{4v_j}|\,e^{5u-Xe^{4u}},
 \qquad f(u)=\sum_{j=0}^{p-1}c_j R_{L+j}(u).
\]
Niech $b_j=c_j/(L+j)!$, $F=\max_j|b_j|$, $H=F\prod_{j=1}^{p-1}(1+e^{4v_j})$. Przy $F=0$ obie porównywane całki znikają. W pozostałych przypadkach na $J_0=[1/8,1/4]$ mamy $f(u)=u^{L-1}Q(u)$, gdzie
\[
 Q(u)=\sum_{j=0}^{p-1} b_j u^j(L+j-u).
\]
Ponieważ współczynnik stopnia $j<p$ to $(L+j)b_j-b_{j-1}$, $b_{-1}=0$, co najmniej jeden współczynnik ma moduł $\ge (L-1)F\ge F$.

Usuńmy z $J_0$ otoczenia o promieniu $\delta=1/(64p)$ wokół $v_j$ i części rzeczywistych wszystkich pierwiastków $Q$. Pozostaje zbiór miary co najmniej $1/16$, bo $\deg Q\le p$. Jeśli $Q=A\prod(u-z)$, to $|A|\prod(1+|z|)$ ogranicza z góry moduły wszystkich współczynników $Q$. Dla pozostałych $u$ mamy $|u-z|/(1+|z|)\ge\delta/3$ (dla $|z|\le2$ z konstrukcji, dla $|z|>2$ z nierówności trójkąta). Ponadto
\[
 \frac{|e^{4u}-e^{4v_j}|}{1+e^{4v_j}}
 \ge \tfrac12(1-e^{-4\delta})\ge\delta .
\]
W konsekwencji całka z modułu po $J_0$ jest co najmniej $H\,8^{-(L-1)}(192p)^{-2p}e^{-eX}/16$.

Na ogonie korzystamy z $\sum_{n\le e^{2u}}n^{-1/2}\le2e^u$. Dostajemy $|f(u)|\le2e^u pF(m+u)(1+u)^m$. Każdy czynnik Vandermonde'a po podzieleniu przez $1+e^{4v_j}$ jest ograniczony przez $2e^{4u}$. Dla $m\ge4$, $p\le m/2$, po wyjęciu $e^{-Xe^{4B}/2}$ pozostaje całka ograniczona przez $mp2^p H\int_0^\infty e^{4mu-(\pi/2)e^{4u}}du\le mp2^p H m!$ (podstawienie $y=e^{4u}$). Zatem dla każdego wyboru pozostałych węzłów
\[
 \int_B^\infty |I|\,du \;\le\;
 \eta\int_{J_0}|I|\,du,\quad
 \eta=16mp\,2^p8^{L-1}(192p)^{2p}m!
       \exp[-X(e^{4B}/2-e)] . \tag{2}
\]
Logarytm prefaktora jest mniejszy od $4m\log(192m)$ dla $m\ge4$, $2p\le m$ (wystarczy $m!\le m^m$). Wybór
\[
 B=\tfrac14\log(4m\log(192m)) \tag{3}
\]
daje $\eta<1/(4m)$ w tym zakresie, ponieważ $X\ge\pi$ i $e^{4B}/2=2m\log(192m)$. Sumując (2) po $p$ współrzędnych i całkując pozostałe, otrzymujemy
\[
 \int_{\max u_i>B}|I| \le p\eta\int |I|.
\]
Jeśli (1) jest dodatnie na parami różnych węzłach w $(0,B)$, to $\int |I|>0$ i $\int I\ge(1-2p\eta)\int|I|>0$. W ten sposób kosztem ogona jest porównanie funkcji jednej zmiennej, jednostajne względem wszystkich pozostałych węzłów.

## 3. Macierze początkowych wrońskianów

Ustalmy $1\le k\le p$, $N=L+k-1$, $M=N-1$, $J=\operatorname{diag}((-1)^i)_{i=0}^{k-1}$. Mamy $M\ge2(k-1)$. Poza progami $a_n$ odwrócenie kolumn początkowego wrońskianu długości $k$ daje macierz $[R_N^{(i+j)}]$ i znak $\det J$. Przekształcamy tę macierz kongruencją trójkątną, biorąc współczynniki $w^iz^j$ wyrażenia
\[
 (1-w)^N(1-z)^N R_N\!\left(u+\frac{uw}{1-w}+\frac{uz}{1-z}\right).
\]
Przekątna macierzy przekształcającej to $u^i/i!>0$. Dzielimy wyrażenie przez $(1-w)(1-z)$ oraz $u^M/M!$, a rzędy i kolumny przez $\sqrt{\binom Mi}$. Zachowuje to znak wyznacznika. Dla $d=a_n/u$, $Q_d=1-wz-d(1-w)(1-z)$ niech $C_d$ będzie blokiem $k\times k$ macierzy współczynników $Q_d^M$ znormalizowanych tymi dwumianami. Wkład $n$ otrzymuje wagę $n^{-1/2}$ i macierz
\[
 A_d=C_d-\frac{u}{N}(V_d C_d+C_d V_d^\top),\qquad
 V_d=U-\tfrac{1+d}{2}\operatorname{Id},\quad
 U_{ij}=\sqrt{\binom Mj/\binom Mi}\quad(0\le j\le i<k).
\]
Pozostałe wpisy $U$ są zerowe. Wzór wynika z $Q_d/[(1-w)(1-z)]=(1-w)^{-1}+(1-z)^{-1}-1-d$. Mamy $C_0=J$.

Dla $q=i-j\ge0$ zachodzi $U_{ij}\le e^{-q^2/N}$. Istotnie
\[
 \log U_{ij}^{-1}
 =\tfrac12\sum_{\ell=j+1}^i\log\frac{N-\ell}{\ell}
 \ge\sum_{\ell=j+1}^i (N-2\ell)/N \ge q^2/N ,
\]
gdyż $i\le M/2$. Przekątna $V_d$ leży w $[0,1/2]$. Sumowanie gaussowskiej granicy wierszy i kolumn daje $2\|V_d\|_2\le1+\sqrt{\pi N}$. Dla $N\ge N_0=m-p$ kładziemy
\[
 E=B(1/N_0+\sqrt{\pi/N_0}).
\]
Wtedy $\|A_0-J\|\le E$ i $\|A_d\|\le(1+E)\|C_d\|$. Zatem wystarczy wykazać
\[
 E+(1+E)\sum_{2\le n\le e^{2u}}n^{-1/2}\|C_{a_n/u}\|<1\qquad(0<u<B). \tag{4}
\]
Wszystkie normy bez indeksu są euklidesowymi normami operatorowymi. Macierz łączymy odcinkiem z $J$ w kuli o promieniu mniejszym niż $1$. Cały odcinek jest odwracalny, więc znak wyznacznika wynosi $\det J$. Odwrócenie kolejności kolumn przywraca dodatni znak wrońskianu początkowego.

Dodatnie początkowe wrońskiany dają dodatni wyznacznik wartości. Na progach ostatnia potrzebna pochodna może skakać. Uzasadnieniem obejmującym również te węzły jest podzielenie wierszy wyznacznika przez jego pierwszą funkcję $f_1>0$ i odjęcie kolejnych wierszy od dołu. Rozwinięcie wzdłuż pierwszej kolumny daje całkę wyznacznika funkcji $(f_{j+1}/f_1)'$ po kolejnych przedziałach między węzłami. Ich początkowe wrońskiany długości $j$ są równe $W(f_1,\ldots,f_{j+1})/f_1^{j+1}$. Powtarzamy redukcję. Funkcje $R_{L+j}$ są klasy $C^{p-2}$ z lokalnie absolutnie ciągłą pochodną rzędu $p-2$. Wrońskiany rzędów do $p-1$ są ciągłe również na progach i dodatnie tam przez jednostajny margines w (4) oraz ciągłość odwracalnych kongruencji dla $u>0$. Ostatnie różniczkowanie wymaga tylko dodatniości prawie wszędzie. Na uporządkowanych węzłach oba wyznaczniki w (1) są więc dodatnie, a symetria obejmuje wszystkie permutacje.

## 4. Oszacowanie także przy m = 2p i k = p

Dla $0<d<1$ połóżmy $s=\sqrt{(1-d)/(1+d)}$ i $c=\sqrt{1-d^2}$. Macierz $H=\left(\begin{smallmatrix}1-d&d\\d&-1-d\end{smallmatrix}\right)$ po kongruencji przez $\operatorname{diag}(1,s)$ i podzieleniu przez $s$ daje ortogonalną macierz $\left(\begin{smallmatrix}c&d\\d&-c\end{smallmatrix}\right)$. Na jej $M$-tej potędze symetrycznej, w ortonormalnej bazie tensorów symetrycznych, otrzymujemy ortogonalną macierz $T$. Z porównania współczynników formy na wektorach $(e_0+w e_1)^{\otimes M}$ wynika
\[
 (C_d)_{ij}=s^{M-i-j}T_{ij},\qquad
 \|C_d\|\le s^{M-2(k-1)}\le1. \tag{5}
\]
Druga nierówność normowa wynika z dwóch diagonalnych skalowań bloku ortogonalnej macierzy. Obowiązuje przez ciągłość także dla $d=1$.

Oznaczmy $\alpha=M/2-i$, $\beta=M/2-j$. Gdy $\max(\alpha,\beta)>\sqrt M/16$, z (5) dostajemy $|(C_d)_{ij}|\le e^{-d\sqrt M/16}$. Dla pozostałych wpisów możemy przez symetrię przyjąć $i\ge j$. Wówczas
\[
 T_{ij}=\sqrt{\binom Mj/\binom Mi}\,[z^i](c+dz)^{M-j}(d-cz)^j ,
\]
a prefaktor jest najwyżej $1$. Na okręgu jednostkowym, przy $x=2cd\cos\theta$, logarytm modułu iloczynu wynosi co najwyżej
\[
 \tfrac{M-j}{2}\log(1+x)+\tfrac j2\log(1-x)
 \le \beta x-Mx^2/8\le4\beta^2/M-Mx^2/16 .
\]
Użyliśmy $\log(1+x)\le x-x^2/4$ dla $-1<x\le1$. Średnia $e^{-Mc^2d^2\cos^2\theta/4}$ po okręgu jest najwyżej $\sqrt{\pi}/(cd\sqrt M)$ przez $\sin v\ge2v/\pi$ na $[0,\pi/2]$. Z wzoru Cauchy'ego i $e^{1/64}\sqrt{\pi}<2$ wynika $|T_{ij}|\le2/(cd\sqrt M)$ w tej części macierzy. Norma Frobeniusa macierzy o wpisach $s^{\alpha+\beta}$ na rozpatrywanym bloku jest najwyżej $1/(1-s^2)$, co wynika z szeregu geometrycznego. Dodajemy obie części. Otrzymujemy
\[
 \|C_d\|\le \frac{2}{(1-s^2)cd\sqrt M}+k e^{-d\sqrt M/16}. \tag{6}
\]
To oszacowanie zachowuje czynnik $1/\sqrt M$ również przy $M=2(k-1)$.

## 5. Zsumowanie indeksów i liczbowy próg

Dla $m=2r$ mamy $M\ge r-1$, $N\ge r$, $k\le m$. Dla $0<u\le b\le B$ niech $K=\lfloor e^{2u}\rfloor$. Jeżeli $K\ge2$, wydzielamy pojedynczy indeks $K$, dla którego wystarcza (5) z wagą $1/\sqrt K$. Pozostałe $2\le n<K$ spełniają $a_2/b\le d<1$.

Dla $d\le1/2$ mamy $1/[(1-s^2)cd]\le d^{-2}$. Tu $n\le e^u$, więc suma wag jest najwyżej $2e^{b/2}$. Dla $d>1/2$ mamy $1/[(1-s^2)cd]\le3/\sqrt{1-d}$. Ponadto
\[
 (1-d)^{-1/2}=\sqrt{\frac{2u}{\log(e^{2u}/n)}}
 \le\sqrt{\frac{2b e^{2u}}{e^{2u}-n}},\qquad
 \sum_{n=1}^{K-1}\frac1{\sqrt{n(K-n)}}\le4 .
\]
Ostatnia granica wynika z podziału sumy w połowie. Z (5)–(6) otrzymujemy
\[
 \sum_{2\le n\le K}n^{-1/2}\|C_{a_n/u}\|
 \le K^{-1/2}+P(b)+Q(b)+D(b),
\]
\[
 P(b)=\frac{4(b/a_2)^2e^{b/2}}{\sqrt{r-1}},\quad
 Q(b)=\frac{24\sqrt{2b}\,e^b}{\sqrt{r-1}},\quad
 D(b)=2m e^b\exp[-a_2\sqrt{r-1}/(16b)]. \tag{7}
\]
Przy $K<2$ suma jest pusta.

Bierzemy $E=B(1/r+\sqrt{\pi/r})$. W zakresie $u\le4$ używamy $b=4$, $K\ge2$. Dla $4<u\le B$ używamy $b=B$, $K\ge2980$. Przy $r=10^{11}$ mamy $7.71270<B<7.71271$, $E<0.000044$. Poniżej są granice zaokrąglone w górę.

| Zakres | $P(b)$ | $Q(b)$ | $\log D(b)$ | Lewa strona (4), granica górna |
|---|---:|---:|---:|---:|
| $u\le4$, $K\ge2$ | 0,012451 | 0,011721 | −1681 | 0,732 |
| $4<u\le B$ | 0,296262 | 0,666678 | −853 | 0,982 |

Granice obowiązują dla wszystkich większych $r$. Istotnie przy $z=\log r$ mamy $B'=(1+1/\log(192m))/4<0.26$ oraz $B>7$. Stąd logarytmiczne pochodne $P(B)$ i $Q(B)$ względem $z$ są mniejsze odpowiednio od $(2/B+1/2)0.26-1/2$ i $(1/(2B)+1)0.26-1/2$, a więc ujemne. Tak samo maleją oba składniki $E$. Dla $\lambda=a_2\sqrt{r-1}/(16B)$ mamy $(\log\lambda)'>1/2-0.26/7>0.46$, a jej wartość początkowa przekracza $800$. Zatem $(\log D(B))'<1+0.26-0.46\lambda<0$. Przy stałym $b=4$ sprawdzenie monotoniczności jest identyczne z $b'=0$. Warunek (4) zachodzi dla każdego $p,k$, jednostajnie w centrum. Z (2)–(3) otrzymujemy żądany ścisły znak na całej półosi. Kryterium wrońskianowe Nuttalla daje $RR_r$.

## 6. Osobne oszacowanie przy r = 8000

Bierzemy $m=16008$, $p\le8000$, $B=3.13$. W (2) użycie $p\le8000$, $L-1\le m$, $m!\le m^m$, $X\ge\pi$ daje $\log(4m\eta)<-8258$. W (5) wykładnik $M-2(k-1)=m-p-k$ ma wartość co najmniej $8$. Funkcja $s$ jest malejąca względem $d$, więc w ograniczeniu górnym na sumę wystarczy $u=B$. Mamy $523<e^{2B}<524$, a zatem
\[
 S=\sum_{n=2}^{523}\frac1{\sqrt n}
       \left(\frac{1-\log n/(2B)}{1+\log n/(2B)}\right)^4
 <0.801456,\qquad E<0.062386 .
\]
Lewa strona (4) jest mniejsza od $0.914$. Daje to $m(8000)\le16008$. Dla $m=16000$, $p\le7996$ ponownie $m-2p\ge8$, ten sam wybór $B$ i to samo $S$ wystarczają, $E<0.063$, a prefaktor w (2) nadal jest ograniczony przez ten użyty przy $m=16008$. Przy dokładnie $16000$ całkowaniach z tego rachunku pozostają rzędy $7997,7998,7999,8000$.

Poniższy kod odtwarza nierówności liczbowe dla $m=16008$ z arytmetyką przedziałową.

~~~python
from mpmath import iv

iv.dps = 40
m, p = 16008, 8000
B = iv.mpf('3.13')
log_pref = (iv.log(16*m*p) + p*iv.log(2) + m*iv.log(8)
            + 2*p*iv.log(192*p) + m*iv.log(m))
assert (log_pref + iv.log(4*m) - iv.pi*(iv.exp(4*B)/2-iv.exp(1))).b < -8258
assert iv.exp(2*B).a > 523 and iv.exp(2*B).b < 524
S = iv.mpf(0)
for n in range(2, 524):
    d = iv.log(n)/(2*B)
    S += ((1-d)/(1+d))**4/iv.sqrt(n)
E = B*(1/iv.mpf(m-p) + iv.sqrt(iv.pi/(m-p)))
assert (E+(1+E)*S).b < iv.mpf('0.914').a
~~~

## Odniesienie

John Nuttall, *Cumulants, the Riemann Hypothesis, and Similar*, §3.2–3.3, w szczególności (3.16) i (3.28), podaje użyte kryterium wrońskianowe regularności znakowej. Próg i oszacowania w tej nocie pochodzą z powyższego rachunku. [Tekst Nuttalla](https://publish.uwo.ca/~jnuttall/cumanal_a.pdf)

