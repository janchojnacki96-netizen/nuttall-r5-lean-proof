# Dwa całkowania na rząd wystarczają dla jądra Riemanna

**Nota robocza, 25 listopada 2026. Dowód wspomagany komputerowo do niezależnej weryfikacji.**

Dla $t\ge0$ niech $x_n=\pi n^2e^{4t}$ i $\Phi(t)=\sum_{n\ge1}e^t x_n(2x_n-3)e^{-x_n}$. Niech $\Psi_0=\Phi$ i $\Psi_{m+1}(t)=\int_t^\infty\Psi_m(v)\,dv$. Przez $m(r)$ oznaczamy najmniejszą nieujemną liczbę całkowań, dla której jądro $\Psi_m(u+v)$ jest regularne znakowo typu $RR_r$ na dodatniej półosi.

**Twierdzenie.** Dla każdej liczby całkowitej $r\ge1$, każdego $p=1,\dots,r$ i każdego $t\ge0$ zachodzi
\[
 (-1)^{p(p-1)/2}\det[\Psi_{2r}^{(i+j)}(t)]_{0\le i,j<p}>0.
\]
Kryterium wrońskianowe Nuttalla daje stąd $m(r)\le 2r$. Wniosek dotyczy podanego jądra i liczby całkowań. Wyznaczenie minimalnej liczby dla poszczególnych rzędów i hipoteza Riemanna to odrębne zagadnienia.

## Jak sprawdzić wynik

Polecenie **python sprawdz.py** uruchomione w rozpakowanym katalogu sprawdza pokrycie trzech wcześniejszych tabel, a następnie powtarza wszystkie nowe certyfikaty. Wymaga Pythona, NumPy i mpmath, z włączonymi asercjami. Użyto NumPy 2.3.5 i mpmath 1.3.0. W katalogu **wyniki** są protokoły. W razie niepowodzenia na zbyt szerokim bloku program może wypisać „FAIL” dla próby, po czym sprawdza węższy blok. Tylko zatwierdzone bloki tworzą pokrycie. Końcowy status każdego zakresu musi brzmieć „PASS”.

| Rzędy | Składnik dowodu |
|---|---|
| $1\le r\le32$ | Wcześniejsze trzy tabele i dowód analityczny na ogonie w **poprzednie/r_do_32.zip**. Sprawdzono ponownie zgodność końców i granice wszystkich 10 919 zapisanych komórek. Generator tych wcześniejszych tabel jest w archiwum. |
| $33\le r\le649$ | Certyfikat warstw dla $h\ge1$ i osobny certyfikat dopełnienia Schura dla $h=0$. |
| $650\le r\le1449$ | Certyfikat warstw również dla $h=0$. |
| $1450\le r<10^{11}$ | Certyfikat bloków indeksów, a następnie sumowanie analityczne. |
| $r\ge10^{11}$ | Wcześniejszy argument analityczny w **poprzednie/duze_r.md**, §§1–5. |

Poniższe szczegóły dotyczą nowego zakresu $33\le r<10^{11}$. Wyprowadzenia reprezentacji całkowej, kongruencji trójkątnej i przejścia przez progi są podane również w dołączonej nocie dla dużych rzędów.

## 1. Od wrońskianu do przedziału dla węzłów

Ustalmy $m=2r$, $L=m-p$, $X=\pi e^{4t}$ i $a_n=(\log n)/2$. Niech
\[
 R_j(u)=\sum_{a_n\le u}n^{-1/2}\left(\frac{(u-a_n)^{j-1}}{(j-1)!}
                  -\frac{(u-a_n)^j}{j!}\right).
\]
Z tożsamości Andréiefa znak badanego wyznacznika ze znakiem jest znakiem całki z
\[
 I=\det[R_{L+j}(u_i)]_{i=1,\ldots,p;\ j=0,\ldots,p-1}\,
 \Delta(e^{4u_1},\ldots,e^{4u_p})\prod_i e^{5u_i-Xe^{4u_i}}
\]
po dodatniej ortancie. Wystarczy pokazać dodatniość na parami różnych węzłach $0<u_i<b$ i ograniczyć masę bezwzględną dopełnienia przez mniej niż połowę całkowitej masy bezwzględnej. Przypadek $p=1$ wynika także bezpośrednio z $\Phi>0$.

Niech $R\le r\le S$ będzie całkowitoliczbowym przedziałem. Oto stosowany test obcięcia, ważny ogólniej dla $p\le S,\ m\le2S,\ L\ge2$. Po ustaleniu innych węzłów $v_j$ w zmiennej $u$ pozostaje, poza stałą,
\[
 |f(u)|\prod_j|e^{4u}-e^{4v_j}|e^{5u-Xe^{4u}},
 \qquad f=\sum_{j=0}^{p-1}c_jR_{L+j}.
\]
Niech $b_j=c_j/(L+j)!$, $F=\max|b_j|$, $H_0=F\prod(1+e^{4v_j})$. Przy $F=0$ obie strony porównania znikają. Na $[0,1/3]$, poniżej progu $a_2$, mamy $f=u^{L-1}Q(u)$, $Q=\sum_j b_j u^j(L+j-u)$. Pewien współczynnik $Q$ ma moduł $\ge F$, co wynika z $(L+j)b_j-b_{j-1}$ dla $j$ maksymalizującego $|b_j|$. Jeśli $Q=A\prod(u-z)$, to $|A|\prod(1+|z|)\ge F$.

Średnia $\log u$ dla rozkładu jednostajnego na $[0,1/3]$ wynosi $-1-\log3$. Średnia $\log(|u-z|/(1+|z|))$ jest co najmniej $-1-\log12$. Dla $|z|\le1$ stosujemy $|u-z|\ge|u-\Re z|$ i minimalizujemy średnią w środku odcinka. Dla $|z|\ge1$ iloraz jest $\ge1/3$. Podobnie $|e^{4u}-e^{4v}|/(1+e^{4v})\ge\min(|u-v|,1/3)$ dla $v\ge0$. Średnia logarytmu prawej strony jest najmniejsza w środku odcinka i wynosi $-1-\log6$ (wynika to także z maksymalnej długości przecięcia z odcinkiem symetrycznym wokół $v$). Z nierówności Jensena całka z modułu po $[0,1/3]$ jest co najmniej $H_0 e^{-9S-4X}/3$. Użyliśmy $L+p\le2S$, $p\le S$, $3+\log216<9$ i $e^{4/3}<4$.

Dla $u\ge b\ge1$ zachodzi $|f|\le2e^u pF(m+u)u^m$ oraz $|e^{4u}-e^{4v}|/(1+e^{4v})\le e^{4u}$. Górna granica integrandu ma pochodną logarytmiczną co najwyżej $6S+3-4\pi e^{4b}$. Jeśli $4\pi e^{4b}>6S+4$, to całkę ogonową ogranicza jej majoranta w punkcie $b$. Wystarczy zatem
\[
 \log[24S^2(2S+b)]+(4S+2)b+2S\log b+9S
       -\pi(e^{4b}-4)<0. \tag{1}
\]
Wówczas stosunek obu całek jest $<1/(4S)$, jednostajnie w pozostałych współrzędnych i $X\ge\pi$. Suma po $p$ współrzędnych daje udział ogona $<1/4$. Funkcja **cutoff** znajduje $b$ potwierdzone arytmetyką przedziałową.

## 2. Przesunięte macierze i parzystość

Potrzebne są początkowe wrońskiany funkcji $R_L,\ldots,R_{L+p-1}$, długości $1\le k\le p$. Piszemy
\[
 N=L+k-1,\quad M=N-1,\quad h=M-2(k-1)=m-p-k,\quad
 J=\operatorname{diag}((-1)^i)_{i=0}^{k-1}.
\]
Przy $m=2r$ mamy $h\ge0$, a równość zachodzi dokładnie przy $p=k=r$. Ponadto $M\ge r-1$ i $M+h\ge2r-2$. Dla $d=a_n/u$ niech $C_d$ będzie początkowym blokiem współczynników
\[
 [1-wz-d(1-w)(1-z)]^M
\]
po podzieleniu wpisu $ij$ przez $\sqrt{\binom Mi\binom Mj}$. Mamy $C_0=J$. Z kongruencji z §3 noty dla dużych rzędów, po odwróceniu kolumn, badana macierz jest równoważna sumie $\sum n^{-1/2} A_d$, gdzie
\[
 A_d=C_d-(u/N)(V_d C_d+C_dV_d^\top),\qquad V_d=U-(1+d)I_k/2,
\quad U_{ij}=\sqrt{\binom Mj/\binom Mi}\quad(j\le i).
\]
Wpisy nad przekątną w $U$ są zerowe. Wystarczy dodatnia określoność części symetrycznej $(\sum n^{-1/2}A_d)J$. Wtedy odcinek do identyczności jest odwracalny i znak odwrócenia kolumn się kasuje.

Część symetryczna $C_dJ$ rozdziela się na indeksy parzyste i nieparzyste. W każdym bloku jej wpisy mają jeden wspólny mnożnik $+1$ lub $-1$ względem $C_d$. Dla $n=1$ dostajemy identyczność z błędem
\[
 E_0\le u(1/N+\sqrt{\pi/N}/2).
\]
Dokładniej jest to macierz $I_k-(u/N)G$. Przekątna $G$ to jedynki, a poza nią na tej samej parzystości wpis $ij$ dla $i>j$ jest równy $U_{ij}$. Ponieważ $U_{ij}\le e^{-(i-j)^2/N}$, suma w wierszu jest $\le1+2\sum_{a\ge1}e^{-4a^2/N}\le1+\sqrt{\pi N}/2$. Dla pełnego błędu pojedynczego składnika można zawsze użyć $2u\|V_d\|/N\le u(1/N+\sqrt{\pi/N})$.

Niech $s=\sqrt{(1-d)/(1+d)}$, $c=\sqrt{1-d^2}$. Ortogonalna potęga symetryczna macierzy $\left(\begin{smallmatrix}c&d\\d&-c\end{smallmatrix}\right)$ daje macierz $T$. Przy $\alpha=M/2-i,\ \beta=M/2-j$ zachodzi $(C_d)_{ij}=s^{\alpha+\beta}T_{ij}$, a $\|C_d\|\le s^h$. Po wydzieleniu $s^h$ obie pozostałe diagonalne macierze skalujące mają elementy $s^{k-1-i}$. Oznaczmy jedną z nich $D_0$. Z postaci $V_d$ i $U_{ij}\le1$ wynika
\[
 \|V_dD_0\|_F^2
 \le v_d^2:=\frac{(1-d)^2}{4(1-s^2)}+\frac{s^2}{(1-s^2)^2}.
\]
Stąd poprawkę $A_d-C_d$ ogranicza $(2u/N)s^h v_d$ w normie operatorowej. Na progach stosujemy granice jednostronne. Przy $d=1$ znika cały blok poza ewentualnym ostatnim wpisem dla $h=0$.

## 3. Wspólna granica na elementy potęgi symetrycznej

Po zamianie indeksów można przyjąć $i\ge j$. Wtedy
\[
 T_{ij}=\sqrt{\binom Mj/\binom Mi}\,[z^i](c+dz)^{M-j}(d-cz)^j,
 \qquad \sqrt{\binom Mj/\binom Mi}\le1 .
\]
Niech $J_0(A)$ oznacza w tej nocie średnią $e^{-A\cos^2\theta}$ po okręgu. Przy $x=2cd\cos\theta$ moduł iloczynu z wzoru Cauchy’ego to $(1-x^2)^{M/4-\beta/2}(1+x)^\beta$. Symetryzacja w $x$ daje czynnik nie większy od $\cosh(\beta x)\le e^{\beta^2x^2/2}$. Zatem gdy $\alpha,\beta\le t$, mamy
\[
 |T_{ij}|\le J_0\!\left((M-2t-2t^2)_+\,d^2(1-d^2)\right). \tag{2}
\]
Dla niekorzystnej wartości $t$ prawa strona wynosi $1$.

Zawsze $J_0(A)\le\min(1,0.887/\sqrt A)$ przez $\sin v\ge2v/\pi$. Dla $A\ge16$ można zastąpić stałą przez $0.585$. Istotnie w całce $(2/\pi)\int_0^1 e^{-Ay^2}/\sqrt{1-y^2}\,dy$ na $y\le1/\sqrt2$ mamy $(1-y^2)^{-1/2}\le1+y^2$. Reszta jest $\le e^{-A/2}$. Otrzymujemy $(1+1/(2A))/\sqrt{\pi A}+e^{-A/2}$. Na $A\le16$ dokładniejsza tablica używa monotoniczności i rozwinięcia $J_0(A)=e^{-A/2}\sum_{\ell\ge0}(A/4)^{2\ell}/(\ell!)^2$, które wynika z całkowania szeregu wykładniczego. Ogon po $\ell=35$ jest mniejszy od ostatniego zachowanego dodatniego wyrazu.

W prostszym teście dla $r\ge1450$ kompresja do jednego bloku parzystości i do $\alpha,\beta\le t$ ma normę co najwyżej $J_0(A)/(1-s^4)$ (norma Frobeniusa). Pozostała część jest sumą dwóch kompresji z co najmniej jednym skalowaniem $\le s^t$ i ma normę $\le2s^t$. Używamy najmniejszej z kilku takich granic oraz $1$. Dla $R\le r\le S$ przyjmujemy $M_0=2R-2-\lfloor R/20\rfloor$. Gdy $M<M_0$, działa $\|C_d\|\le s^{2\lfloor R/40\rfloor}$. Przy $M\ge M_0$ podstawiamy $M_0$ w górnych granicach (2).

Dla dużych bloków skończonego zakresu program przechodzi na sumowanie analityczne także bez rozdzielenia parzystości. Przy $t=0.24\sqrt{M_0}$, $g=\sqrt{M_0-2t-2t^2}$ granica indywidualna wynosi $0.887/[g(1-s^2)cd]+2s^t$. Największy aktywny indeks $K=\lfloor e^{2u}\rfloor$ wnosi co najwyżej $1/\sqrt K$. Dla kolejnych przedziałów $d\le0.35$, $0.35\le d\le0.60$, $0.60\le d\le0.82$ maksimum $(1+d)/(2d^2\sqrt{1-d^2})$ jest na końcu przedziału, co widać z pochodnej logarytmicznej. Najmniejsze $d$ jest co najmniej $a_2/u$. W każdym przedziale do $d_1$ suma wag jest $\le 2e^{d_1u}$. Dla pozostałych $n<K$ stosujemy
\[
 (1-d)^{-1/2}\le \sqrt{2u}\,e^u/\sqrt{K-n},\qquad
 \sum_{n=1}^{K-1}[n(K-n)]^{-1/2}\le4.
\]
Współczynnik przy $(1-d)^{-1/2}$ w $1/[(1-s^2)cd]$ jest $\le\sqrt2/(2\cdot0.82^2)$. Łączny wkład $2s^t$ jest $\le4 e^u e^{-a_2t/u}$. Pozwala to sprawdzić całe przedziały $u\le2$ i $2<u\le b$, z odpowiednio $K\ge2$ lub $K\ge54$ jeśli suma jest niepusta.

## 4. Dokładniejsze oszacowanie warstw dla rzędów pośrednich

W bloku jednej parzystości odległości indeksów od środka mają postać $o+2i$, $i=0,1,\dots$. Po wyjęciu z oszacowania normy czynnika $s^{2o}$, niech $x=s^4$. Suma kwadratów skalowań dla $\max(i,j)=l$ jest
\[
 x^l\left(2\sum_{a=0}^{l-1}x^a+x^l\right).
\]
Mnożymy ją przez kwadrat prawej strony (2) przy $t=o+2l$ i sumujemy. Pierwiastek z sumy jest granicą normy Frobeniusa po wyjęciu wspomnianego czynnika. Dla pominiętych $l\ge24$ wystarcza $2x^{24}/(1-x)^2$. Jeśli $h$ jest znane dokładnie, rozpatrujemy $o=h/2$ i $o=h/2+1$. Dla $h\ge h_0$ kolejne możliwe półcałkowite przesunięcia są podzbiorami czterech siatek o początkach $(h_0+j)/2$, $j=0,1,2,3$. Usunięcie wcześniejszych wierszy i kolumn nie zwiększa normy. Kod rozdziela pierwsze trzy wartości $h$ i pozostałość. Dla przedziału $h<h_{\max}$ używa $M\ge\max(R-1,\,2R-2-h_{\max})$, a powyżej progu stosuje $s^{h_{\max}}$. Do granic na normy dodawane są poprawki na $V_d$ i na $n=1$. Test sprawdza, czy odchylenie części symetrycznej od identyczności jest $<1$.

Dla $650\le r\le1449$ to wystarcza dla wszystkich $h$. Dla $33\le r\le649$ to wystarcza dla $h\ge1$. Ponieważ $h=0$ wymusza $p=k=r$, w każdym z tych rzędów pozostaje jeden blok.

## 5. Przypadek graniczny i znak sumy Legendre’a

Przy $p=k=r$ mamy $M=2l$, $l=r-1$, $N=2r-1$. W parzystości ostatniego indeksu wydzielamy współrzędną środkową $i=l$. Jej wkład w część symetryczną $C_dJ$ jest **dokładnie** $P_l(1-2d^2)$, gdzie $P_l$ jest wielomianem Legendre’a. W istocie współczynnik $[z^l](c+dz)^l(d-cz)^l$ po pomnożeniu przez $(-1)^l$ to $\sum_{a=0}^l\binom la^2(1-d^2)^{l-a}(-d^2)^a=P_l(1-2d^2)$, np. ze wzoru Rodrigues’a. Sumujemy te liczby ze znakami:
\[
 S_l(u)=\sum_{n=2}^K n^{-1/2}P_l\left(1-2(\log n)^2 v\right),
 \qquad v=(2u)^{-2}. \tag{3}
\]

Niech $O$ będzie górną granicą sumy ważonych norm na przeciwnej parzystości ($o=1$), a $P$ na parzystości środka po usunięciu tej współrzędnej ($o=2$). Liczymy je jak w §4. Niech $F$ ogranicza sumę ważonych norm kolumny sprzęgającej środek z jego resztą. Dla jednego indeksu kwadrat normy tej kolumny jest ograniczony przez $\sum_{j\ge1} x^j J_0((M-4j-8j^2)_+d^2c^2)^2$; ogon od $j=24$ jest $\le x^{24}/(1-x)$. Gdy poprawki na $A_d-C_d$ mają łączną normę $\le e_1$, można odjąć $e_1 I_k$ od całej macierzy. Piszemy $e=E_0+e_1$.

We wkładzie jedynki koszt na samej centralnej przekątnej jest dokładnie $u/N$. Jej kolumna pozadiagonalna w tej parzystości ma normę najwyżej $g_0=(u/N)(\pi N/32)^{1/4}$, bo $U_{l,l-2a}\le e^{-4a^2/N}$ i $\sum_{a\ge1}e^{-8a^2/N}\le\sqrt{\pi N/32}$. Z kryterium dopełnienia Schura wystarczają trzy nierówności
\[
 e+O<1,\qquad 1-e-P>0,\qquad
 \frac{u}{N}+e_1-S_l(u)+\frac{(F+g_0)^2}{1-e-P}<1. \tag{4}
\]
To jest miejsce wykorzystania rzeczywistego znaku sumy (3). Tam, gdzie wystarcza granica bezwzględna z (2), program używa krótszej ścieżki.

## 6. Kontrola ciągłego przedziału i błędu obliczeń

Przy ustalonym $K$, na $v\in[(\log(K+1))^{-2},(\log K)^{-2}]$ wyrażenie (3) jest wielomianem stopnia $l$. Można je kontrolować oddzielnie po obu stronach progu. Przy liniowym przekształceniu $v$ ze zmiennej $\cos\theta$ otrzymujemy wielomian trygonometryczny $T$ stopnia $l$. Na odcinku $0\le\theta\le\pi$ pobieramy $L+1$ równomiernych węzłów, $L\ge ql$, gdzie $q=5$ albo $12$. Jeśli wartości węzłowe leżą w $[a,b]$, to na całym przedziale
\[
 \min T\ge a-\frac{5(b-a)}{8q^2-10}.
\]
Istotnie po odjęciu środka rzeczywistego zakresu o szerokości $W$ nierówność Bernsteina dwa razy daje $\|T''\|_\infty\le l^2 W/2$ (norma na okręgu jest tą samą normą). Błąd interpolacji liniowej na kroku $\pi/L$ jest $\le(\pi/L)^2\|T''\|_\infty/8$. Z $\epsilon=\pi^2l^2/(8L^2)<5/(4q^2)$ wynika $W\le (b-a)/(1-\epsilon)$ i podana granica. Na trudniejszych odcinkach stosujemy cztery podprzedziały w $v$. Nie zakładamy, że minimum jest w węźle.

Wartości węzłowe w **corner.py** liczone są rekurencją Legendre’a w arytmetyce całkowitoliczbowej o skali $Q=2^{46}$. Iloczyn z obcięciem w dół jest liczony na dwóch częściach 23-bitowych ze znakiem. Wstępne logarytmy, cosinusy i pierwiastki mają przedziały mpmath; funkcja konwertująca do skali $Q$ sprawdza szerokość mniejszą niż jednostka. Wartości $v_0$, $v_1-v_0$ i $(1+\cos\theta)/2$ są wprowadzane z błędem $<2/Q$ każda. W rzeczywistości $0<v_1-v_0<1.3$, bo największa różnica jest co najwyżej $(\log2)^{-2}-(\log3)^{-2}<1.3$ (różnice maleją z wypukłości $(\log x)^{-2}$ na $x>1$). Można też użyć dokładności z sprawdzonej szerokości w mpmath. Współrzędna $v$ ma błąd $<8/Q$, a w sprawdzanych komórkach $K<100$, $v\le2.09$, $\log^2 K<22$. Wobec tego błąd argumentu $1-2v\log^2 n$ jest $<370/Q$.

W skali rzeczywistej lokalna reszta rekurencji
\[
 z_{j+1}=\frac{(2j+1)xz_j-jz_{j-1}}{j+1}+\eta_{j+1}
\]
ma $|\eta_{j+1}|<750/Q$, gdyż sprawdzamy $|z_j|<1.001$; każdy z dwóch iloczynów lub podziałów z obcięciem ma błąd najwyżej jednej jednostki w odpowiedniej skali. Wartość początkowa $z_0=1$ jest dokładna, a błąd $z_1$ jest również $<750/Q$. Reszty nie rosną wykładniczo. Przy $D(z)=1-2xz+z^2$ funkcja tworząca błędu spełnia $D E'+D'E/2=\sum_{j\ge1}j\eta_j z^{j-1}$, skąd
\[
 E(z)=D(z)^{-1/2}\int_0^z D(w)^{-1/2}\sum_{j\ge1}j\eta_j w^{j-1}dw .
\]
Ponieważ $D^{-1/2}=\sum P_i(x)z^i$ i $|P_i(x)|\le1$ dla $|x|\le1$, w stopniu $l$ wzmocnienie reszty z kroku $j$ wynosi najwyżej $\sum_{k=0}^{l-j}j/(j+k)\le l-j+1$. Dla $l\le649$ błąd pojedynczej wartości jest więc $\le(750/Q)l(l+1)/2$. W całej sumie $\sum n^{-1/2}<20$. Wraz z błędem wag i obcięciem ich iloczynów daje to mniej niż $1/4000$, dodawane na obu końcach zakresu węzłowego. Użyte wartości w rekurencji są rzędu $Q$; po rozdzieleniu iloczynu na części 23-bitowe wszystkie pośrednie całkowite działania tablicowe mieszczą się w int64 (w szczególności przy mnożeniu przez $2j+1\le1299$).

Pozostałe tablice używają skali $2^{20}$ i 4096 koszyków dla $d$. Minimum $d^2(1-d^2)$ na koszyku występuje na końcu. Wagi, sumy i pierwiastki zaokrąglamy na zewnątrz. W sumach po $n$ bierzemy maksimum ze wszystkich koszyków, które może przeciąć dany przedział. W **verify.py** przy przejściu do następnego bloku rzędów ponownie podejmujemy obliczenia od $\lfloor e^{2b}\rfloor$; wcześniejsza część centrum została certyfikowana dla wszystkich $r\ge R$ dla tego samego $u$. Większy rząd powiększa jedynie potrzebny przedział. W częściach operujących na int64 największy skończony iloczyn skal w sumowaniu po indeksach jest ograniczony przez $4\cdot50000\cdot(2^{20})^2<2^{63}$. Iloczyny wyższych stopni w pojedynczych wzorach liczone są jako całkowite Pythona lub w etapach ze skalowaniem. Precyzja przedziałowa funkcji elementarnych wynosi 35 cyfr dziesiętnych.

## 7. Domknięcie argumentu

Największe zatwierdzone granice w środkowym zakresie, zaokrąglone w górę, wyniosły: $0.998768$ dla $33\le r\le649$ i $h\ge1$, $0.999141$ dla przypadków krytycznych w (4), $0.992082$ dla $650\le r\le1449$ oraz $0.988985$ dla $1450\le r<10^{11}$. W (4) oprócz granicy mniejszej od jedności sprawdzana jest ściśle dodatnia dolna granica mianownika.

Dodatnia określoność części symetrycznej zachowuje znak wyznacznika po odwróceniu kolumn. Dodatnie początkowe wrońskiany funkcji $R_{L+j}$ dają dodatni wyznacznik wartości na uporządkowanych węzłach. Na progach $a_n$ wystarcza lokalna absolutna ciągłość pochodnych rzędu $p-2$ i dodatniość ostatniego wrońskianu prawie wszędzie, przez iterowane całkowanie różnic po kolejnych przedziałach między węzłami. Szczegóły redukcji zawiera §3 noty dla dużych rzędów. Następnie (1) kontroluje dopełnienie centrum, jednostajnie w $X\ge\pi$. Tabele i argument dla dużych rzędów domykają podany na początku podział wszystkich dodatnich liczb całkowitych.

## Literatura użytych kryteriów

- J. Nuttall, *Cumulants, the Riemann Hypothesis, and Similar Problems*, §3.2–3.3, zwłaszcza (3.16) i (3.28). [Tekst pracy](https://publish.uwo.ca/~jnuttall/cumanal_a.pdf)
- S. Kalmykov, B. Nagy, V. Totik, *Bernstein- and Markov-type inequalities*, wzór (1) dla wielomianów trygonometrycznych. [Tekst przeglądu](https://publicatio.bibl.u-szeged.hu/22893/1/SATarXivupdate.pdf)

