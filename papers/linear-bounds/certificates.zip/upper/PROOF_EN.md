# Checking the intermediate orders in the bound \(m(r)\le 2r\)

This companion to §4 uses the notation of the English manuscript. The Polish derivation is in DOWOD.md. All ranks here are integers. All bounds on the symmetric part refer to its Euclidean operator norm. The seven runs of sprawdz.py cover orders 33 through \(10^{11}-1\). Their common input is the analytic reduction to finite node intervals, so these computations apply for every real \(t\ge0\).

## Truncating a node

On a rank block \(R\le r\le S\), hold all but one Andréief node fixed. The varying determinant row is \(f(u)=\sum c_jR_{L+j}(u)\). On \(0\le u\le1/3\), only the first theta term is active and \(f=u^{L-1}Q(u)\). Define \(F=\max_j|c_j|/(L+j)!\). A coefficient of \(Q\) has modulus at least \(F\), by subtracting the preceding normalized coefficient from \((L+j)c_j/(L+j)!\) at a maximum. Factor the polynomial and normalize each root distance by \(1+|z|\). Its mean logarithm on this interval is at least \(-1-\log12\). The analogous bound for a Vandermonde factor, normalized by \(1+e^{4v}\), is \(-1-\log6\). Indeed its modulus is at least \(\min(|u-v|,1/3)\), whose log average is smallest at the midpoint. Jensen's inequality gives the central mass bound in §4.3. The cutoff routine increases \(b\) until the two inequalities at the start of that subsection hold. The one-coordinate tail then costs at most \(1/(4S)\) of the central slice mass. Summing over \(p\le S\) keeps the absolute mass outside the cube below a quarter of the total.

## Parity and norm estimates

Fix an initial Wronskian of length \(k\le p\) and put \(h=m-p-k\). The inequalities \(M\ge r-1\) and \(M+h\ge 2r-2\) hold throughout. Positive definiteness of the symmetric part after multiplication by the alternating diagonal matrix \(J_k\) guarantees positivity of the determinant after the required sign change. The full matrix is invertible along the line segment to the identity, since the symmetric part stays positive definite.

The symmetric part of \(C_dJ_k\) preserves parity. If the distances from the center are \(o+2i\), \(o+2j\), the angular bound for entries is the mean of \(\exp(-A\cos^2\theta)\), with \(A=(M-2t-2t^2)_+d^2(1-d^2)\) and \(t=o+2\max(i,j)\). For \(A\le16\), the code evaluates the identity
\[
 J_0(A)=e^{-A/2}\sum_{j\ge0}(A/4)^{2j}/(j!)^2 .
\]
After term 35 the remaining positive sum is at most the last retained term, by the ratio test. For \(A\ge16\) the mean is at most \(0.585/\sqrt A\). Substitute \(y=|\cos\theta|\), use \((1-y^2)^{-1/2}\le1+y^2\) up to \(1/\sqrt2\), and bound the remaining contribution by \(e^{-A/2}\). For all \(A>0\), the simpler \(0.887/\sqrt A\) follows from the sine chord bound.

The squared entry bounds are summed in layers of constant \(\max(i,j)\). The weights in one parity form a geometric progression with ratio \(x=s_d^4\). After removing the common scaling, the tail from layer 24 costs at most \(2x^{24}/(1-x)^2\). For larger ranks a cheaper compression first bounds a central square by \(J_0(A)/(1-s_d^4)\). Two terms with a diagonal scaling factor at most \(s_d^t\) bound the rest by \(2s_d^t\). The program uses the smaller of these bounds and the contraction bound. The correction from \(A_d-C_d\) is controlled by the bound for \(V_dD_0\) derived in §4.3.

## The center when \(h=0\)

Only \(p=k=r\) gives \(h=0\). Here \(M=2\ell\), \(\ell=r-1\). After multiplication by \(J_k\) the central diagonal contribution for one shift equals
\[
 \sum_{j=0}^{\ell}\binom{\ell}{j}^{\!2}(1-d^2)^{\ell-j}(-d^2)^j
   =P_\ell(1-2d^2).
\]
This signed sum is retained. The program bounds the opposite-parity block (\(O\)), the same-parity block with the center removed (\(P\)), and the coupling column (\(F\)). The coupling column has squared tail at most \(x^{24}/(1-x)\). Subtracting \(e_1I\) absorbs all correction terms with \(n\ge2\), including off-parity errors. The scalar diagonal of this lower comparison is \(1-u/N+S_\ell-e_1\). Its coupling norm is at most \(F+g_0\). The denominator \(1-e-P\) is checked separately before division. Appendix A bounds the Legendre recurrence error. The angular sampling step bounds the entire polynomial between nodes by Bernstein's inequality.

## Rounding, coverage and replay

The tables use 4,096 bins and round norm bounds upward at scale \(2^{20}\). Each sum over theta indices uses the maximum on all bins intersecting the permitted range. Elementary functions use interval enclosures. The central recurrence uses scale \(2^{46}\) and splits signed products into 23-bit pieces. The maximum argument error is \(370/2^{46}\). The one-step error is bounded by \(750/2^{46}\). The inhomogeneous recurrence amplifies a local error from step \(j\) to degree \(\ell\) by at most \(\ell-j+1\), as proved in Appendix A. After weighting and rounding, both ends of the nodal range are expanded by \(1/4000\).

Run **python upper/sprawdz.py** from the supplement root, with Python assertions enabled. The two layer passes cover \(33\le r\le649\) with \(h\ge1\), then \(650\le r\le1449\) with \(h\ge0\). The large block program covers \(1450\le r<10^{11}\). The four center passes jointly cover \(33\le r\le649\). A trial block may be subdivided. Only the complete successful covers count. The largest accepted bounds, rounded upward, are respectively \(0.998768,0.992082,0.988985\), and \(0.999141\) over all four center passes. The analytic argument for \(r\ge10^{11}\) and the three historical covers for \(r\le32\) are separate parts of the proof.

