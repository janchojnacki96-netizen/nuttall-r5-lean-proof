"""Finite interval certificate using the two parity blocks of the symmetric part."""
from verify import *

@lru_cache(None)
def gauss_table():
    # Entry k encloses the mean of exp(-k*cos(theta)^2/64).
    g=[]
    for i in range(1025):
        a=iv.mpf(i)/64
        term=iv.mpf(1); value=iv.mpf(1)
        for ell in range(1,36):
            term*= (a/(4*ell))**2
            value+=term
        # All following ratios <=(16/144)^2 < 1/2.
        g.append(min(D,up(iv.exp(-a/2)*(value+term)*D)))
    for i in range(1025,100001):
        root=isqrt(i*D*D//64)
        g.append(min(D,ceildiv(585*D*D,1000*root)))
    return np.array(g,dtype=np.int64)

def root_array(x):
    return np.fromiter((isqrt(int(t))+1 for t in x),dtype=np.int64,count=len(x))

def par_tables(R,b,h,bonus,width=9):
    hmax=h+width
    M=max(R+bonus-1,2*R+2*bonus-2-hmax)
    E=up(D*b*(1/iv.mpf(M+1)+iv.sqrt(iv.pi/(M+1))/2))
    E2=up(D*b*(1/iv.mpf(R)+iv.sqrt(iv.pi/R)/2))
    eco=up(D*b*(1/iv.mpf(R)+iv.sqrt(iv.pi/R)))
    theta=up(D*b)
    j=np.arange(H//16,H,dtype=np.int64)
    # Integer envelopes for row/column scaling and cos(theta)^2 coefficient.
    s2=ceildiv(D*(H-j),H+j); x=ceildiv(s2*s2,D)
    s=np.minimum(D,root_array(s2*D))
    q=(np.minimum(j*j*(H*H-j*j),(j+1)**2*(H*H-(j+1)**2)))//(H**4//D)
    weights=[np.full(len(j),D,dtype=np.int64)]
    cum=np.zeros_like(j); coeff=[]
    for l in range(24):
        w=weights[-1]
        coeff.append(ceildiv(w*(2*cum+w),D))
        cum+=w
        weights.append(ceildiv(w*x,D))
    # x<=0.78 here. This form keeps all integer products below 2^63.
    tail=ceildiv(2*weights[-1]*D,D-x)
    tail=ceildiv(tail*D,D-x)
    sh=[np.full(len(j),D,dtype=np.int64)]
    for level in range(hmax+4):
        sh.append(ceildiv(sh[-1]*s,D))
    G=np.zeros_like(j)
    F=gauss_table()
    for start in ((h,h+2) if width==1 else (h,h+1,h+2,h+3)):
        sumsq=tail.copy()
        for l in range(24):
            t2=start+4*l
            v=max(0,2*M-2*t2-t2*t2)
            aidx=v*q*64//(2*D)
            assert max(aidx)<len(F)
            f=F[aidx]
            sq=ceildiv(f*f,D)
            sumsq+=ceildiv(sq*coeff[l],D)
        G=np.maximum(G,ceildiv(sh[start]*root_array(sumsq*D),D))
    G=np.minimum(G,sh[h])
    # Square of the Frobenius bound for V_d times the edge scaling.
    vr=[]
    for j0 in map(int,j):
        num=(H-j0)**2*j0*(H+j0)+2*H**2*(H-j0)*(H+j0)
        den=8*H**2*j0**2
        vr.append(isqrt(ceildiv(num*D*D,den))+1)
    vv=np.array(vr,dtype=np.int64)
    vc=ceildiv(2*theta*vv,(M+1)*D)
    correction=ceildiv(vc*sh[h],D)
    G=np.minimum(G+correction,ceildiv((D+eco)*sh[h],D))
    large=ceildiv((D+eco)*sh[hmax],D)
    def finish(a,last):
        return np.r_[np.full(H//16,D+eco,dtype=np.int64),a,last]
    return [(E,finish(G,0 if h else D)),(E2,finish(large,0))]

def check_layer(R,S,h,bonus,split=True):
    b=cutoff(S+(bonus+1)//2)
    last=int(iv.exp(2*b).b)
    weights=np.array([w_upper(n) for n in range(2,last+1)],dtype=np.int64)
    logs=np.array([ln_floor(n) for n in range(2,last+2)],dtype=np.int64)
    worst=0
    if split:
        tables=[par_tables(R,b,h+d,bonus,1)[0] for d in range(3)]
        tables+=par_tables(R,b,h+3,bonus)
    else:
        tables=par_tables(R,b,h,bonus)
    for E,A in tables:
        for k in range(2,last+1):
            # log(e^{2u}) traverses [log k,log(k+1)]; use four overlapping enclosures.
            lk,lk1=ln_floor(k),ln_floor(k+1)
            for part in range(4):
                v0=((4-part)*lk+part*lk1)//4
                v1=ceildiv((3-part)*(lk+1)+(part+1)*(lk1+1),4)
                lo=H*logs[:k-1]//v1
                hi=np.minimum(H,H*(logs[:k-1]+1)//v0)
                total=sum(int(w)*int(A[a:b+1].max()) for w,a,b in zip(weights,lo,hi))
                worst=max(worst,E+ceildiv(total,D))
    return worst/D

def run_layers(start,stop,h,bonus):
    r=start; worst=0
    while r<=stop:
        end=min(stop,r+max(1,r//25))
        z=check_layer(r,end,h,bonus)
        print(r,end,h,bonus,z,flush=True)
        if z>=1:return False
        worst=max(worst,z);r=end+1
    print('PASS. Maximum upper bound',worst,flush=True)
    return True

if __name__=='__main__':
    import sys
    assert run_layers(*map(int,sys.argv[1:]))
