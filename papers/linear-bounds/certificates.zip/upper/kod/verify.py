"""Enclosures for the Nuttall determinant test. Run with Python, mpmath, numpy."""
from math import isqrt
from functools import lru_cache
import numpy as np
from mpmath import iv

iv.dps = 35
D, H, J = 2**20, 4096, 2**32

def ceildiv(a,b):
    return (a+b-1)//b

def up(x):
    return int(x.b)+1

def dn(x):
    return int(x.a)

def pow_up(x,e):
    out=D
    while e:
        if e%2:
            out=ceildiv(out*x,D)
        x=ceildiv(x*x,D)
        e//=2
    return out

def cutoff(S):
    bnum=100
    while True:
        b=iv.mpf(bnum)/100
        z=iv.log(24*S*S*(2*S+b))+(4*S+2)*b+2*S*iv.log(b)+9*S-iv.pi*(iv.exp(4*b)-4)
        if z.b<0 and (4*iv.pi*iv.exp(4*b)).a>6*S+4: return b
        bnum+=1

def norm_table(R,b):
    M=2*R-2-R//20
    terms=[]
    for f in [12,19,26,34,42,50,56,62]:
        t=2*(isqrt(M*f*f)//200)
        v=M-2*t-2*t*t
        if t and v>0: terms.append((t//2,v))
    u=up(b*D)
    eco=up(b*(1/iv.mpf(R)+iv.sqrt(iv.pi/R))*D)
    tab=[D+eco]
    for j in range(1,H):
        q=min(x*x*(H*H-x*x) for x in (j,j+1))
        s2=ceildiv(D*(H-j),H+j)
        best=D
        for half,v in terms:
            a_num=q*v
            root=isqrt(a_num*D*D//H**4)
            if not root: continue
            c=585 if a_num>=16*H**4 else 887
            near=ceildiv(c*D*D*(H+j)**2,1000*root*4*j*H)
            val=near+2*pow_up(s2,half)
            best=min(best,val)
        # V_d times the edge scaling: Frobenius bound squared <= 1/(4(1-s^2)) + s^2/(1-s^2)^2.
        # In the first term the diagonal (1-d)/2 is retained.
        num=(H-j)**2*j*(H+j)+2*H**2*(H-j)*(H+j)
        den=8*H**2*j**2
        vroot=isqrt(ceildiv(num*D*D,den))+1
        correction=ceildiv(2*u*vroot,(M+1)*D)
        small=min(D+eco,best+correction)
        large=ceildiv((D+eco)*pow_up(s2,R//40),D)
        tab.append(max(small,large))
    tab.append(D+1)
    return np.array(tab,dtype=np.int64)

@lru_cache(None)
def ln_floor(n):
    return dn(iv.log(n)*J)

@lru_cache(None)
def w_upper(n):
    return up(D/iv.sqrt(n))

def scalar_check(R,S,first,b):
    last=int(iv.exp(2*b).b)
    assert last<50000 and 4*last*D**2 < 2**63
    weights=np.array([w_upper(i) for i in range(2,last+1)],dtype=np.int64)
    logs=np.array([ln_floor(i) for i in range(2,last+2)],dtype=np.int64)
    A=norm_table(R,b)
    sparse=[A]
    while 2*len(sparse)<=100 and 2**len(sparse)<=H+1:
        step=2**(len(sparse)-1)
        x=sparse[-1]
        sparse.append(np.maximum(x[:-step],x[step:]))
    exp2=np.array([j.bit_length()-1 for j in range(1,H+2)],dtype=np.int64)
    E=up(D*b*(1/iv.mpf(R)+iv.sqrt(iv.pi/R)/2))
    worst=0
    loc=None
    k=first
    while k<=last:
        width=max(1,isqrt(k)//18)
        end=min(k+width-1,last)
        count=end-1
        lo=H*logs[:count]//(ln_floor(end+1)+1)
        hi=np.minimum(H,H*(logs[:count]+1)//ln_floor(k))
        bits=exp2[hi-lo]
        bounds=np.zeros(count,dtype=np.int64)
        for power in np.unique(bits):
            mask=bits==power
            j=lo[mask]; zz=hi[mask]-(1<<int(power))+1
            bounds[mask]=np.maximum(sparse[power][j],sparse[power][zz])
        total=int(weights[:count]@bounds)
        score=E+ceildiv(total,D)
        if score>worst:worst,loc=score,(k,end)
        k=end+1
    return dn(iv.exp(2*b)),worst/D,loc

def high(R,S,b):
    M=iv.mpf(2*R-2-R//20)
    T=iv.sqrt(M)*iv.mpf('.24')
    g=iv.sqrt(M-2*T-2*T*T)
    E=b*(1/iv.mpf(R)+iv.sqrt(iv.pi/R))
    a=iv.log(2)/2
    scores=[]
    for u,weight in [(iv.mpf(2),1/iv.sqrt(2)),(b,1/iv.sqrt(54))]:
        low=0
        for lo,hi in [(a/u,iv.mpf('.35')),(iv.mpf('.35'),iv.mpf('.60')),(iv.mpf('.60'),iv.mpf('.82'))]:
            assert lo.b<hi.a
            fac=lambda d:(1+d)/(2*d*d*iv.sqrt(1-d*d))
            mx=max(fac(lo).b,fac(hi).b)
            low+=2*iv.exp(hi*u)*mx
        big=4*iv.sqrt(2*u)*iv.exp(u)*iv.sqrt(2)/(2*iv.mpf('.82')**2)
        far=4*iv.exp(u)*iv.exp(-a*T/u)
        # If M_actual < M then h >= R//20; bound that case separately.
        other=2*iv.exp(u)*iv.exp(-a*(R//20)/u)
        s=E+(1+E)*max((weight+(low+big)*iv.mpf('.887')/g+far).b, other.b)
        scores.append(up(s*D)/D)
    return max(scores)

def all_ranges(start,stop=10**11):
    R=start
    first=2
    result=0
    while R<stop:
        if R<1600: S=min(stop-1,R+4)
        elif R<20000: S=min(stop-1, R*105//100)
        elif R<1000000: S=min(stop-1,R*14//10)
        else: S=min(stop-1,R*17//10)
        b=cutoff(S)
        if R<10**7:
            nex,z,at=scalar_check(R,S,first,b)
            print(R,S,'B',float(b.a),'od K',first,'kolejne K',nex,'upper',z,'at',at,flush=True)
            first=nex
        else:
            z=high(R,S,b)
            print(R,S,'analytic',float(b.a),z,flush=True)
        result=max(z,result)
        if z>=1:return False
        R=S+1
    print('PASS. Maximum upper bound',result,flush=True)
    return True

if __name__=='__main__':
    import sys
    assert all_ranges(int(sys.argv[1]) if len(sys.argv)>1 else 5000)
