"""Signed last diagonal of the critical block, checked over consecutive intervals."""
from layers import *
import sys
from fractions import Fraction

Q=2**46
BINARY=2**23

def floor_q(x):
    y=x*Q
    assert (y.b-y.a).b<1
    return int(y.a) if y.a>=0 else int(y.a)-1

def mul_q(x,y):
    # floor(x*y/Q) with signed int64 limbs; x,y each represent Q times a real.
    xh=x//BINARY; xl=x%BINARY
    yh=y//BINARY; yl=y%BINARY
    return xh*yh+(xh*yl+xl*yh+(xl*yl)//BINARY)//BINARY

@lru_cache(None)
def cosnodes(L):
    return np.array([max(0,floor_q((1+iv.cos(iv.pi*j/L))/2)) for j in range(L+1)],dtype=np.int64)

@lru_cache(None)
def log2_q(n):
    return floor_q(iv.log(n)**2)

@lru_cache(None)
def weight_q(n):
    return floor_q(1/iv.sqrt(n))

def minima(R,S,k,part=0,parts=1,rate=8):
    L=rate*(S-1)
    va=1/iv.log(k+1)**2
    vb=1/iv.log(k)**2
    v0=va+(vb-va)*part/parts
    v1=va+(vb-va)*(part+1)/parts
    v=floor_q(v0)+mul_q(floor_q(v1-v0),cosnodes(L))
    n=list(range(2,k+1))
    logs2=np.array([log2_q(i) for i in n],dtype=np.int64)
    weights=np.array([weight_q(i) for i in n],dtype=np.int64)
    xx=Q-2*mul_q(v[:,None],logs2[None,:])
    assert k<100 and S<=650 and np.max(np.abs(xx))<=Q+320
    zm=np.full_like(xx,Q); z=xx.copy()
    low=Q*100
    for j in range(1,S):
        if j>=R-1:
            sums=np.sum(mul_q(z,weights[None,:]),axis=1)
            safety=ceildiv(Q,4000)
            lo=int(sums.min())-safety; hi=int(sums.max())+safety
            low=min(low,lo-ceildiv(5*(hi-lo),8*rate**2-10))
        if j+1<S:
            zz=((2*j+1)*mul_q(xx,z)-j*zm)//(j+1)
            zm,z=z,zz
            assert np.max(np.abs(z))<Q+Q//1000
    return iv.mpf(low)/Q

def edge_table(R):
    M=2*R-2; j=np.arange(H//16,H,dtype=np.int64)
    s2=ceildiv(D*(H-j),H+j); x=ceildiv(s2*s2,D)
    q=np.minimum(j*j*(H*H-j*j),(j+1)**2*(H*H-(j+1)**2))//(H**4//D)
    F=gauss_table()
    def g(t):
        aidx=max(0,M-2*t-2*t*t)*q*64//D
        f=F[aidx]
        return ceildiv(f*f,D)
    one=np.full(len(j),D,dtype=np.int64); w=one.copy(); cum=0
    norms={o:np.zeros_like(j) for o in (1,2)}
    vec=np.zeros_like(j)
    for l in range(24):
        coef=ceildiv(w*(2*cum+w),D)
        for o in norms:
            norms[o]+=ceildiv(coef*g(o+2*l),D)
        if l:vec+=ceildiv(w*g(2*l),D)
        cum+=w; w=ceildiv(w*x,D)
    tail=ceildiv(w*D,D-x)
    vec+=tail
    for o in norms:
        norms[o]+=ceildiv(2*tail*D,D-x)
        factor=s2 if o==1 else x
        norms[o]=np.minimum(factor,ceildiv(factor*root_array(norms[o]*D),D))
    vec=np.minimum(D,root_array(vec*D))
    vv=[]
    for t in map(int,j):
        num=(H-t)**2*t*(H+t)+2*H**2*(H-t)*(H+t)
        den=8*H**2*t*t
        vv.append(isqrt(ceildiv(num*D*D,den))+1)
    tab=np.stack([norms[1],norms[2],vec,np.array(vv),np.minimum(D,root_array(g(0)*D))],axis=0)
    # Only d>=a2/B>1/16 occurs. The sentinel below catches any change.
    return np.c_[np.full((5,H//16),100*D,dtype=np.int64),tab,np.array([[0],[0],[0],[0],[D]],dtype=np.int64)]

def check(R,S):
    b=cutoff(S)
    last=int(iv.exp(2*b).b)
    A=edge_table(R)
    worst=0
    for k in range(2,last+1):
        def cell(part,parts,rate):
            # Match the subdivision in v exactly; only outward integer index limits enter A.
            va=1/iv.log(k+1)**2;vb=1/iv.log(k)**2
            v0=va+(vb-va)*part/parts;v1=va+(vb-va)*(part+1)/parts
            u=1/(2*iv.sqrt(v0))
            V=[0,0,0,0,0]
            for n in range(2,k+1):
                al=iv.log(n)*iv.sqrt(v0); ar=iv.log(n)*iv.sqrt(v1)
                lo=max(0,min(H,int((H*al).a)))
                hi=min(H,int((H*ar).b))
                assert lo>=H//16
                for j in range(5):
                    V[j]+=w_upper(n)*int(A[j,lo:hi+1].max())
            O,P,F,VC,Diag=[iv.mpf(t)/(D*D) for t in V]
            N=2*R-1
            e=u*(1/iv.mpf(N)+iv.sqrt(iv.pi/N)/2)+2*u*VC/N
            if (1-e-P).a<=0: return 2.
            g0=u/N*(iv.pi*(2*S-1)/32)**iv.mpf('.25')
            cost=(u+2*u*VC)/N+(F+g0)**2/(1-e-P)
            score=max((e+O).b,(cost+Diag).b)
            if score>=1:
                v=minima(R,S,k,part,parts,rate)
                score=max((e+O).b,(cost-v).b)
            return up(D*score)/D
        z=cell(0,1,5)
        if z>=1:z=max(cell(part,4,12) for part in range(4))
        if z>=1:
            print('FAIL',R,S,'K',k,'score',z,flush=True);return z
        worst=max(worst,z)
    return worst

def run(a,b):
    r=a;worst=0
    while r<=b:
        end=min(b,r+max(0,r//18))
        z=check(r,end)
        if z>=1 and end>r:
            end=r
            z=check(r,r)
        print(r,end,'Schur',z,flush=True)
        if z>=1:return False
        worst=max(worst,z);r=end+1
    print('PASS. Maximum upper bound',worst,flush=True)
    return True

if __name__=='__main__':
    assert run(*map(int,sys.argv[1:]))
