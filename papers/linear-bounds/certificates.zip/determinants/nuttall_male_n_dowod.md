# Wyznaczniki Nuttalla dla małych \(n\) i dowolnych \(r\)

Niech \(F(z)=\xi(\tfrac12+\sqrt z)=\sum_{k\ge0}a_kz^k\), gdzie wartość jest niezależna od wyboru pierwiastka, i niech \(a_k=0\) dla \(k<0\). Dla \(D(n,r)=\det[a_{n+i-j}]_{i,j=0}^{r-1}\) zachodzi
\[
\boxed{D(n,r)>0\qquad(0\le n\le80\,000\,000\,000,\quad r\ge1).}
\]
Dowód używa bezwarunkowej weryfikacji zer do wysokości \(T=3\cdot10^{12}\) w pracy Platta i Trudgiana. Dopuszcza zera poza prostą krytyczną powyżej \(T\).

## 1. Dokładna tożsamość dla prostokąta

Mamy \(a_0>0\) i iloczyn Hadamarda
\[
 F(z)/a_0=\prod_{\rho=\beta+i\gamma,\ \gamma>0}(1+x_\rho z),
 \qquad x_\rho=-\frac{1}{(\rho-\tfrac12)^2}.
\]
Funkcja \(F\) ma rząd \(1/2\), bo \(\xi\) ma rząd 1 i jest parzysta wokół \(1/2\). Iloczyn ma więc rodzaj zero. Każdy pierwiastek \(z=(\rho-\tfrac12)^2\) odpowiada parze \(\rho,1-\rho\), z której dokładnie jedno zero jest nad osią rzeczywistą. Szereg \(\sum_\rho |x_\rho|\) jest zbieżny, ponieważ \(|x_\rho|\le\gamma^{-2}\) i \(N(v)=O(v\log v)\). Dla \(n=0\) macierz jest trójkątna z przekątną \(a_0\), więc \(D(0,r)=a_0^r\).

Dla \(n\ge1\) weźmy \(X=(x_1,\ldots,x_n)\) odpowiadające \(n\) pierwszym prostym zerom, wszystkie poniżej \(T\). Są to liczby \(x_i=\gamma_i^{-2}>0\). Niech \(Y\) oznacza resztę zmiennych, \(B=(x_1^{-1},\ldots,x_n^{-1})\), a \(P=\prod_{i=1}^n x_i\). Z tożsamości dualnej Jacobiego–Trudiego i rozwinięcia funkcji Schura według dwóch alfabetów dostajemy
\[
 \frac{D(n,r)}{a_0^r}
 =s_{(r^n)}(X,Y)
 =P^r \sum_{\nu\subseteq(r^n)}s_\nu(B)s_\nu(Y).
 \tag{1}
\]
Istotnie, dla \(\mu\subseteq(r^n)\) niech \(\nu_i=r-\mu_{n+1-i}\), z dopełnieniem \(\mu\) zerami. Tablica skośna kształtu \((r^n)/\mu\) po obrocie o \(180^\circ\) i odwróceniu porządku symboli staje się tablicą kształtu \(\nu\). Symetria funkcji Schura daje \(s_{(r^n)/\mu}(Y)=s_\nu(Y)\). Z ilorazu alternantów mamy \(s_\mu(X)=P^r s_\nu(B)\): odwrócenie wierszy w liczniku i mianowniku dla \(X^{-1}\) i wyjęcie potęg z kolumn daje dokładnie ten czynnik. Dla nieskończonego alfabetu używamy granicy skończonych obcięć z powodu \(\sum_\rho |x_\rho|<\infty\).

## 2. Kontrola faz w sumie Schura

Najpierw bierzemy skończone obcięcie \(Y=(y_j)_{j=1}^m\) domknięte na sprzężenia. Niech \(q_{ij}=B_i|y_j|\). Jeśli \(\gamma\) zera odpowiadającego \(y_j\) jest większa od \(\gamma_n\), to \(q_{ij}\le\gamma_i^2/\gamma^2<1\). W naszym zastosowaniu wszystkie pozostałe zera mają większą wysokość, bo \(n\)-te zero jest proste i leży poniżej \(T\).

Niech \(M_{ij}\) będą niezależnymi zmiennymi geometrycznymi z \(\Pr(M_{ij}=k)=(1-q_{ij})q_{ij}^k\), \(k\ge0\), a \(C_j=\sum_i M_{ij}\). Korespondencja Robinsona–Schensteda–Knutha (RSK) odwzorowuje \(M\) na parę tablic tego samego kształtu \(\nu\) o wagach równych sumom wierszy i kolumn. Pierwszy wiersz \(\nu_1\) jest maksymalną sumą wpisów po rosnącej ścieżce od \((1,1)\) do \((n,m)\). Zdarzenie \(E=\{\nu_1\le r\}\) jest zatem malejące względem każdego wpisu \(M_{ij}\), a \(\Pr(E)>0\), bo zawiera macierz zerową. Liczba wierszy \(\nu\) jest najwyżej \(n\).

Po zestawieniu wag tablic dostajemy tożsamość
\[
 \frac{\sum_{\nu\subseteq(r^n)}s_\nu(B)s_\nu(Y)}
      {\sum_{\nu\subseteq(r^n)}s_\nu(B)s_\nu(|Y|)}
 =\mathbb E\!\left[e^{i\Theta}\mid E\right],
 \qquad
 \Theta=\sum_j (\arg y_j)C_j .
 \tag{2}
\]
W mianowniku wyraz pustej partycji jest równy 1, a pozostałe wyrazy są nieujemne.

Tworząca funkcja warunkowego rozkładu wektora \(C\) jest proporcjonalna do \(\sum_{\nu\subseteq(r^n)}s_\nu(B)s_\nu((|y_j|z_j)_j)\). Gdy \(|y_a|=|y_b|\), jest symetryczna względem niezależnej zamiany \(z_a,z_b\). Dla każdej nierzeczywistej pary \(\ell\) zmiennych \(y_a,y_b=\overline{y_a}\) piszemy \(\theta_\ell=\arg y_a\) i \(J_\ell=C_a-C_b\). Dodatnie \(y_j\) nie wnoszą fazy. Zamiana w parze zmienia znak \(J_\ell\) i zachowuje wszystkie \(J_k\) dla \(k\ne\ell\). Dlatego
\[
 \mathbb E[\Theta^2\mid E]
 =\sum_\ell\theta_\ell^2\,\mathbb E[J_\ell^2\mid E].
 \tag{3}
\]
W szczególności prawa strona (2) jest rzeczywista.

Dla pary \((a,b)\) funkcja \((C_a+C_b)^2\) jest rosnąca względem wpisów macierzy. Rosnąca funkcja \(f\) i malejące zdarzenie \(E\) w mierze produktowej spełniają \(\mathbb E[f\mid E]\le\mathbb E[f]\). W jednej zmiennej wynika to z tożsamości kowariancji przez dwie niezależne kopie. Indukcja przez warunkowanie względem jednej współrzędnej daje przypadek wielowymiarowy, ponieważ warunkowe średnie zachowują monotoniczność w pozostałej współrzędnej. Stąd
\[
 \mathbb E[J_\ell^2\mid E]
 \le \mathbb E[(C_a+C_b)^2\mid E]
 \le \mathbb E[(C_a+C_b)^2].
 \tag{4}
\]

Ustalmy \(U<T\) takie, że \(\gamma_n\le U\), i zdefiniujmy
\[
 A=\sum_{i=1}^n\gamma_i^2,\quad
 \alpha=U^2/T^2,\quad
 S_k=\sum_{\gamma>T}\gamma^{-k}.
\]
Nierzeczywista para pochodzi od zer \(\beta+i\gamma,1-\beta+i\gamma\) z \(\gamma>T\). Dla takiej pary \(q_{ij}\le B_i/\gamma^2\le\alpha\) i \(|\theta_\ell|=2|\arctan((\beta-\tfrac12)/\gamma)|\le1/\gamma\), bo \(0<\beta<1\). Ze średniej \(q/(1-q)\) i wariancji \(q/(1-q)^2\) zmiennej geometrycznej oraz niezależności wpisów mamy
\[
 \mathbb E[(C_a+C_b)^2]
 \le \frac{4A^2/\gamma^4+2A/\gamma^2}{(1-\alpha)^2}.
\]
Każda para to dwa zera liczone w \(S_k\), a ewentualne zera na prostej powyżej \(T\) tylko zwiększają \(S_k\). Po uwzględnieniu (3) i (4) nierówność \(\cos\Theta\ge1-\Theta^2/2\) daje
\[
 \mathbb E[\cos\Theta\mid E]
 \ge 1-\frac{A^2 S_6+(A/2)S_4}{(1-\alpha)^2}.
 \tag{5}
\]
Prawa strona jest niezależna od obcięcia i \(r\). Jeśli jest dodatnia, to (1) i (2) dają dla skończonych obcięć dolne ograniczenie \(a_0^rP^r\) razy prawa strona (5), dzięki wyrazowi pustej partycji w mianowniku (2). W granicy współczynniki iloczynu i ich wyznaczniki są zbieżne, więc dodatnie ograniczenie obowiązuje także dla \(F\).

## 3. Jawne stałe

Bierzemy \(U=24\,000\,000\,000\). Funkcja \(N(v)\) liczy zera o \(0<\gamma\le v\) z krotnościami. Używamy oszacowania Trudgiana w postaci zapisanej przez Dusarta:
\[
 |N(v)-H(v)|\le R(v),\qquad
 H(v)=\frac{v}{2\pi}\left(\log\frac{v}{2\pi}-1\right)+\frac78,\quad
 R(v)=0.112\log v+0.278\log\log v+2.510+\frac{0.2}{v}.
\]
Dla \(v\ge14\), \(R(v)\le2\log v\), co wynika z nierówności w \(v=14\) i porównania pochodnych. Na \([14,U]\) mamy \(R(v)<50\). Ponieważ \(H(U)-50>80\,000\,000\,000\), każdy użyty indeks \(n\) spełnia \(\gamma_n\le U\). Nie ma zer o \(0<\gamma\le14\). Całkowanie przez części względem \(N\) na \((14,U]\) daje
\[
 A\le\sum_{\gamma\le U}\gamma^2
 \le\frac{U^3}{6\pi}\left(\log\frac U{2\pi}-\frac13\right)
       + 100U^2+1000
 <1.6\cdot10^{31}.
\]
Dwa składniki błędu to odpowiednio \(50U^2\) z górnego końca i co najwyżej \(50U^2\) z całki. Przy zastąpieniu dolnego końca całki głównej zerem uzyskujemy oszacowanie górne, bo \(H'(v)=\log(v/(2\pi))/(2\pi)\) i \(\int_0^{14}v^2H'(v)\,dv>0\). Dodatek 1000 jest zapasem.

Na ogonie całkowanie przez części daje dla \(k>1\)
\[
 S_k
 \le \frac{\log(T/(2\pi))+1/(k-1)}{2\pi(k-1)T^{k-1}}
    +\frac{4\log T+2/k}{T^k}.
\]
Pierwszy wyraz to \(\int_T^\infty v^{-k}H'(v)\,dv\). Drugi pochodzi z ograniczenia \(2\log v\) w wyrazie brzegowym \(T^{-k}|N(T)-H(T)|\) i w \(k\int_T^\infty v^{-k-1}|N(v)-H(v)|\,dv\).

Liczbowo \(S_4<5.4\cdot10^{-38}\), \(S_6<3.6\cdot10^{-63}\), a \(\alpha=0.000064\). Po podstawieniu
\[
 \frac{A^2 S_6+(A/2)S_4}{(1-\alpha)^2}<0.923.
\]
Nierówności liczbowe sprawdzono arytmetyką przedziałową z 60 cyframi precyzji. W (5) pozostaje margines ponad \(0.077\). Z (1)–(2) wynika na przykład jawna dolna granica \(0.077\,a_0^r(\prod_{i=1}^n\gamma_i^{-2})^r\) dla \(D(n,r)\) w podanym zakresie.

Wynik obejmuje także \(r>9\cdot10^{12}\) i nie korzysta z wcześniejszej deklaracji o zakresie \(r\le9\cdot10^{12}\). Wyprowadzone kryterium (5) można stosować dla innych \(U,T\), o ile pierwsze \(n\) zer leżą poniżej \(U\), a do wysokości \(T\) jest znana prostota zer i ich położenie na prostej. Konkretnie udowodniony pas ma stały górny kres \(n=80\,000\,000\,000\). Nadal pozostaje kontrola \(n\) większych od tego kresu, które rosną razem z \(r\) i leżą poniżej progu dla metody dużych \(n\). Dowód jest analityczny, z weryfikacją stałych, bez formalizacji w Lean i bez oceny pierwszeństwa.

## Źródła

- John Nuttall, [Wronskians, Cumulants, and the Riemann Hypothesis](https://publish.uwo.ca/~jnuttall/det3CAEXP_2.pdf).
- Dave Platt i Tim Trudgian, [The Riemann hypothesis is true up to \(3\cdot10^{12}\)](https://doi.org/10.1112/blms.12460).
- Pierre Dusart, [Improved explicit bounds for some functions of prime numbers](https://doi.org/10.7169/facm/1547), wzór (3).
- Kurt Johansson, [Shape Fluctuations and Random Matrices](https://sites.math.northwestern.edu/~auffing/papers/J2000.pdf), §2.1.
- LMFDB, [Źródło danych o zerach funkcji dzeta](https://www.lmfdb.org/zeros/zeta/Source).
