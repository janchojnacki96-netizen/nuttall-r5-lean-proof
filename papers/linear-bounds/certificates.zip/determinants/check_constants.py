"""Outward-rounded scalar bounds for Appendix C. Requires mpmath 1.3."""
from fractions import Fraction
from mpmath import iv

iv.dps = 60
I = iv.mpf
T = I(3) * 10**12
U = I(32400000000)
L = iv.ln(T)


def require(test, name, interval):
    if not test:
        raise ArithmeticError(f"{name} failed: {interval}")
    print(f"{name}: {interval}")


def H(height):
    return height / (2 * iv.pi) * (iv.ln(height / (2 * iv.pi)) - 1) + I(7) / 8


def all_zeros_tail(k):
    return ((iv.ln(T / (2 * iv.pi)) + I(1) / (k - 1))
            / (2 * iv.pi * (k - 1) * T**(k - 1)) + (4 * L + I(2) / k) / T**k)


def density_tail(k, sigma, c, d):
    a, b = 8 * (1 - sigma) / 3, 5 - 2 * sigma
    return 2 * k * (c * L**b * T**(a-k) / (k-a-b/L)
                    + d * L**2 * T**(-k) / (k-2/L))


def weighted_tail(k):
    return (I('0.49') * all_zeros_tail(k)
            + I('0.15') * density_tail(k, I('0.85'), I('8.98'), I('3.59'))
            + I('0.36') * density_tail(k, I('0.90'), I('11.50'), I('3.19')))


# The sector estimate uses the full endpoint of Platt--Trudgian, Theorem 1.
# The independent phase estimate retains the round height T above.
verified_height = I(3_000_175_332_800)
theta = (1 - 2 / (I('4.896') * iv.ln(verified_height))) / verified_height
sector_order = 9_561_277_002_984
fraction = iv.pi / theta - 1 - sector_order
require(I('0.1253') < fraction < I('0.1254'), 'fractional part at sector endpoint', fraction)
require((sector_order + 1) * theta < iv.pi, 'sector endpoint: positive angular margin',
        iv.pi - (sector_order + 1) * theta)
require(iv.pi < (sector_order + 2) * theta, 'next order exceeds this angular bound',
        (sector_order + 2) * theta - iv.pi)
# Sra (arXiv:2611.02944v1, Theorem 1.2) supplies the analytic PF order.
# Only its numerical overlap with the sector bound is checked here.
sra_order = 1_810_540_931_075
require(1 <= sra_order <= sector_order, 'sector overlap for r < n <= K_*',
        sector_order - sra_order)
require(2 * iv.ln(U) < 50, 'counting error below 50', 2 * iv.ln(U))
require(H(U)-50 > 110000000000, 'count at U, lower bound', H(U)-50)
# Published inputs: Platt--Trudgian, Theorem 1, and Knausgård, Theorem 1.3.
verified_zero_count = 12_363_153_437_138
gap_shift_endpoint = 12_363_153_437_137
require(gap_shift_endpoint + 1 == verified_zero_count,
        'last shift with both consecutive ordinates verified', gap_shift_endpoint)
simple_on_line = Fraction(1_669_159, 2_478_195)
require(simple_on_line > Fraction(6735, 10000),
        'density bound exceeds 0.6735', simple_on_line)
A = U**3 / (6*iv.pi) * (iv.ln(U/(2*iv.pi))-I(1)/3) + 100*U**2 + 1000
alpha = (U/T)**2
W4, W6 = weighted_tail(4), weighted_tail(6)
require(W4 < I('2.66e-38'), 'weighted fourth tail, upper bound', W4)
require(W6 < I('1.77e-63'), 'weighted sixth tail, upper bound', W6)
loss = (A**2*W6 + I('1.5')*A*W4) / (3*(1-alpha)**2)
require(loss < I('0.931'), 'phase loss below 0.931', loss)
print("PASS: all determinant constants.")
