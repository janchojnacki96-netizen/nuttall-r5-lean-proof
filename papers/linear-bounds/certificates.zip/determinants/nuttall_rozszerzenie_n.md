# Rozszerzenie zakresu wyznaczników \(D(n,r)\)

Niech \(F(z)=\xi(\tfrac12+\sqrt z)=\sum_{j\ge0}a_jz^j\) i \(D(n,r)=\det[a_{n+i-j}]_{i,j=0}^{r-1}\), z \(a_j=0\) dla \(j<0\). Poniższe trzy zakresy dodatniości są bezwarunkowe.

| Indeks \(n\) | Rząd \(r\) |
|---|---|
| \(0\le n\le110\,000\,000\,000\) | Każde \(r\ge1\) |
| \(0\le n<\infty\) | \(1\le r\le9\,540\,000\,000\,000\) |
| \(1\le n\le12\,360\,000\,000\,000\) | Każde \(r\) spełniające jawne kryterium (6) |

Używamy weryfikacji Platta i Trudgiana z \(T=3\cdot10^{12}\). Tam, gdzie potrzebujemy granic dla liczby zer, używamy oszacowania Trudgiana w postaci zapisanej przez Dusarta. Tożsamość Schura i jej interpretację RSK stosujemy w normalizacji z wcześniejszej noty *Wyznaczniki Nuttalla dla małych \(n\) i dowolnych \(r\)*.

## 1. Dodatniość dla wszystkich \(r\) do \(n=110\) miliardów

Z iloczynu Hadamarda \(F/a_0=\prod_{\rho}(1+x_\rho z)\), gdzie \(x_\rho=-(\rho-\tfrac12)^{-2}\), bierzemy \(X=(\gamma_1^{-2},\ldots,\gamma_n^{-2})\) z pierwszych \(n\) zer na prostej. Wszystkie zera liczymy w górnej półpłaszczyźnie. Definiujemy \(B=(\gamma_1^2,\ldots,\gamma_n^2)\), \(P=\prod_{i=1}^n\gamma_i^{-2}\), a pozostałe zmienne oznaczamy przez \(Y\). Używamy tożsamości dualnej Jacobiego–Trudiego i dopełnienia partycji w prostokącie:
\[
 D(n,r)=a_0^r P^r\sum_{\nu\subseteq(r^n)}s_\nu(B)s_\nu(Y).
 \tag{1}
\]
Dla skończonego obcięcia \(Y=(y_j)\) zawierającego całe pary sprzężone niech \(M_{ij}\) będą niezależnymi geometrycznymi na \(\{0,1,\ldots\}\) z parametrami \(q_{ij}=B_i |y_j|\), czyli \(\Pr(M_{ij}=k)=(1-q_{ij})q_{ij}^k\). Wszystkie \(q_{ij}<1\), bo pierwszych \(n\) zer jest prostych i mają mniejsze wysokości niż pozostałe. Piszemy \(C_j=\sum_i M_{ij}\). Zdarzenie \(E=\{\nu_1\le r\}\) w RSK jest malejące względem wpisów macierzy, ponieważ \(\nu_1\) jest maksimum po rosnących ścieżkach. Generująca funkcja rozkładu \(C\) pod warunkiem \(E\) jest proporcjonalna do
\[
 \sum_{\nu\subseteq(r^n)}s_\nu(B)s_\nu((|y_j|z_j)_j).
\]
Wartość przy \(z_j=\exp(i\arg y_j)\) po normalizacji daje iloraz sumy w (1) i tej samej sumy z \(|Y|\) oraz wynosi \(\mathbb E[e^{i\Theta}\mid E]\), gdzie \(\Theta=\sum_j C_j\arg y_j\). Mianownik ilorazu jest co najmniej 1. Każda para \((a,b)\) daje składnik \(\theta(C_a-C_b)\), gdzie \(\theta=\arg y_a=-\arg y_b\). Funkcja rozkładu jest symetryczna w \(z_a,z_b\), więc wyrazy mieszane pomiędzy parami po podniesieniu \(\Theta\) do kwadratu znikają.

### Oszacowanie pojedynczej pary

Dla ustalonej pary podstawmy w generującej funkcji \(z_j=1\) poza parą. Reguła rozwinięcia Schura względem dwóch alfabetów daje sumę wielomianów \(s_{(a',b')}(z_a,z_b)\) z nieujemnymi współczynnikami. Istotnie, rozwijamy każdy \(s_\nu\) według podziału na parę i pozostałe zmienne, a współczynniki są nieujemnymi wartościami \(s_{\nu/(a',b')}\) na pozostałych modułach przemnożonymi przez dodatnie potęgi wspólnego modułu pary. Zatem warunkowy rozkład \((C_a,C_b)\) jest mieszaniną znormalizowanych wag tych wielomianów. Dla \(d=a'-b'\) monomy \(s_{(a',b')}(z_a,z_b)\) mają współczynniki 1. Rozkład różnicy wykładników jest jednostajny na \(-d,-d+2,\ldots,d\). Jego drugi moment to \(d(d+2)/3\), a suma wykładników jest równa \(a'+b'\ge d\). Stąd
\[
 \mathbb E[(C_a-C_b)^2\mid E]
 \le \frac{\mathbb E[(C_a+C_b)^2+2(C_a+C_b)\mid E]}3
 \le \frac{\mathbb E[(C_a+C_b)^2+2(C_a+C_b)]}3.
 \tag{2}
\]
Druga nierówność wynika z ujemnej kowariancji rosnącej funkcji wpisów i wskaźnika malejącego zdarzenia pod miarą produktową.

Niech \(\gamma_n\le U<T\) oraz \(A=\sum_{i=1}^n\gamma_i^2\), \(\alpha=(U/T)^2\). Dla pary na wysokości \(\gamma>T\), o którejś części rzeczywistej \(\beta\), mamy
\[
 q_{ij}\le\gamma_i^2/\gamma^2\le\alpha,\qquad
 |\theta|\le 2|\beta-\tfrac12|/\gamma.
\]
Sumując średnie i wariancje geometrycznych w dwóch kolumnach, otrzymujemy dla \(Z=C_a+C_b\)
\[
 \mathbb EZ\le\frac{2A}{\gamma^2(1-\alpha)},\qquad
 \operatorname{Var}Z\le\frac{2A}{\gamma^2(1-\alpha)^2}.
\]
Niech \(W_k=\sum_{\gamma>T}(2|\beta-\tfrac12|)^2\gamma^{-k}\), z krotnościami. Łącząc (2) z \(\cos t\ge1-t^2/2\) i licząc dwa zera w każdej parze, dostajemy
\[
 \mathbb E[\cos\Theta\mid E]
 \ge 1-\frac{A^2W_6+\tfrac32 A W_4}{3(1-\alpha)^2}.
 \tag{3}
\]
Po pomnożeniu przez mianownik ilorazu i \(a_0^rP^r\) dodatni margines obowiązuje także dla \(F\), dzięki zbieżności współczynników z iloczynu Hadamarda.

### Arytmetyka ogona

Oznaczmy przez \(N(v)\) liczbę zer z \(0<\gamma\le v\) i połóżmy
\[
 H(v)=\frac{v}{2\pi}\left(\log\frac{v}{2\pi}-1\right)+\frac78 .
\]
Dla \(v\ge14\) zapisane przez Dusarta jawne oszacowanie implikuje \(|N(v)-H(v)|\le 2\log v\). Dla \(L=\log T\) i \(k>1\) po całkowaniu przez części mamy
\[
 S_k:=\sum_{\gamma>T}\gamma^{-k}\le
 \frac{\log(T/(2\pi))+1/(k-1)}{2\pi(k-1)T^{k-1}}
 +\frac{4L+2/k}{T^k}.
 \tag{4}
\]
Ten sam wzór działa po zastąpieniu \(T\) przez dowolne \(v\ge14\).

W progach \(\sigma=0.85,0.90\) tabela 1 Kadiri, Lumley i Nga daje \(N(\sigma,v)\le c_\sigma(\log v)^b v^a+d_\sigma(\log v)^2\) dla \(v\ge T\), gdzie \(N(\sigma,v)\) liczy zera o \(\Re\rho>\sigma\) oraz \(a=8(1-\sigma)/3\), \(b=5-2\sigma\). Bierzemy stałe zaokrąglone w górę \((c_\sigma,d_\sigma)=(8.98,3.59),(11.50,3.19)\). Przy \(v\ge T\) używamy \(\log v\le L(v/T)^{1/L}\). Po pominięciu ujemnego składnika brzegowego w całkowaniu przez części dostajemy
\[
 R_{k,\sigma}:=\sum_{\substack{\gamma>T\\ \beta>\sigma\ {\rm lub}\ \beta<1-\sigma}}\gamma^{-k}
 \le 2k\left[\frac{c_\sigma L^bT^{a-k}}{k-a-b/L}
               +\frac{d_\sigma L^2T^{-k}}{k-2/L}\right].
 \tag{5}
\]
Czynnik 2 pochodzi z symetrii względem prostej krytycznej. Z obwiedni schodkowej dla \((2|\beta-\tfrac12|)^2\) wynika
\[
 W_k\le0.49 S_k+0.15 R_{k,0.85}+0.36 R_{k,0.90}.
\]
Stąd \(W_4<2.66\cdot10^{-38}\), \(W_6<1.77\cdot10^{-63}\). Przy \(U=32\,400\,000\,000\), z \(H(U)-50>110\,000\,000\,000\) i \(2\log U<50\) wynika \(\gamma_n\le U\) w deklarowanym zakresie. Całkowanie przez części na \((14,U]\), gdzie nie ma zer poniżej 14, daje
\[
 A\le \sum_{\gamma\le U}\gamma^2
 \le \frac{U^3}{6\pi}\left(\log\frac U{2\pi}-\frac13\right)+100U^2+1000
 <3.98\cdot10^{31}.
\]
Składniki \(100U^2+1000\) pokrywają błędy zastąpienia \(N\) przez \(H\) i dolną granicę całkowania. W (3) odejmowany składnik jest mniejszy niż \(0.936\). Nierówności liczbowe sprawdzono arytmetyką przedziałową przy 60 cyfrach precyzji.

## 2. Znacznie większe \(n\) przy dostatecznie dużym \(r\)

Dla każdego \(n\), dla którego \(\gamma_{n+1}\le T\), połóżmy
\[
 q=\left(\frac{\gamma_n}{\gamma_{n+1}}\right)^2,\qquad
 M=\left(\sum_{i=1}^n\gamma_i^2\right)\sum_{\gamma>\gamma_n}\gamma^{-2}.
\]
Wtedy dodatniość zachodzi, jeżeli
\[
 \boxed{r+1>\frac{12M}{(1-q)^2}.}
 \tag{6}
\]
Do wyznaczenia jawnego progu wystarczą \(\gamma_n,\gamma_{n+1}\), bo w \(M\) pierwszy czynnik można zastąpić \(n\gamma_n^2\), a drugi oszacować z (4) przy \(T=\gamma_n\) i \(k=2\).

Istotnie, pełna suma Cauchy’ego po wszystkich partycjach o co najwyżej \(n\) wierszach wynosi \(L_Y=\prod_{i,j}(1-B_i y_j)^{-1}>0\), bo czynniki są dodatnie rzeczywiste lub sprzężone i moduły \(B_i|y_j|\) są mniejsze od 1. W (1) brakuje partycji o \(\nu_1>r\), czyli \(|\nu|\ge r+1\). Dla dowolnego \(u>1\) z \(uq<1\) dodatniość współczynników Schura i jednorodność dają błąd modułu co najwyżej
\[
 u^{-(r+1)}\prod_{i,j}(1-uB_i|y_j|)^{-1}.
\]
Po podzieleniu przez \(L_Y\) logarytm względnej granicy błędu jest co najwyżej
\[
 -(r+1)\log u+\sum_{i,j}\log\frac{1+q_{ij}}{1-uq_{ij}},
 \qquad q_{ij}=B_i |y_j|\le q,\quad \sum_{i,j}q_{ij}\le M.
\]
Bierzemy \(u=1+(1-q)/2\), więc \(\log u\ge(1-q)/3\), \(1-uq\ge(1-q)/2\), \(u\le3/2\). Z \(\log(1+x)\le x\), \(-\log(1-x)\le x/(1-x)\) suma logarytmów jest najwyżej \(4M/(1-q)\). Warunek (6) czyni błąd względny mniejszym niż 1. Argument działa dla całego nieskończonego iloczynu ze względu na \(\sum_{i,j}q_{ij}<\infty\). Liczenie zer daje \(H(T)-2\log T>12\,360\,000\,000\,001\), zatem warunek na \(\gamma_{n+1}\) zachodzi w całym podanym zakresie \(n\).

## 3. Dowolne \(n\) do określonego rzędu \(r\)

Zera położone na prostej dają czynniki \(1+xz\), \(x>0\). Dla pary poza prostą przy \(\gamma>T\) czynniki mają postać \(1+2|x|\cos\theta\,z+|x|^2z^2\), \(\theta=\arg x\). Z jawnego obszaru bezzerowego Mossinghoffa, Trudgiana i Yanga oraz symetrii mamy
\[
 |\theta|\le \frac{1-2/(5.558691\log\gamma)}{\gamma}
 \le \frac{1-2/(5.558691\log T)}{T}.
\]
Ostatnia nierówność wynika z ujemnej pochodnej prawej strony jako funkcji wysokości \(\gamma\ge T\). Dla \(r\le9\,540\,000\,000\,000\) arytmetyka przedziałowa daje \((r+1)|\theta|<\pi\). Z kryterium sektorowego Schoenberga każdy czynnik ma wszystkie minory Toeplitza do rozmiaru \(r\) nieujemne. Iloczyn tych czynników zachowuje tę własność przez Cauchy’ego–Bineta i przejście do granicy współczynników. Formułę Cauchy’ego–Bineta dla półnieskończonej macierzy stosujemy po ograniczeniu do skończonego początkowego bloku zawierającego wszystkie użyte indeksy, ponieważ macierze Toeplitza są trójkątne.

Ścisła dodatniość \(D(n,r)\) wynika przez wydzielenie iloczynu \(n\) czynników odpowiadających zerom na prostej. Istnieje ich nieskończenie wiele z twierdzenia Hardy’ego. Dla wydzielonego iloczynu żądany minor jest dodatni, ponieważ \(s_{(r^n)}(x_1,\ldots,x_n)=(x_1\cdots x_n)^r>0\). W Cauchym–Binecie jego iloczyn z głównym minorem macierzy pozostałego czynnika (równym 1) jest składnikiem dodatnim. Dla \(n=0\) mamy \(D(0,r)=a_0^r>0\) bez wydzielania czynników.

## Zakres wniosku

Uzyskane kryterium dla dużych \(r\) ma próg zależny od odstępu \(\gamma_{n+1}-\gamma_n\). W kombinacji z kryterium sektorowym pozostają pary \(n,r\), których żadne z oszacowań nie rozstrzyga. W szczególności wynik jednocześnie dla nieograniczonych \(n,r\) pociągałby hipotezę Riemanna przez determinantalne kryterium Nuttalla. Dowód ma charakter analityczny z przedziałową kontrolą stałych. Nie wykonano formalizacji w Lean ani oceny pierwszeństwa.

## Źródła

- J. Nuttall, [Determinantal Inequalities and the Riemann Hypothesis](https://publish.uwo.ca/~jnuttall/DET3.pdf), §1.2.
- D. Platt i T. Trudgian, [The Riemann hypothesis is true up to \(3\cdot10^{12}\)](https://doi.org/10.1112/blms.12460).
- P. Dusart, [Improved explicit bounds for some functions of prime numbers](https://doi.org/10.7169/facm/1547), wzór (3).
- H. Kadiri, A. Lumley i N. Ng, [Explicit zero density for the Riemann zeta function](https://doi.org/10.1016/j.jmaa.2018.04.071), tabela 1 i wzór (4.71).
- M. Mossinghoff, T. Trudgian i A. Yang, [Explicit zero-free regions for the Riemann zeta-function](https://doi.org/10.1007/s40993-023-00498-y).
- K. Johansson, [Shape Fluctuations and Random Matrices](https://sites.math.northwestern.edu/~auffing/papers/J2000.pdf), §2.1.
- A. Khare, [Pólya frequency sequences and their generating functions](https://math.iisc.ac.in/~khare/teaching/Math341-notes.pdf), twierdzenie 30.27.
