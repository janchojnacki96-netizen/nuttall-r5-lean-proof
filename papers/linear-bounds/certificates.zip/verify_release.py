"""Quick release audit. For regenerated moments and cell bounds use the full runs in the paper."""
import csv
import re
from decimal import Decimal
import subprocess
import sys
from fractions import Fraction
from pathlib import Path
from mpmath import iv

base = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError("Use standard Python without -O")
iv.dps=50
r=iv.mpf(10)**11
m=2*r
B=iv.ln(4*m*iv.ln(192*m))/4
a=iv.ln(2)/2
E=B*(1/r+iv.sqrt(iv.pi/r))
for b,K,cap in [(iv.mpf(4),2,'0.732'),(B,2980,'0.982')]:
    P=4*(b/a)**2*iv.exp(b/2)/iv.sqrt(r-1)
    Q=24*iv.sqrt(2*b)*iv.exp(b)/iv.sqrt(r-1)
    D=2*m*iv.exp(b-a*iv.sqrt(r-1)/(16*b))
    value=E+(1+E)*(1/iv.sqrt(K)+P+Q+D)
    assert value < iv.mpf(cap)
    print('Large-r starting bound',value,'<',cap)
assert 40000*iv.exp(-625*iv.pi/3)<iv.mpf(2)**(-900)
assert 2*6912*iv.exp(-15)<1
cursor=Fraction(0)
caps=[]
with (base/'small/cells.csv').open() as f:
    for cell in csv.DictReader(f):
        lo,hi=Fraction(cell['t_from']),Fraction(cell['t_to'])
        cap=int(cell['norm_upper_times_1e9'])
        assert lo==cursor and hi>lo and cell['rank']=='7' and 0<=cap<10**9
        cursor=hi
        caps.append(cap)
assert cursor==Fraction(1,2) and len(caps)==67 and max(caps)==801559662
print('Orders 5--7: exact coverage and maximum confirmed.')
replay4 = subprocess.run([sys.executable, str(base/'small/check_phi4.py')],
                         check=True, stdout=subprocess.PIPE, text=True)
assert replay4.stdout.splitlines() == (base/'small/phi4_cells.csv').read_text().splitlines()
rows4 = list(csv.DictReader(replay4.stdout.splitlines()))
assert len(rows4) == 64 and max(int(row['upper_bound_times_1e9']) for row in rows4) == 637776742
print('Unintegrated kernel: all 64 rank-four cells regenerated and compared.')
assert 7*iv.log(iv.mpf(40)/9) < 15
replay8 = subprocess.run([sys.executable, str(base/'small/check_order8.py')],
                         check=True, capture_output=True, text=True)
assert replay8.stdout.splitlines() == (base/'small/order8.csv').read_text().splitlines()
assert replay8.stderr.splitlines() == (base/'small/order8.log').read_text().splitlines()
rows8 = list(csv.DictReader(replay8.stdout.splitlines()))
assert len(rows8) == 86 and max(int(row['upper_bound_times_1e9']) for row in rows8) == 823252099
print('Order eight: regenerated the negative determinant and all 86 cells of the second integral.')
subprocess.run([sys.executable,str(base/'historical32/compare.py')],check=True)
subprocess.run([sys.executable,str(base/'rank500/sprawdz_wyniki.py')],check=True)
subprocess.run([sys.executable, str(base/'rank500/check_witness.py'),
                '--log', str(base/'rank500/fresh_witness.log')], check=True)
subprocess.run([sys.executable, str(base/'rank500/check_witness.py'), '--rank', '142',
                '--log', str(base/'rank500/fresh142.log')], check=True)
subprocess.run([sys.executable, str(base/'determinants/check_constants.py')], check=True)

def check_archived_blocks(lines):
    """Validate accepted ranges, run modes and maxima in the archived transcript."""
    expected_jobs = [
        ('layers-1', 33, 649), ('layers-0', 650, 1449),
        ('large', 1450, 10**11-1),
        ('schur', 33, 100), ('schur', 101, 220),
        ('schur', 221, 400), ('schur', 401, 649),
    ]
    it = iter(lines)
    for header in ('t_0_do_1_16.csv 459 OK', 't_1_16_do_1_4.csv 1845 OK',
                   'certyfikat_X.csv 8615 OK'):
        assert next(it) == header
    for mode, start, end in expected_jobs:
        cursor, maximum, first_k = start, Decimal(0), 2
        for line in it:
            if line.startswith('PASS. Maximum upper bound '):
                assert cursor == end+1 and Decimal(line.split()[-1]) == maximum
                break
            fields = line.split()
            if fields[0] == 'FAIL':
                # A rejected trial block contributes no ranks to the cover.
                assert mode == 'schur' and int(fields[1]) == cursor
                continue
            lo, hi = map(int, fields[:2])
            assert lo == cursor and lo <= hi <= end, (mode, cursor, line)
            if mode.startswith('layers-'):
                assert len(fields) == 5 and fields[2:4] == [mode[-1], '0']
                score = Decimal(fields[4])
            elif mode == 'schur':
                assert len(fields) == 4 and fields[2] == 'Schur'
                score = Decimal(fields[3])
            elif lo < 10**7:
                match = re.fullmatch(
                    r'\d+ \d+ B [\d.]+ od K (\d+) kolejne K (\d+) upper ([\d.]+) at \(\d+, \d+\)', line)
                assert match and int(match[1]) == first_k
                next_k = int(match[2])
                assert next_k >= first_k
                first_k, score = next_k, Decimal(match[3])
            else:
                assert len(fields) == 5 and fields[2] == 'analytic'
                score = Decimal(fields[4])
            assert 0 <= score < 1
            maximum = max(maximum, score)
            cursor = hi+1
        else:
            raise ValueError(f'Missing summary for {mode} at {start}')
        print(f'Archived {mode} cover {start}..{end}, maximum {maximum}')
    assert list(it) == ['Wszystkie nowe zakresy przeszły. Tabele r<=32 pokrywają swoje przedziały.']


check_archived_blocks((base/'upper/fresh_replay.log').read_text().splitlines())
print('PASS: recomputed scalar inequalities; regenerated order-four and order-eight cells; verified stored cell tables, both witness transcripts, '
      'and all seven archived rank covers. Full regeneration uses the commands in Appendix B.')
