#define NUTTALL_NO_SCAN_MAIN
#include "scan.cpp"
// Independent forward transport from interval moments at zero on a fine mesh.
int main(int argc,char**argv){
    if(argc!=11){std::cerr<<"near r lo hi grid_d nc_k bits last cache_file cache_negative cache_bits\n";return 2;}
    int r=atoi(argv[1]),lo=atoi(argv[2]),hi=atoi(argv[3]),d=atoi(argv[4]),k=atoi(argv[5]),bits=atoi(argv[6]),last=atoi(argv[7]),n0=atoi(argv[9]),cbits=atoi(argv[10]);
    precision=bits+128;int L=256,neg=2*r-1-lo;
    FILE *f=fopen(argv[8],"rb");if(!f)return 2;
    Vec b(hi);for(int j=-n0;j<hi;++j){Z x,y;if(!mpz_inp_raw(x.get_mpz_t(),f)||!mpz_inp_raw(y.get_mpz_t(),f))return 3;if(j>=0)b[j]=value(x,-cbits-512);}fclose(f);
    auto poly=derivative_polys(std::max(0,neg-1));auto w=weights(k);
    Vec coef(hi),scoef(hi);coef[0]=scoef[0]=value(1);
    Real lh=value(L,-d);
    for(int s=1;s<hi;s++){coef[s]=quot(times(coef[s-1],lh),value(s));scoef[s]=coef[s];if(s%2)mpfr_neg(scoef[s].v,scoef[s].v,near);}
    std::vector<Vec> panels(last),samples(last+1);samples[0]=b;
    #pragma omp parallel for schedule(dynamic)
    for(int j=0;j<last;j++)local(j,d,k,hi,bits,w,panels[j]);
    for(int j=0;j<last;j++){
        Vec next(hi);for(int s=0;s<hi;s++)b[s]=diff(b[s],times(coef[s],panels[j][s]));
        #pragma omp parallel for schedule(static)
        for(int s=0;s<hi;s++){Real y,z;for(int i=0;i<=s;++i){mpfr_mul(z.v,scoef[i].v,b[s-i].v,near);mpfr_add(y.v,y.v,z.v,near);}next[s]=y;}
        b.swap(next);samples[j+1]=b;
    }
    #pragma omp parallel for schedule(dynamic)
    for(int j=0;j<=last;j++){
        const double t=std::ldexp(double(j),-d);Vec v(hi+neg);
        auto der=derivatives(t,neg-1,L,bits,poly);
        for(int i=0;i<neg;i++)v[neg-1-i]=der[i];
        for(int i=0;i<hi;i++)v[i+neg]=samples[j][i];
        std::string line=std::to_string(j);
        if(j>0){auto z=batch(lo,hi,r,v,-neg);for(int p:z)line+=" "+std::to_string(p);}
        else for(int m=lo;m<=hi;++m)line+=" "+std::to_string(first_fail(m,r,v,-neg));
        #pragma omp critical
        {std::cout<<line<<std::endl;}
    }
}
