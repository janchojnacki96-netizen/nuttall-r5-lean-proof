#!/bin/sh
set -eu
for target in scan near certificate
do
    binary=$target
    if [ "$target" = certificate ]; then binary=certify; fi
    g++ -O3 -std=c++17 -fopenmp "$target.cpp" -o "$binary" -lgmpxx -lgmp -l:libmpfr.so.6
done
