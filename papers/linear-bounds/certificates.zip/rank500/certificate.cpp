#define NUTTALL_NO_SCAN_MAIN
#include "scan.cpp"
static Ball dotpos(const Ball&a,const Ball&b){ // b is nonnegative
    Ball t;mpfr_mul(t.lo.v,a.lo.v,mpfr_cmp_ui(a.lo.v,0)<0?b.hi.v:b.lo.v,down);
    mpfr_mul(t.hi.v,a.hi.v,mpfr_cmp_ui(a.hi.v,0)<0?b.lo.v:b.hi.v,up);return t;
}
static Ball sym(const Real&r){Ball v;v.hi=r;mpfr_neg(v.lo.v,r.v,near);return v;}
static std::vector<Ball> negative(const Ball&t,int K,int L,int bits){
    auto polys=derivative_polys(K);
    std::vector<Ball> z(K+1);
    Ball eu=expB(t),x=mul(pi(),expB(scale(t,4)));
    const unsigned long V=16UL*(bits+100+(K+1)*(bitlog(8UL*(K+1))+2));
    std::vector<Ball> raw(K+3);
    for(int n=1;;++n){
        Ball y=scale(x,n*n);if(mpfr_cmp_ui(y.lo.v,V)>0)break;
        Ball term=mul(eu,expNeg(y));
        for(int j=0;j<=K+2;++j){raw[j]=add(raw[j],term);term=mul(term,y);}
    }
    for(int k=0;k<=K;++k){
        if(mpfr_cmp_ui(t.hi.v,0)==0 && k%2)continue;
        for(int j=0;j<(int)polys[k].size();++j)
            z[k]=add(z[k],dotpos(dyadic(polys[k][j],0),raw[j]));
        z[k]=shift(z[k],-long(bitlog(L))*(k+1));
    }
    const Ball e=sym(shift(constant(1),-bits).hi);
    for(int k=0;k<=K;++k)
        if(!(mpfr_cmp_ui(t.hi.v,0)==0 && k%2))z[k]=add(z[k],e);
    return z;
}
static std::vector<Ball> positive(int M,int N,int L,int bits,int J,int den){
    if(!J){
        int R=(M+2)/2;
        auto m=moments(R,N,L,bits);Ball e=sym(radius(N,L,bits).hi);
        std::vector<Ball> vals;
        for(int i=0;i<M;++i)vals.push_back(add(dyadic(m[i],-bits),e));
        return vals;
    }
    // Period 12, centred at zero, full (not parity-reduced) interpolation on [-6,6].
    // Nodes for shifted theta lie on the same uniform grid.
    if((long)J*N%(12*den)!=0)throw std::runtime_error("t must be a mesh point");
    const long centre=(long)J*N/(12*den); const int threads=omp_get_max_threads();
    auto w=odd_weights(N,bits); std::vector<Z> masses(N/2+centre+1); auto pib=pi();
    #pragma omp parallel for schedule(dynamic,16)
    for(long i=0;i<(long)masses.size();++i){
        Ball u=shift(constant(i*12),-bitlog(N));
        Ball eu=expB(u),x=mul(pib,expB(scale(u,4)));
        // Phi(x) is even, and once x_phys>=3.5 the dyadic bin is zero for bits<=16000.
        if(2*i*12>=7*N)continue;
        Ball mass=shift(scale(theta(eu,x,bits),12),-bitlog(N));
        masses[i]=fixed(mass.lo,bits);
        if(fixed(mass.hi,bits)+1-masses[i]>1024)std::abort();
    }
    std::vector<std::vector<Z>> accum(threads,std::vector<Z>(M));
    const Z one=Z(1)<<bits;const unsigned long base=N/(4*L);
    if(N%(4*L)!=0)std::abort();
    #pragma omp parallel for schedule(dynamic,16)
    for(int j=0;j<N/2;j++){
        const Z &pos=masses[centre+j],&neg=masses[std::abs(centre-j)];
        auto &v=accum[omp_get_thread_num()];
        if(!j){v[0]+=pos>>1;continue;}
        // Integration over the positive half-period: weights (1+w)/2 and (1-w)/2.
        Z plus=(pos*(one+w[j]))>>(bits+1), minus=(neg*(one-w[j]))>>(bits+1);
        unsigned long num=3UL*j,nn=num*num;
        Z e=plus+minus,o=(plus-minus)*num/base;
        for(unsigned long k=0;k<(unsigned)M;k+=2){
            v[k]+=e;if(k+1<(unsigned)M)v[k+1]+=o;
            mpz_mul_ui(e.get_mpz_t(),e.get_mpz_t(),nn);
            mpz_fdiv_q_ui(e.get_mpz_t(),e.get_mpz_t(),base*base*(k+1)*(k+2));
            mpz_mul_ui(o.get_mpz_t(),o.get_mpz_t(),nn);
            mpz_fdiv_q_ui(o.get_mpz_t(),o.get_mpz_t(),base*base*(k+2)*(k+3));
        }
    }
    // Common error for all moments; see report.
    Ball g=expB(shift(constant(25*L),-2));
    Ball alias=scale(expNeg(divide(scale(pib,N),constant(48))),1000000000UL);
    Ball e=sym(mul(g,add(add(alias,scale(expNeg(constant(60000)),1000000000UL)),
                        shift(constant(1),-bits+12*long(bitlog(N))+40))).hi);
    std::vector<Ball> vals;
    for(int j=0;j<M;++j){Z v=0;for(auto &a:accum)v+=a[j];vals.push_back(add(dyadic(v,-bits),e));}
    return vals;
}
#include "residual.inc"
int main(int argc,char**argv){
    if(argc!=9)return 2;
    int r=atoi(argv[1]),lo=atoi(argv[2]),hi=atoi(argv[3]),J=atoi(argv[4]),den=atoi(argv[5]),N=atoi(argv[6]),L=atoi(argv[7]),bits=atoi(argv[8]);
    if(r>500||r<2||lo<1||hi>1000||hi<lo||J<0||J>2*den||den<1||bits>16000||bits<1024||L<1||L>1024||(L&(L-1))||N<1024||N>(1<<20)||(N&(N-1))||N%(4*L))return 2;
    precision=bits+128;std::cout<<"r="<<r<<" m="<<lo<<".."<<hi<<" t="<<J<<"/"<<den<<" N="<<N<<" L="<<L<<" bits="<<bits<<std::endl;
    int neg=std::max(0,2*r-1-lo);std::vector<Ball> v;
    const int baseM=std::min(1000,std::max(hi,2*r)),baseNeg=std::max(neg,std::min(r,300));
    std::string name="cache_"+std::to_string(r)+"_"+std::to_string(J)+"_"+std::to_string(den)+"_"+std::to_string(N)+"_"+std::to_string(L)+"_"+std::to_string(bits)+"_"+std::to_string(baseM)+"_"+std::to_string(baseNeg);
    const long f=bits+512;FILE *fd=fopen(name.c_str(),"rb");
    if(fd){
        for(int j=-baseNeg;j<baseM;++j){Z x,y;if(!mpz_inp_raw(x.get_mpz_t(),fd)||!mpz_inp_raw(y.get_mpz_t(),fd))std::abort();
            Ball z;z.lo=dyadic(x,-f).lo;z.hi=dyadic(y,-f).hi;v.push_back(z);}
        fclose(fd);
    }else{
        auto pos=positive(baseM,N,L,bits,J,den);Ball t=divide(constant(J),constant(den));
        if(baseNeg){auto a=negative(t,baseNeg-1,L,bits);v.insert(v.end(),a.rbegin(),a.rend());}
        v.insert(v.end(),pos.begin(),pos.end());
        fd=fopen((name+".tmp").c_str(),"wb");if(!fd)std::abort();
        for(auto &z:v){Z x=fixed(z.lo,f),y=fixed(z.hi,f)+1;mpz_out_raw(fd,x.get_mpz_t());mpz_out_raw(fd,y.get_mpz_t());}
        fclose(fd);std::rename((name+".tmp").c_str(),name.c_str());
    }
    neg=baseNeg;
    #pragma omp parallel for schedule(dynamic)
    for(int m=lo;m<=hi;++m){int q=residual(m,r,v,-neg,bits);
        #pragma omp critical
        {std::cout<<"m "<<m<<" result "<<q<<std::endl;}
    }
}
