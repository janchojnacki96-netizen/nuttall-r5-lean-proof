# Pomiar minimalnej liczby całkowań dla rzędu 500

Dla pełnej sumy theta pomiar wskazuje **$m(500)=768$**. Dolna granica $m(500)\ge768$ ma niezależny od siatki dowód wspomagany komputerowo. Wynik $m(500)\le768$ na całej półosi pozostaje wnioskiem empirycznym: na początkowym zwartym odcinku sprawdzano dyskretne argumenty.

## Wyniki i zakres

W punkcie $t=15/8192=0.0018310546875$ wszystkie podpisane wrońskiany do rzędu 499 są dodatnie po 767 całkowaniach, a podpisany wrońskian rzędu 500 jest ściśle ujemny. Po 768 całkowaniach wszystkie 500 jest dodatnich w tym samym punkcie. Wszystkie znaki na poziomie 768 sprawdzono dodatkowo przedziałowo w $t=0$ i w $t=81/64$. Świadek przy 767 i trwałość regularności przez całkowanie wykluczają wszystkie poziomy do 767 włącznie. Nie wymaga to założenia RH ani globalnego $m(r)\le2r$.

Pomiar podstawowy obejmuje $t=j/512$, $0\le j\le679$, przy 7200 bitach przed dodatkowymi bitami ochronnymi, z niezależnym obliczeniem danych na gęstszych węzłach kwadratury. Dodatkowo sprawdzono $j/1024$, $0\le j\le40$ oraz $j/8192$, $0\le j\le48$, przez transport od certyfikowanych momentów w zerze. Na wszystkich tych siatkach na poziomie 768 sprawdzano wszystkie rzędy od 1 do 500. Obszar $t\ge\log(502/\pi)/4=1.26846755846\ldots$ obejmuje też dowód analityczny w dowod_ogona.md.

Przy teście kontrolnym dla $r=142$ niewłaściwy znak uzyskano na poziomie 196 w samym zerze. Poziom 197 przeszedł siatkę $j/128$, $0\le j\le126$, obejmującą początek analitycznie pokrytego ogona. Oba znaki krańcowe w zerze powtórzono ściśle przedziałowo. Ujemny znak w zerze i trwałość regularności przy całkowaniu dają m(142) ≥ 197. Z twierdzenia 4.1 wynika m(142) ≤ 284. Wartość 197 występuje w tabeli 2 Nuttalla. Jego wyniki są numeryczne. [Tabela Nuttalla](https://publish.uwo.ca/~jnuttall/wronskRH.pdf)

Wcześniejsze dopasowanie $2r-3.2r^{2/3}$ daje 798.4126 dla $r=500$. Przy empirycznej wartości 768 otrzymujemy $m/r=1.536$ i $(2r-m)/r^{2/3}=3.68277\ldots$. Sam świadek ujemny już dowodzi $m(500)/500\ge1.536$. Żaden z wyników dla skończonego rzędu nie wyznacza granicy $m(r)/r$.

## Obliczenia numeryczne

Pliki z siatek zawierają indeks punktu, potem wyniki kolejnych poziomów $m$ w porządku rosnącym. Zero oznacza wszystkie prawidłowe znaki. Liczba dodatnia wskazuje pierwszy rząd z innym wynikiem. Punkty zapisywano równolegle, dlatego kolejność wierszy jest dowolna. W obliczeniach przedziałowych kod ujemny jest zarezerwowany dla braku rozstrzygnięcia.

| Plik | Poziomy całkowania | Siatka |
|---|---|---|
| dense500.log | 766–771 | $j/512$ |
| fine500a.log | 730–810 | $j/1024$ |
| detail500.log | 764–775 | $j/8192$ |
| valid142.log | 195–198 | $j/128$ |

Dodatnie indeksy momentów obliczono z pełnego jądra, panel po panelu. Na każdym panelu użyto interpolacyjnej kwadratury Newtona–Cotesa; wagi powstają z dokładnych wielomianów wymiernych. Kod korzysta z dzielników dyadycznych i całkowitych sum z wagami o obu znakach. Momenty całej półosi są propagowane wstecz; dla kroku $h$ moment skalowany $b_s(t)=L^s\Psi_{s+1}(t)$ jest sumą lokalnej całki oraz $\sum_{i=0}^s (Lh)^i b_{s-i}(t+h)/i!$. W głównym pomiarze stosujemy $L=256$, 512 podprzedziałów kwadratury w panelu i obcięcie w $1330/512$. W dwóch zagęszczeniach przy zerze obliczenie przebiega w przeciwnym kierunku. Pochodne potrzebne przy ujemnych indeksach powstają z dokładnych współczynników wielomianów różniczkowania jądra. Znaki liczono kondensacją Desnanota–Jacobiego, a w zerze trójczłonową rekurencją dla Hankela, aby ominąć dokładnie zerowe pochodne nieparzyste.

W próbach rozpoznawczych z rzadszą kwadraturą uzyskiwano pozorne nieprawidłowe znaki przy większych $t$. Przy zwiększaniu dokładności te niepowodzenia się przesuwały; część wypadała na obszarze objętym dodatnim znakiem analitycznym. Wykluczono je z pomiaru. Kontrolę niezależną od błędu kwadratury Newtona–Cotesa wykonano w punktach wybranych przez osobny algorytm Fouriera, z przedziałowymi danymi wejściowymi i weryfikacją kongruencji na dokładnych liczbach całkowitych (certyfikacja.md).

Po kompilacji polecenia `python check_witness.py --rank 142` i `python check_witness.py --rank 500` sprawdzają odpowiednie pary poziomów. Skrypt tworzy tymczasowy pusty katalog na dane momentowe i zwraca błąd przy wyniku nierozstrzygniętym lub niezgodnym z twierdzeniem.

## Odtworzenie

Potrzebne są GNU/Linux LP64, C++17, OpenMP, GMP z GMPXX oraz MPFR 4. Plik build.sh buduje trzy programy. Polecenia poniżej uruchamia się w katalogu z rozpakowanymi plikami. Przy pierwszym wywołaniu program certify zapisuje dane momentów w lokalnym pliku cache. Pakiet zawiera wyniki i źródła; cache można wytworzyć od nowa. Powtórzenie wszystkich gęstych siatek jest wolniejsze od ponownego sprawdzenia pojedynczego świadka.

~~~bash
sh build.sh
export OMP_NUM_THREADS=8
./certify 500 767 768 15 8192 131072 256 9000
./certify 500 768 768 0 1 65536 256 8500
./certify 500 768 768 81 64 131072 256 10000
./certify 142 196 197 0 1 32768 256 5000
./scan 500 766 771 9 512 7200 1330 679
./scan 142 195 198 7 512 3800 335 126
./near 500 730 810 10 512 5200 40 cache_500_0_1_65536_256_8500_1000_300 300 8500
./near 500 764 775 13 256 5000 48 cache_500_0_1_65536_256_8500_1000_300 300 8500
~~~

Przebiegi numeryczne wykorzystywały kolejne implementacje tego samego obliczenia. W końcowej wersji część splotów dyadycznych przyspieszono przez mnożenie wielkich liczb całkowitych, a sumowanie potęg theta przegrupowano. Bity ostatnich zaokrągleń mogą się różnić. Wiążący dla ścisłej dolnej granicy jest oddzielny wynik programu certify.
