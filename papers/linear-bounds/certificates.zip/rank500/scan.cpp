#include <iomanip>
#define NUTTALL_NO_ENDPOINT_MAIN
#include "endpoint.cpp"
// Numeric probes use the midpoint moments. Independent precision runs check stability.
extern "C" int mpfr_set_d(mpfr_ptr,double,mpfr_rnd_t);
using Vec=std::vector<Real>;
static Real value(const Z &z,long exponent=0){Real v;mpfr_set_z_2exp(v.v,z.get_mpz_t(),exponent,near);return v;}
static Real times(const Real&a,const Real&b){Real x;mpfr_mul(x.v,a.v,b.v,near);return x;}
static Real diff(const Real&a,const Real&b){Real x;mpfr_sub(x.v,a.v,b.v,near);return x;}
static Real quot(const Real&a,const Real&b){Real x;mpfr_div(x.v,a.v,b.v,near);return x;}
static std::vector<std::vector<Z>> derivative_polys(int K){
    std::vector<std::vector<Z>> polys={{0,-3,2}};
    for(int k=1;k<=K;k++){const auto &v=polys.back(); std::vector<Z>w(v.size()+1);
        for(size_t i=0;i<v.size();++i){w[i]-=(1+4*i)*v[i];w[i+1]+=4*v[i];}
        polys.push_back(std::move(w));
    }return polys;
}
static Vec derivatives(double t,int K,int L,int bits,const std::vector<std::vector<Z>>&poly){
    // (-1)^k Phi^(k)/L^(k+1); matches b_s=L^s Psi_(s+1) at s=-1-k
    Real u;
    mpfr_set_d(u.v,t,near);Real eu;mpfr_exp(eu.v,u.v,near);Real e2=times(eu,eu),X=times(pi().lo,times(e2,e2));
    Vec ret(K+1),raw(K+3);
    for(int n=1;;++n){
        Real z;mpfr_mul_ui(z.v,X.v,n*n,near);
        double zz=mpfr_get_d(z.v,near);
        if(zz>(bits+100)*0.7+(K+4)*std::log(20*(zz+K+4)))break;
        Real term;mpfr_neg(term.v,z.v,near);mpfr_exp(term.v,term.v,near);term=times(term,eu);
        for(int j=0;j<=K+2;++j){mpfr_add(raw[j].v,raw[j].v,term.v,near);mpfr_mul(term.v,term.v,z.v,near);}
    }
    for(int k=0;k<=K;++k){
        if(t==0&&(k&1))continue;
        for(int j=0;j<(int)poly[k].size();++j){Real c=value(poly[k][j]);
            mpfr_mul(c.v,c.v,raw[j].v,near);mpfr_add(ret[k].v,ret[k].v,c.v,near);}
        mpfr_mul_2si(ret[k].v,ret[k].v,-long(bitlog(L))*(k+1),near);
    }
    return ret;
}
// All sizes in one Hankel recursion at fixed integration level, with monic orthogonal polynomials.
static int first_fail(int m,int r,const Vec& vals,int first){
    Vec old(2*r+2),cur(2*r+2),next(2*r+2);
    for(int j=0;j<=2*r-2;++j)cur[j]=vals[m-1-j-first];
    Real subleading,prevnorm=value(1);
    for(int p=0;p<r;++p){
        if(!mpfr_number_p(cur[p].v))return -1;
        int cmp=mpfr_cmp_ui(cur[p].v,0);
        if((p%2==0&&cmp<=0)||(p%2==1&&cmp>=0))return p+1;
        if(p+1==r)break;
        Real alpha=quot(cur[p+1],cur[p]);mpfr_add(alpha.v,alpha.v,subleading.v,near);
        Real beta=quot(cur[p],prevnorm);
        subleading=diff(subleading,alpha);prevnorm=cur[p];
        for(int j=p+1;j<=2*r-3-p;++j){
            Real temp=times(alpha,cur[j]);mpfr_sub(next[j].v,cur[j+1].v,temp.v,near);
            if(p){mpfr_mul(temp.v,beta.v,old[j].v,near);mpfr_sub(next[j].v,next[j].v,temp.v,near);}
        }
        old.swap(cur);cur.swap(next);
    }return 0;
}
// Closed Newton-Cotes on k equal subintervals. Integer polynomial and common denominator.
static Vec weights(int k){
    std::vector<Z> v(k+2);v[0]=1;
    Z fact=1,lcm=1;
    for(int j=0;j<=k;++j){
        for(int a=j+1;a>=0;--a)v[a]=(a?v[a-1]:Z(0))-j*v[a];
        if(j)fact*=j;
        mpz_lcm_ui(lcm.get_mpz_t(),lcm.get_mpz_t(),j+1);
    }
    std::vector<Z> integral(k+1);Z pw=1;
    for(int i=0;i<=k;++i){integral[i]=(lcm/(i+1))*pw;pw*=k;}
    Vec w(k+1);Z denom=lcm*fact,choose=1;
    for(int j=0;j<=k/2;++j){
        Z h=1,sum=integral[k];for(int i=k-1;i>=0;--i){h=h*j+v[i+1];sum+=h*integral[i];}
        sum*=choose;if((k-j)%2)sum=-sum;
        w[j]=quot(value(sum),value(denom));w[k-j]=w[j];
        choose=choose*(k-j)/(j+1);
    }return w;
}
static void local(int j,int d,int k,int M,int bits,const Vec&w,Vec&out){
    // Panel [j/2^d,(j+1)/2^d]. Keep panel moments relative to exp(-X_left).
    const auto pib=pi();Ball left=shift(constant(j),-d);
    const Ball euLeft=expB(left);const Ball xLeft=mul(pib,expB(scale(left,4)));
    // Compute exp(-X_node+X_left) directly, then sum the exact theta prefactors.
    std::vector<Z> accum(M);const unsigned long logk=bitlog(k);
    Real eu=euLeft.lo,x=xLeft.lo,stepU=expB(shift(constant(1),-d-long(logk))).lo;
    Real stepX=times(stepU,stepU);stepX=times(stepX,stepX);Real inv=expB(xLeft).lo,three=value(3);
    for(int i=0;i<=k;++i){
        Real sum,qq=x;mpfr_neg(qq.v,qq.v,near);mpfr_exp(qq.v,qq.v,near);
        Real term=times(inv,qq),q2=times(qq,qq),step=times(q2,qq);
        const double xx=mpfr_get_d(x.v,near);
        for(int n=1;;++n){
            if((n*n-1)*xx>(bits+k+100)*0.70+64)break;
            Real y,z;mpfr_mul_ui(y.v,x.v,n*n,near);mpfr_mul_ui(z.v,y.v,2,near);
            mpfr_sub(z.v,z.v,three.v,near);mpfr_mul(z.v,z.v,y.v,near);
            mpfr_mul(z.v,z.v,term.v,near);mpfr_add(sum.v,sum.v,z.v,near);
            mpfr_mul(term.v,term.v,step.v,near);mpfr_mul(step.v,step.v,q2.v,near);
        }
        Real v=times(w[i],times(eu,sum));eu=times(eu,stepU);x=times(x,stepX); Z a=fixed(v,bits); accum[0]+=a;
        if(i)for(int s=1;s<M;++s){mpz_mul_ui(a.get_mpz_t(),a.get_mpz_t(),i);
            mpz_fdiv_q_2exp(a.get_mpz_t(),a.get_mpz_t(),logk);accum[s]+=a;}
    }
    Real scale0=xLeft.lo;mpfr_neg(scale0.v,scale0.v,near);mpfr_exp(scale0.v,scale0.v,near);
    mpfr_mul_2si(scale0.v,scale0.v,-d,near);
    out.resize(M);for(int s=0;s<M;++s)out[s]=times(scale0,value(accum[s],-bits));
}
// Ordered output for a whole band via Desnanot--Jacobi.
static std::vector<int> batch(int lo,int hi,int r,const Vec&vals,int first){
    std::vector<int> failures(hi-lo+1);
    Vec prev(vals.size()+2,value(1)),cur=vals,next(vals.size());
    for(int p=1;p<=r;++p){
        const int count=vals.size()-2*(p-1);
        for(int m=lo;m<=hi;++m){
            int j=m-2*p+1-first;
            if(!failures[m-lo] && (!mpfr_number_p(cur[j].v)||mpfr_cmp_ui(cur[j].v,0)<=0))
                failures[m-lo]=p;
        }
        if(p==r)break;
        Real a,b;
        for(int i=0;i<count-2;++i){
            mpfr_mul(a.v,cur[i+1].v,cur[i+1].v,near);
            mpfr_mul(b.v,cur[i].v,cur[i+2].v,near);
            mpfr_sub(a.v,a.v,b.v,near);
            mpfr_div(next[i].v,a.v,prev[i+2].v,near);
        }
        prev.swap(cur);cur.swap(next);
    }return failures;
}
#include "packing.h"
// Exact dyadic convolution, rounded back to MPFR after extraction.
static Vec convolution(const Vec&a,const Vec&b,int n,int bits){
    auto encode=[&](const Vec&v,std::vector<Z>&z){
        long least=LONG_MAX;
        for(auto &x:v)if(mpfr_cmp_ui(x.v,0)!=0)least=std::min(least,mpfr_get_exp(x.v));
        if(least==LONG_MAX)return 0L;
        long f=bits+16-least;
        for(int i=0;i<n;++i)z[i]=fixed(v[i],f);
        return f;
    };
    std::vector<Z>x(n),y(n);long fx=encode(a,x),fy=encode(b,y);
    size_t bx=1,by=1;for(int i=0;i<n;i++){bx=std::max(bx,bitlen(x[i]));by=std::max(by,bitlen(y[i]));}
    size_t stride=(bx+by+bitlog(n)+4+63)/64;
    Z prod=pack(x,stride)*pack(y,stride);
    size_t width=64*stride;
    mpz_fdiv_r_2exp(prod.get_mpz_t(),prod.get_mpz_t(),n*width);
    const Z half=Z(1)<<(width-1);std::vector<Z>bias(n,half);
    prod+=pack(bias,stride);mpz_fdiv_r_2exp(prod.get_mpz_t(),prod.get_mpz_t(),n*width);
    std::vector<unsigned long> words(n*stride);size_t count;
    mpz_export(words.data(),&count,-1,sizeof(unsigned long),0,0,prod.get_mpz_t());
    Vec ans(n);for(int j=0;j<n;j++){Z v;mpz_import(v.get_mpz_t(),stride,-1,sizeof(unsigned long),0,0,words.data()+j*stride);
        ans[j]=value(v-half,-fx-fy);}
    return ans;
}
#ifndef NUTTALL_NO_SCAN_MAIN
int main(int argc,char**argv){
    if(argc!=9){std::cerr<<"scan r min_m max_m grid_d panel_k bits end_t_index last_sample_index\n";return 2;}
    const int r=atoi(argv[1]),lo=atoi(argv[2]),hi=atoi(argv[3]),d=atoi(argv[4]),k=atoi(argv[5]),bits=atoi(argv[6]),end=atoi(argv[7]),last=atoi(argv[8]);
    if((k&(k-1))||lo<0||lo>hi||end<=last)return 2;
    int L=256,neg=std::max(0,2*r-1-lo);
    precision=bits+128; auto polys=derivative_polys(std::max(0,neg-1));
    auto w=weights(k);Vec coef(hi);coef[0]=value(1);
    Real lh=value(L,-d);
    for(int s=1;s<hi;s++)coef[s]=quot(times(coef[s-1],lh),value(s));
    // Stage 1 parallel panels; stage 2 backward propagation then independent sign tests.
    std::vector<Vec> panels(end),samples(last+1);
    #pragma omp parallel for schedule(dynamic)
    for(int j=0;j<end;++j)local(j,d,k,hi,bits,w,panels[j]);
    std::cerr<<"panels calculated"<<std::endl;Vec b(hi);
    for(int j=end-1;j>=0;--j){
        Vec next=convolution(coef,b,hi,bits+128);
        for(int s=0;s<hi;s++){Real localTerm=times(panels[j][s],coef[s]);mpfr_add(next[s].v,next[s].v,localTerm.v,near);}
        b.swap(next);if(j<=last)samples[j]=b;
        if(j<=last && j%8==0 && std::getenv("ANCHORS")){
            std::string name=std::string(std::getenv("ANCHORS"))+"_"+std::to_string(j);
            FILE *fd=fopen(name.c_str(),"wb");if(!fd)std::abort();
            for(const auto &x:b){long scale=bits+150-mpfr_get_exp(x.v);Z z=fixed(x,scale);
                fwrite(&scale,sizeof(scale),1,fd);mpz_out_raw(fd,z.get_mpz_t());}fclose(fd);
        }
    }
    #pragma omp parallel for schedule(dynamic)
    for(int j=0;j<=last;++j){
        int stride=std::getenv("STRIDE")?std::atoi(std::getenv("STRIDE")):1;
        int dense=std::getenv("DENSE")?std::atoi(std::getenv("DENSE")):0;
        if(j>dense && j%stride && j!=last)continue;
        double t=std::ldexp(double(j),-d); Vec vals(neg+hi);
        if(neg){Vec der=derivatives(t,neg-1,L,bits,polys);for(int i=0;i<neg;++i)vals[neg-i-1]=der[i];}
        for(int s=0;s<hi;++s)vals[neg+s]=samples[j][s];
        std::string line=std::to_string(j);
        if(j && !std::getenv("GRAM")){
            auto result=batch(lo,hi,r,vals,-neg);
            for(int failure:result)line+=" "+std::to_string(failure);
        }else{
            for(int m=lo;m<=hi;++m){int failure=first_fail(m,r,vals,-neg);line+=" "+std::to_string(failure);}
        }
        #pragma omp critical
        {std::cout<<line<<std::endl;}
    }
}

#endif
