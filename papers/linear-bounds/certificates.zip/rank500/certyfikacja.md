# Jak sprawdzono znaki w wybranych punktach

Niech $a_s=\Psi_{s+1}(t)$ dla $s\ge-1$ i $a_{-1-j}=(-1)^j\Phi^{(j)}(t)$. Wprowadzamy $b_s=L^s a_s$. Dla poziomu $m$ badamy jedną symetryczną macierz Hankela $H_{ij}=b_{m-1-i-j}$, $0\le i,j<r$. Znak jej początkowego minora rzędu $p$ jest znakiem $W_p$: usunięte czynniki to dodatnie skale przekątnych i jednoczesne przemnożenie wierszy oraz kolumn przez znaki $(-1)^i$. Właściwy znak to $(-1)^{p(p-1)/2}$.

## Przedziały dla danych

W zerze stosujemy kwadraturę Fouriera o okresie 6 z poprzedniego certyfikatu (wyprowadzenie w kwadratura_bazowa.md). Dla $t>0$ interpolujemy periodyzację $f_s(u)=\Phi(t+u)(Lu)^s/s!$ na okresie 12, wyśrodkowanym w zerze, i całkujemy interpolant na $[0,6]$. Jeżeli $w_j$ są nieparzystymi wagami z poprzedniej noty, to wagi dla dodatniego i ujemnego węzła to odpowiednio $(12/N)(1+w_j)/2$ i $(12/N)(1-w_j)/2$. Wynika to z rozłożenia na część parzystą i nieparzystą. Dla nieparzystego $s$ wartość potęgi na ujemnym węźle zmienia znak. Jądro jest parzyste, więc potrzebne są tylko dodatnie argumenty funkcji theta. W kodzie punkty certyfikowane wypadają na wymiernej siatce; do rachunku certyfikującego nie wchodzi przybliżenie dziesiętne $t$.

Dla $0\le t\le2$, $1\le L\le1024$ promień bezwzględny dla wszystkich $b_s$, $s\ge0$ użytych w rachunku, wynosi co najwyżej
\[
 e^{25L/4}\{10^9e^{-\pi N/48}+10^9e^{-60000}+2^{-P+12\log_2N+40}\}.
\]
Uzasadnienie: dla $|\Im u|\le 1/4$ nadal mamy $|\Phi(t+u)|\le10^4$; po obu stronach gdy $|\Re u|\ge6$, argument jądra ma moduł części rzeczywistej co najmniej 4. Obowiązuje więc dwustronna granica $1000e^y\exp[-\pi e^{4y}/8]$, $y=|t+\Re u|$. W połączeniu z $|(Lu)^s|/s!\le e^{L(|\Re u|+1/4)}$ daje to liniową normę całkową na brzegach pasa $\le10^6e^{25L/4}$. Częstość modu $k$ to $2\pi k/12$, stąd geometryczny ogon od $|k|\ge N/2$ daje pierwszy składnik (także po przemnożeniu przez długość 6 i granicę błędu aliasingu). Pominięty ogon i obrazy periodyczne są w drugim składniku. Punkty z $|t+u|\ge3.5$ pominięte w próbkach mają masę mniejszą od jednostki stałoprzecinkowej przy użytych $P\le 10000$; wynika to z tej samej granicy i $\pi e^{14}/8>470000$. Oszacowanie stałoprzecinkowej FFT i propagacji błędów z kwadratury bazowej stosuje się z $|Lu|\le6L$. Zmiana wag na $(1\pm w_j)/2$ i dodanie obu półosi wnosi co najwyżej stały czynnik, pokryty luźnym ograniczeniem $2^{12\log_2N+40}$. Dokładniej, na jednym węźle przed mnożeniem przez potęgi błąd jest mniejszy od $[4096(1+\log N)+(24/N)10^4\cdot40N^3+20]2^{-P}$, a suma czynników propagacji pojedynczych obcięć wynosi co najwyżej $e^{6L}$. Całkowity promień jest dodawany z zaokrągleniami na zewnątrz.

Dla niskich indeksów obliczamy pochodne bez numerycznego różniczkowania. Przy $y=\pi n^2e^{4t}$ piszemy $(-1)^j\phi_n^{(j)}(t)=e^te^{-y}P_j(y)$. Współczynniki $P_0(y)=2y^2-3y$ i $P_{j+1}=(4y-1)P_j-4yP_j'$ są obliczane w liczbach całkowitych. Najpierw sumujemy przedziały dla $e^{t-y}y^l$, potem wykonujemy kombinację z dokładnymi współczynnikami. Na kole promienia $1/8$ w zmiennej $t$ moduł pojedynczego składnika jest mniejszy od $5000e^{-y/4}$ dla rzeczywistych $0\le t\le2$, ponieważ $e^{-1/2}\cos(1/2)>1/2$. Z oszacowania Cauchy’ego wynika $5000 j!8^j e^{-y/4}$. Kolejne $y$ rosną co najmniej o $\pi$, więc dla najwyższej użytej pochodnej $K$ kod pomija składniki dopiero gdy $y>16[P+100+(K+1)(\lceil\log_2(8(K+1))\rceil+2)]$. Łączny moduł tego ogona jest mniejszy od $2^{-P}$ również po skalowaniu przez $L^{-j-1}$. W punkcie zero nieparzyste pochodne są dokładnie zerowe. Funkcje elementarne w części certyfikującej liczone są dwustronnie w MPFR. Zapisane lokalne pliki cache zawierają zaokrąglone na zewnątrz dyadyczne końce przedziałów.

## Sprawdzenie wyznaczników

Obliczenie przybliżone wykorzystuje moniczne wielomiany formalnie ortogonalne dla funkcjonału $\ell(x^j)=H_{0j}$, z naturalnym przedłużeniem do $j=2r-2$. Przy $F_i(j)=\ell(x^j P_i)$ i $h_i=F_i(i)$ stosujemy trójczłonową rekurencję: $P_{i+1}=(x-\alpha_i)P_i-\beta_iP_{i-1}$, $\beta_i=h_i/h_{i-1}$, $\alpha_i=F_i(i+1)/h_i+[x^{i-1}]P_i$. Rozpoczynamy od $P_0=1$. Potem każdy wiersz współczynników jest dodatnio skalowany potęgą dwójki w przybliżeniu o czynnik $1/\sqrt{|h_i|}$. Ta faza wybiera tylko macierz zmiany bazy. Błąd jej konstrukcji nie jest założeniem dowodu.

Do sprawdzenia bierzemy **dokładną całkowitą** dolnotrójkątną macierz $C$ otrzymaną przez zaokrąglenie tych wierszy na wspólną siatkę dyadyczną i usunięcie mianownika. Sprawdzamy dodatniość przekątnych $C$. Niech $B_j$ będą całkowitymi przybliżeniami momentów macierzy na wspólnej skali, z błędem co najwyżej $E$ w tych samych jednostkach. Liczymy dokładnie
\[
 F_{ij}=\sum_{k=0}^i C_{ik} B_{j+k},\quad 0\le j\le i;
 \qquad U=\max_i\sum_k|C_{ik}|,\quad R=\max_{j<i}|F_{ij}|.
\]
Użyte iloczyny wielomianowe są iloczynami dużych liczb całkowitych GMP. Odwracamy wiersz $C_i$ i odczytujemy współczynnik $i+j$ iloczynu. Rozstaw bitowy to suma maksymalnych długości współczynników obu czynników plus $\lceil\log_2 r\rceil+4$, zaokrąglona do pełnego słowa. Mieści on współczynniki iloczynu ze znakiem. Dodanie połowy podstawy w każdym polu pozwala odczytać znak bez niejednoznaczności przeniesień.

Dla $k<i$ wpis $(CHC^\top)_{ik}$ na skali $B$ ma moduł $\le UR+EU^2$. Wpis diagonalny różni się od $F_{ii}C_{ii}$ najwyżej o tę samą wartość. Jest to bezpośrednie rozwinięcie iloczynu z trójkątnością $C$ i nierównością trójkąta. W wymiarze $d$ certyfikat wymaga
\[
 \min_{i<d}|F_{ii}C_{ii}|>d(UR+EU^2).
\]
Wtedy wszystkie początkowe bloki zachowują znaki wyznaczników podczas odkształcania diagonalnej macierzy o wpisach $F_{ii}C_{ii}$ do rzeczywistego $CHC^\top$ (ścisła dominacja przekątniowa). Trójkątna kongruencja zachowuje znaki początkowych minorów. Sprawdzamy kolejno znaki $F_{ii}C_{ii}$ przeciw naprzemiennemu wzorcowi $(-1)^i$. Program zwraca 0, jeśli udowodniono cały wzorzec, dodatni rząd pierwszego niewłaściwego znaku, a liczbę ujemną przy braku rozstrzygnięcia. Żaden wynik nierozstrzygający nie jest traktowany jako dowód.

Z ujemnego podpisanego wrońskianu na poziomie 767 wynika wykluczenie także wszystkich mniejszych poziomów: właściwość $RR_r$ zachowuje się przy dalszym całkowaniu, a ujemny podpisany wrońskian przeczy nawet słabej regularności $RR_r$ przez zlewanie węzłów. Dla definicji ze ścisłymi wrońskianami analogiczną trwałość uzasadniono w dowodzie ogona.
