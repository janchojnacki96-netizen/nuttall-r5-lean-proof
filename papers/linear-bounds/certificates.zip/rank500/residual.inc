#include "packing.h"
// Exact integer products checked against the entire input moment boxes.
// Test all leading minors through the first wrong sign (or the requested order).
static int residual(int m,int r,const std::vector<Ball>&v,int first,int bits){
    const long f=bits+512;std::vector<Z> B(2*r-1);Z E=0;size_t bb=0;
    Vec old(2*r+1),cur(2*r+1),next(2*r+1),po(r+1),pc(r+1),pn(r+1);
    pc[0]=value(1);Real prev=value(1),c;
    for(int j=0;j<2*r-1;j++){
        const Ball &y=v[m-1-j-first];B[j]=fixed(y.lo,f);
        Z width=fixed(y.hi,f)+1-B[j];if(width>E)E=width;
        cur[j]=value(B[j],-f);bb=std::max(bb,bitlen(B[j]));
    }
    std::vector<std::vector<Z>> C;size_t cb=0;Z U=0;int result=0;
    for(int i=0;i<r;i++){
        if(!mpfr_number_p(cur[i].v)||mpfr_cmp_ui(cur[i].v,0)==0)return -i-1;
        const long e=mpfr_get_exp(cur[i].v);const long adjust=-(long)std::floor(e/2.);
        std::vector<Z> row(i+1);Z sum=0;
        for(int j=0;j<=i;j++){
            row[j]=fixed(pc[j],f+adjust);sum+=abs(row[j]);cb=std::max(cb,bitlen(row[j]));
        }
        if(row[i]<=0)return -i-1;
        U=std::max(U,sum);C.push_back(std::move(row));
        if((i%2==0)!=(mpfr_cmp_ui(cur[i].v,0)>0)){result=i+1;break;}
        if(i+1==r)break;
        Real q=quot(cur[i+1],cur[i]),a;mpfr_add(a.v,q.v,c.v,near);
        Real beta=quot(cur[i],prev);mpfr_neg(c.v,q.v,near);prev=cur[i];
        for(int j=0;j<=i+1;++j){
            pn[j]=j?pc[j-1]:Real();Real tmp;
            if(j<=i){tmp=times(a,pc[j]);mpfr_sub(pn[j].v,pn[j].v,tmp.v,near);}
            if(j<i){tmp=times(beta,po[j]);mpfr_sub(pn[j].v,pn[j].v,tmp.v,near);}
        }
        po.swap(pc);pc.swap(pn);
        for(int j=i+1;j<=2*r-3-i;++j){
            Real tmp=times(a,cur[j]);mpfr_sub(next[j].v,cur[j+1].v,tmp.v,near);
            if(i){mpfr_mul(tmp.v,beta.v,old[j].v,near);mpfr_sub(next[j].v,next[j].v,tmp.v,near);}
        }old.swap(cur);cur.swap(next);
    }
    const size_t stride=(bb+cb+bitlog(r)+4+63)/64;
    const Z half=Z(1)<<(64*stride-1), packedB=pack(B,stride);
    const size_t n=B.size()+C.size();std::vector<Z> offsets(n,half);
    const Z bias=pack(offsets,stride);
    Z D=0,R=0;
    for(size_t i=0;i<C.size();++i){
        Z z=bias+packedB*pack(C[i],stride,true);
        if(z<0)std::abort();
        std::vector<unsigned long> words(n*stride);size_t count;
        mpz_export(words.data(),&count,-1,sizeof(unsigned long),0,0,z.get_mpz_t());
        if(count>words.size())std::abort();
        for(size_t j=0;j<=i;++j){
            Z entry;mpz_import(entry.get_mpz_t(),stride,-1,sizeof(unsigned long),0,0,words.data()+(i+j)*stride);
            entry-=half;
            if(j<i){Z magnitude=abs(entry);R=std::max(R,magnitude);}
            else{Z diag=entry*C[i][i];
                const bool expected=(i%2==0) != (result==int(i+1));
                if(diag==0||((diag>0)!=expected))return -int(i+1);
                Z magnitude=abs(diag);if(!i||magnitude<D)D=magnitude;
            }
        }
    }
    if(D<=C.size()*(U*R+E*U*U))return -int(C.size());
    return result;
}
