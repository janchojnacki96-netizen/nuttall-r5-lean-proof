#include "mpfr_compat.h"
#include <gmpxx.h>
#include <omp.h>
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using Z=mpz_class;
static long precision;
static const auto near=MPFR_RNDN, down=MPFR_RNDD, up=MPFR_RNDU;
struct Real {
    mpfr_t v;
    Real(){mpfr_init2(v,precision);mpfr_set_ui(v,0,near);}
    Real(const Real &a):Real(){mpfr_set(v,a.v,near);}
    Real& operator=(const Real &a){mpfr_set(v,a.v,near);return *this;}
    ~Real(){mpfr_clear(v);}
};
struct Ball {Real lo,hi;};
Ball constant(unsigned long n){Ball a;mpfr_set_ui(a.lo.v,n,near);mpfr_set_ui(a.hi.v,n,near);return a;}
Ball pi(){Ball a;mpfr_const_pi(a.lo.v,down);mpfr_const_pi(a.hi.v,up);return a;}
Ball add(const Ball&a,const Ball&b){Ball t;mpfr_add(t.lo.v,a.lo.v,b.lo.v,down);mpfr_add(t.hi.v,a.hi.v,b.hi.v,up);return t;}
Ball sub(const Ball&a,const Ball&b){Ball t;mpfr_sub(t.lo.v,a.lo.v,b.hi.v,down);mpfr_sub(t.hi.v,a.hi.v,b.lo.v,up);return t;}
Ball shift(const Ball&a,long e){Ball t;mpfr_mul_2si(t.lo.v,a.lo.v,e,down);mpfr_mul_2si(t.hi.v,a.hi.v,e,up);return t;}
Ball scale(const Ball&a,unsigned long n){Ball t;mpfr_mul_ui(t.lo.v,a.lo.v,n,down);mpfr_mul_ui(t.hi.v,a.hi.v,n,up);return t;}
// The two functions below are used only on nonnegative operands.
Ball mul(const Ball&a,const Ball&b){Ball t;mpfr_mul(t.lo.v,a.lo.v,b.lo.v,down);mpfr_mul(t.hi.v,a.hi.v,b.hi.v,up);return t;}
Ball divide(const Ball&a,const Ball&b){Ball t;mpfr_div(t.lo.v,a.lo.v,b.hi.v,down);mpfr_div(t.hi.v,a.hi.v,b.lo.v,up);return t;}
Ball expB(const Ball&a){Ball t;mpfr_exp(t.lo.v,a.lo.v,down);mpfr_exp(t.hi.v,a.hi.v,up);return t;}
Ball expNeg(const Ball&a){Ball t;mpfr_neg(t.lo.v,a.hi.v,near);mpfr_neg(t.hi.v,a.lo.v,near);return expB(t);}
Ball dyadic(const Z& x,long e){Ball t;mpfr_set_z_2exp(t.lo.v,x.get_mpz_t(),e,down);mpfr_set_z_2exp(t.hi.v,x.get_mpz_t(),e,up);return t;}
Z fixed(const Real&a,long p){Real tmp;mpfr_mul_2si(tmp.v,a.v,p,near);Z v;mpfr_get_z(v.get_mpz_t(),tmp.v,MPFR_RNDD);return v;}
static unsigned long bitlog(unsigned long n){unsigned long k=0;while((1UL<<k)<n)++k;return k;}
struct ComplexZ {Z re,im;};
static ComplexZ product(const ComplexZ&a,const ComplexZ&b,long p){
    return {(a.re*b.re-a.im*b.im)>>p,(a.re*b.im+a.im*b.re)>>p};
}
static std::vector<Z> odd_weights(unsigned long N,long p){
    const Z one=Z(1)<<p;
    std::vector<ComplexZ> y(N);
    for(unsigned long k=1;k<N/2;k+=2){y[k].im=-(one/k);y[N-k].im=-y[k].im;}
    for(unsigned long i=1,j=0;i<N;++i){
        unsigned long bit=N>>1;
        for(;j&bit;bit>>=1)j^=bit;
        j^=bit;if(i<j)std::swap(y[i],y[j]);
    }
    Ball pib=pi();
    for(unsigned long len=2;len<=N;len*=2){
        const unsigned long half=len/2;
        ComplexZ root;
        if(len==2)root={-one,0};
        else if(len==4)root={0,one};
        else{
            Ball arg=shift(pib,1-long(bitlog(len)));
            Real c,s;
            mpfr_cos(c.v,arg.hi.v,down);mpfr_sin(s.v,arg.lo.v,down);
            root={fixed(c,p),fixed(s,p)};
        }
        std::vector<ComplexZ> powers(half);powers[0]={one,0};
        for(unsigned long k=1;k<half;++k)powers[k]=product(powers[k-1],root,p);
        #pragma omp parallel for schedule(static)
        for(unsigned long j=0;j<N;j+=len)for(unsigned long k=0;k<half;++k){
            ComplexZ u=y[j+k],v=product(y[j+k+half],powers[k],p);
            y[j+k]={u.re+v.re,u.im+v.im};y[j+k+half]={u.re-v.re,u.im-v.im};
        }
    }
    const Z multiplier=fixed(divide(constant(2),pib).lo,p);
    std::vector<Z> weights(N/2);
    for(unsigned long j=0;j<N/2;++j) weights[j]=(y[j].re*multiplier)>>p;
    return weights;
}
// Range of the positive full theta kernel, including a geometric tail.
static Ball theta(const Ball& eu,const Ball& x,long p){
    const Ball q=expNeg(x),q2=mul(q,q); Ball power=q,step=mul(q2,q),sum=constant(0);
    for(unsigned long j=1;;++j){
        Ball v=scale(x,j*j);
        sum=add(sum,mul(mul(v,sub(scale(v,2),constant(3))),power));
        power=mul(power,step);step=mul(step,q2);
        Real bound;
        mpfr_set_ui_2exp(bound.v,1,-2*p-40,near);
        if(mpfr_cmp(power.hi.v,bound.v)<0){
            // If exp(-x*(j+1)^2)<2^(-2p-40), the omitted sum is <2^-p:
            // (2v^2+3v)exp(-v/2)<100 and successive v differ by at least pi.
            sum.hi=add(sum,shift(constant(1),-p)).hi;break;
        }
    }
    return mul(eu,sum);
}
static std::vector<Z> moments(unsigned long R,unsigned long N,unsigned long L,long p){
    auto weights=odd_weights(N,p);
    std::cout<<"weights done"<<std::endl;
    const unsigned long count=2*R-1;const int threads=omp_get_max_threads();
    std::vector<std::vector<Z>> accum(threads,std::vector<Z>(count));
    const Ball pib=pi();const long logN=bitlog(N);
    const unsigned long den=N/(2*L); // L*u_j=3*j/den.
    assert(den>0 && N%(2*L)==0);
    if((long double)den*den*count*(count+1)>1.8e19L)throw std::runtime_error("denominator overflow");
    #pragma omp parallel for schedule(dynamic,32)
    for(unsigned long j=0;j<N/2;++j){
        Ball u=shift(constant(6*j),-logN);
        const Ball eu=expB(u),squared=mul(eu,eu),x=mul(pib,mul(squared,squared));
        // Common absolute error for the raw sample, before moment powers.
        const Ball mass=shift(scale(theta(eu,x,p),6),-logN);
        if (!mpfr_number_p(mass.lo.v) || !mpfr_number_p(mass.hi.v))
            std::abort();
        Z e=fixed(mass.lo,p);
        if (e<0 || fixed(mass.hi,p)+1-e>1024)
            std::abort();
        if(j==0){accum[omp_get_thread_num()][0]+=e>>1;continue;}
        if(e==0)continue;
        const unsigned long num=3*j, num2=num*num;
        Z o=((e*weights[j])>>p)*num/den;
        auto &a=accum[omp_get_thread_num()];
        for(unsigned long k=0;k<count;k+=2){
            a[k]+=e;
            if(k+1<count)a[k+1]+=o;
            if(k+2<count){
                mpz_mul_ui(e.get_mpz_t(),e.get_mpz_t(),num2);
                mpz_fdiv_q_ui(e.get_mpz_t(),e.get_mpz_t(),den*den*(k+1)*(k+2));
            }
            if(k+3<count){
                mpz_mul_ui(o.get_mpz_t(),o.get_mpz_t(),num2);
                mpz_fdiv_q_ui(o.get_mpz_t(),o.get_mpz_t(),den*den*(k+2)*(k+3));
            }
        }
    }
    for(int j=1;j<threads;++j)for(unsigned long k=0;k<count;++k)accum[0][k]+=accum[j][k];
    return std::move(accum[0]);
}
static Ball radius(unsigned long N,unsigned long L,long p){
    const Ball growth=expB(shift(constant(13*L),-2));
    Ball alias=mul(scale(growth,1000000000UL),expNeg(divide(scale(pi(),N),constant(24))));
    // Spatial periodisation beyond |u|=3. X=pi exp(12)>500000.
    Ball spatial=mul(scale(growth,1000000000UL),expNeg(constant(60000)));
    // All pointwise roundoff (including fixed-point FFT and moment recurrences).
    Ball numeric=mul(growth,shift(constant(1),-p+12*long(bitlog(N))+40));
    return add(add(alias,spatial),numeric);
}
// State for the shifts s=-1 and s=-2. Both denominators are ordinary
// nonnegative-shift minors, independent of the signs computed here.
static Ball generalMul(const Ball &a,const Ball &b) {
    if (mpfr_cmp_ui(a.lo.v,0)>=0 && mpfr_cmp_ui(b.lo.v,0)>=0) return mul(a,b);
    Ball result;
    bool first=true;
    for (auto x:{&a.lo,&a.hi}) for (auto y:{&b.lo,&b.hi}) {
        Real l,h;
        mpfr_mul(l.v,x->v,y->v,down);mpfr_mul(h.v,x->v,y->v,up);
        if(first || mpfr_cmp(l.v,result.lo.v)<0) result.lo=l;
        if(first || mpfr_cmp(h.v,result.hi.v)>0) result.hi=h;
        first=false;
    }
    return result;
}
static Ball byPositive(const Ball &a,const Ball &b) {
    if(mpfr_cmp_ui(b.lo.v,0)<=0) throw std::runtime_error("nonpositive denominator");
    Ball t;
    mpfr_div(t.lo.v,a.lo.v,mpfr_cmp_ui(a.lo.v,0)<0?b.lo.v:b.hi.v,down);
    mpfr_div(t.hi.v,a.hi.v,mpfr_cmp_ui(a.hi.v,0)<0?b.hi.v:b.lo.v,up);
    if(!mpfr_number_p(t.lo.v)||!mpfr_number_p(t.hi.v))
        throw std::runtime_error("nonfinite border");
    return t;
}
static void verify(const std::vector<Z>&m,unsigned long R,unsigned long N,unsigned long L,long p){
    const Ball err=radius(N,L,p);Real lg;mpfr_log10(lg.v,err.hi.v,up);
    std::cout<<"absolute moment radius log10 <= "<<mpfr_get_d(lg.v,up)<<std::endl;
    Ball sym; sym.hi=err.hi;mpfr_neg(sym.lo.v,err.hi.v,near);
    std::vector<Ball> cur;cur.reserve(m.size());
    for(auto& z:m){cur.push_back(add(dyadic(z,-p),sym));if(!mpfr_number_p(cur.back().hi.v)||mpfr_cmp_ui(cur.back().lo.v,0)<=0)throw std::runtime_error("moment enclosure crosses zero");}
    const Ball m0=cur[0];
    // b_s=L^s a_s, including a_(-1)=Phi(0) and a_(-2)=-Phi'(0)=0.
    const Ball phi0=theta(constant(1),pi(),p);
    Ball minusOne=divide(phi0,constant(L)),minusTwo=constant(0);
    unsigned long passOne=1,passTwo=0,neverOne=0,neverTwo=0;
    std::vector<Ball> prev(m.size()+2,constant(1));
    for(unsigned long k=2;k<=R;++k){
        std::vector<Ball> next(cur.size()-2);
        int fail=0;
        #pragma omp parallel for reduction(|:fail) schedule(static)
        for(unsigned long j=0;j<next.size();++j){
            Ball diff=sub(mul(cur[j+1],cur[j+1]),mul(cur[j],cur[j+2]));
            if(mpfr_cmp_ui(diff.lo.v,0)<=0){fail=1;continue;}
            next[j]=divide(diff,prev[j+2]);
            if (!mpfr_number_p(next[j].hi.v) || mpfr_cmp_ui(next[j].lo.v,0)<=0) fail=1;
        }
        if(fail)throw std::runtime_error("first unresolved condensation layer "+std::to_string(k));
        if((k==R)||(k>=16&&(k&(k-1))==0)){
            Ball ratio=divide(next[0],mul(cur[2],m0));Real a,b;
            mpfr_log10(a.v,ratio.lo.v,down);mpfr_log10(b.v,ratio.hi.v,up);
            std::printf("p=%lu log10(signed relative pivot) in (%.9f, %.9f)\n",k,
              std::floor(mpfr_get_d(a.v,down)*1e8)/1e8-1e-8,std::ceil(mpfr_get_d(b.v,up)*1e8)/1e8+1e-8);std::fflush(stdout);
        }
        const Ball newOne=byPositive(sub(mul(cur[0],cur[0]),generalMul(minusOne,cur[1])),prev[1]);
        const Ball newTwo=byPositive(sub(generalMul(minusOne,minusOne),generalMul(minusTwo,cur[0])),prev[0]);
        if(mpfr_cmp_ui(newOne.lo.v,0)>0) ++passOne;
        else if(!neverOne) neverOne=k;
        if(mpfr_cmp_ui(newTwo.lo.v,0)>0) ++passTwo;
        else if(!neverTwo) neverTwo=k;
        minusOne=newOne;minusTwo=newTwo;
        cur.swap(next);prev.swap(next);
    }
    std::cout<<"PASS "<<R*R<<" nonnegative-shift minors"<<std::endl;
    std::cout<<"s=-1 positive ranks 1..R: "<<passOne<<"/"<<R
             <<", first unresolved or nonpositive rank (0=none): "<<neverOne<<"\n";
    std::cout<<"s=-2 positive ranks 2..R: "<<passTwo<<"/"<<R-1
             <<", first unresolved or nonpositive rank (0=none): "<<neverTwo<<std::endl;
}
#ifndef NUTTALL_NO_ENDPOINT_MAIN
int main(int argc,char**argv){
    if(argc!=5){std::cerr<<"usage: endpoint R grid_N scale_L bits\n";return 2;}
    unsigned long R=std::stoul(argv[1]),N=std::stoul(argv[2]),L=std::stoul(argv[3]);long p=std::stol(argv[4]);
    if(R<2||R>8000||L<1||L>8000||N<32||N>(1UL<<22)||(N&(N-1))||p<128||p<15*long(bitlog(N))+80||N%(2*L)!=0)
        throw std::invalid_argument("parameters outside the proved range");
    precision=p+128;std::cout<<"R="<<R<<" N="<<N<<" L="<<L<<" bits="<<p<<" threads="<<omp_get_max_threads()<<std::endl;
    auto m=moments(R,N,L,p);std::cout<<"moments done"<<std::endl;
    verify(m,R,N,L,p);
}

#endif
