# Kwadratura bazowa dla punktu zero

## Błąd kwadratury

Niech \(N=2^h\), \(u_j=6j/N\). Bierzemy periodyzację \(F_s(x)=\sum_{k\in\mathbb Z}f_s(x+6k)\), interpolujemy ją trygonometrycznie na całym okresie i całkujemy interpolant na połowie okresu \([0,3]\). Przy węzłach rzeczywistych wykorzystujemy parzystość lub nieparzystość \(f_s\). Po zastąpieniu periodyzowanych wartości fizycznymi i pominięciu węzła 3 waga wewnętrznego węzła dodatniego wynosi \(6/N\) dla parzystego \(s\), a dla nieparzystego wynosi \((6/N)w_j\), gdzie
\[
 w_j=\frac4\pi\sum_{1\le k<N/2,\ k\ {\rm nieparzyste}}\frac{\sin(2\pi k j/N)}k.
\]
Węzeł zerowy przy parzystym rzędzie ma połowę zwykłej wagi. Wzór wynika z dyskretnej ortogonalności sinusów i cosinusów. Całka modu cosinusowego o częstości Nyquista na połowie okresu jest zerowa.

W pasie \(|\Im z|\le1/4\) mamy \(\Re(\pi n^2e^{4z})\ge v/2\), gdzie \(v=\pi n^2e^{4\Re z}\). Dla \(0\le x=\Re z\le3\) zachodzi \(|\Phi(z)|\le10^4\), bo \((2v^2+3v)e^{-v/4}<100\) oraz \(\sum_{n\ge1}e^{-\pi n^2/4}<2\). Dla \(x\ge3\) otrzymujemy \(|\Phi(z)|\le1000 e^x\exp(-\pi e^{4x}/8)\) przez ponowne wydzielenie połowy wykładnika. Lewą stronę osi kontroluje analityczna tożsamość \(\Phi(-z)=\Phi(z)\), wynikająca z transformacji Jacobiego funkcji theta. Dla potęgi podzielonej przez silnię wystarcza \(|Lz|^s/s!\le e^{L(|x|+1/4)}\). Przy \(L\le 8000\) wykładnik \((L+1)x-\pi e^{4x}/8\) na \(x\ge3\) ma pochodną mniejszą od \(-200000\), a \(\pi e^{12}/8>63900\). Na obu brzegach pasa dostajemy więc
\[
 \int_{\mathbb R}|f_s(x\pm i/4)|dx\le10^6 e^{13L/4}.
\]
Przesunięcie konturu Fouriera o \(1/4\) daje dla modu \(k\) granicę \((10^6/6)e^{13L/4}e^{-\pi |k|/12}\). Każdy mod poza zakresem siatki i jego reprezentant na siatce mają moduł co najwyżej 1. Błąd interpolacji w normie supremum ogranicza zatem podwójna suma modułów współczynników od \(|k|\ge N/2\), także dla symetrycznej konwencji Nyquista. Po scałkowaniu na przedziale długości 3 dostajemy \(10^9 e^{13L/4-\pi N/24}\). Suma przesuniętych kopii obcych w węzłach i odrzucone ogony całkowe mieszczą się łącznie w \(10^9e^{13L/4-60000}\). W szczególności moduł obcej kopii oddalonej o \(x\ge3\) ogranicza \(1000e^{3+13L/4-63900-200000(x-3)}\), kopie są od siebie oddalone o 6, a \(|w_j|\le 2(1+\log N)\) oraz \(h\le22\). Te same granice obejmują pominięty węzeł 3.

## Błąd arytmetyczny

W programie \(P\) oznacza liczbę bitów stałoprzecinkowych, \(\delta=2^{-P}\). Przedziały dla funkcji wykładniczej, \(\pi\), sumy theta i rekurencji wyznacznikowej liczone są z zaokrągleniem skierowanym w MPFR przy \(P+128\) bitach. Wagi \(w_j\) powstają w arytmetyce dyadycznej przez FFT z dodatnim znakiem wykładnika, z wejściem \(-i/k\) i jego sprzężeniem dla nieparzystych \(k<N/2\), następnie pomnożonym przez \(2/\pi\).

Moduł błędu każdego przybliżenia pierwiastka z jedności na danym etapie jest co najwyżej \(4\delta\). Wynika to z Lipschitzowskości sinusa i cosinusa, dodatkowych 128 bitów i zaokrąglenia na siatkę. Błąd obcięcia pojedynczego iloczynu zespolonego jest co najwyżej \(2\delta\). Kolejne potęgi do \(N/2\) mają błąd najwyżej \(10N\delta\), przez sumę ciągu geometrycznego o ilorazie \(1+4\delta\). Dokładne wartości pośrednie FFT mają moduł najwyżej \(N\). Jeśli błąd na etapie wynosi \(E\), to po następnym jest co najwyżej \((2+10N\delta)E+10N^2\delta+2\delta\). Ponieważ \(P\ge15h+80\), po \(h\) etapach błąd gotowych wag, wraz z mnożnikiem \(2/\pi\), wynosi co najwyżej \(40N^3\delta\).

W szeregu theta kolejne potęgi oblicza się jako przedziały dla \(e^{-xj^2}\). Jeżeli pierwsza pominięta potęga jest mniejsza od \(2^{-2P-40}\), ogon przed czynnikiem \(e^u\) jest mniejszy od \(2^{-P}\). Istotnie \((2v^2+3v)e^{-v/2}<100\), a pozostałe połówki wykładników tworzą szereg ograniczony geometrycznie z ilorazem \(e^{-\pi/2}\). Program sprawdza osobno dla każdego węzła, że siatkowa wartość masy \((6/N)\Phi(u_j)\) różni się od prawdziwej najwyżej o \(1024\delta\). Zatrzymanie przy wartości siatkowej zero również mieści się w tej granicy.

Węzły są wymierne, a mnożniki \(Lu_j/(k+1)\) lub ich dwukrokowe iloczyny obliczane są jako ilorazy całkowite. Przy przejściu o dwa indeksy każde obcięcie wnosi co najwyżej \(\delta\) błędu. Błąd z poziomu \(k\) na poziomie \(k+\ell\) mnoży się co najwyżej przez \((3L)^\ell/\ell!\); suma tych mnożników jest co najwyżej \(e^{3L}\). Początkowy błąd na jednym węźle, przed mnożeniem przez potęgi, jest co najwyżej \((1024\cdot 2(1+\log N)+(6/N)10^4\cdot40N^3+10)\delta\). W pierwszym nieparzystym kroku zarówno podłoga przed mnożeniem przez \(Lu_j\), jak i podział całkowity po nim wnoszą dodatkowy błąd najwyżej odpowiednio \(\delta\) przed mnożeniem i \(\delta\) po nim. Suma po wszystkich węzłach, także z połówkową wagą w zerze, mieści się w \(e^{13L/4}\,2^{-P+12h+40}\). W użytych obliczeniach \(2R-1<N\). Wspólny bezwzględny promień momentów przekazany do arytmetyki przedziałowej jest więc
\[
 E=e^{13L/4}\left(10^9e^{-\pi N/24}+10^9e^{-60000}+2^{-P+12h+40}\right).
\]
W biegu dla \(R=2048\) zachodzi \(E<10^{-4652}\). Porównanie znaków wykorzystuje pełny przedział, a nie wydrukowaną wartość przybliżoną.

