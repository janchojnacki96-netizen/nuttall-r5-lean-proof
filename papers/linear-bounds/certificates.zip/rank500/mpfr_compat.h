#pragma once
#include <gmp.h>
#if __has_include(<mpfr.h>)
#include <mpfr.h>
#else
// MPFR 4.x public C ABI on GNU/Linux LP64, for hosts with the runtime only.
extern "C" {
typedef long mpfr_prec_t;
typedef long mpfr_exp_t;
typedef enum {MPFR_RNDN=0,MPFR_RNDZ,MPFR_RNDU,MPFR_RNDD,MPFR_RNDA} mpfr_rnd_t;
typedef struct {mpfr_prec_t prec; int sign; mpfr_exp_t exp; mp_limb_t *d;} __mpfr_struct;
typedef __mpfr_struct mpfr_t[1];
typedef __mpfr_struct *mpfr_ptr;
typedef const __mpfr_struct *mpfr_srcptr;
void mpfr_init2(mpfr_ptr,mpfr_prec_t); void mpfr_clear(mpfr_ptr);
int mpfr_set(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_set_z(mpfr_ptr,mpz_srcptr,mpfr_rnd_t);
int mpfr_set_z_2exp(mpfr_ptr,mpz_srcptr,mpfr_exp_t,mpfr_rnd_t);
int mpfr_set_ui(mpfr_ptr,unsigned long,mpfr_rnd_t);
int mpfr_set_si(mpfr_ptr,long,mpfr_rnd_t);
int mpfr_set_ui_2exp(mpfr_ptr,unsigned long,mpfr_exp_t,mpfr_rnd_t);
int mpfr_get_z(mpz_ptr,mpfr_srcptr,mpfr_rnd_t);
double mpfr_get_d(mpfr_srcptr,mpfr_rnd_t);
int mpfr_const_pi(mpfr_ptr,mpfr_rnd_t);
int mpfr_cmp(mpfr_srcptr,mpfr_srcptr);
int mpfr_number_p(mpfr_srcptr);
int mpfr_cmp_ui(mpfr_srcptr,unsigned long);
int mpfr_neg(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_add(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_sub(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_mul(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_div(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_mul_ui(mpfr_ptr,mpfr_srcptr,unsigned long,mpfr_rnd_t);
int mpfr_mul_2si(mpfr_ptr,mpfr_srcptr,long,mpfr_rnd_t);
int mpfr_exp(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_log10(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_sin(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_cos(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
}
#endif
