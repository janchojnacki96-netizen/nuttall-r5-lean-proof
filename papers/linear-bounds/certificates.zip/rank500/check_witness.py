"""Verify the order-142 or order-500 witness from fresh moments or validate a saved transcript."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile


PARAMETERS = {
    142: (196, 197, 0, 1, 32768, 256, 5000),
    500: (767, 768, 15, 8192, 131072, 256, 9000),
}


def validate(transcript, rank):
    low, high, numerator, denominator, nodes, scale, bits = PARAMETERS[rank]
    header = f'r={rank} m={low}..{high} t={numerator}/{denominator} N={nodes} L={scale} bits={bits}'
    lines = transcript.splitlines()
    results = lines[1:]
    if rank == 142 and results[:1] == ['weights done']:
        results = results[1:]
    if not lines or lines[0] != header or sorted(results) != [f'm {low} result {rank}', f'm {high} result 0']:
        raise ValueError("unexpected parameters, missing result, or incorrect witness")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rank', type=int, choices=PARAMETERS, default=500)
    source = parser.add_mutually_exclusive_group()
    source.add_argument('--log', type=Path)
    source.add_argument('--binary', type=Path, default=Path(__file__).with_name('certify'))
    args = parser.parse_args()
    if args.log:
        transcript = args.log.read_text()
    else:
        with tempfile.TemporaryDirectory() as work:
            environment = os.environ.copy()
            environment.setdefault('OMP_NUM_THREADS', '4')
            run = subprocess.run([str(args.binary.resolve()), str(args.rank), *map(str, PARAMETERS[args.rank])], cwd=work,
                                 env=environment, check=True, stdout=subprocess.PIPE, text=True)
            transcript = run.stdout
    validate(transcript, args.rank)
    sys.stdout.write(transcript)
    if args.log:
        print("PASS: saved witness transcript matches the specified parameters and results.")
    else:
        print("PASS: regenerated both pointwise witness results at the specified parameters.")


if __name__ == '__main__':
    main()
