# Analityczne pokrycie końca półosi

Dla r=142 i r=500 oraz $X=\pi e^{4t}\ge r+2$ wszystkie podpisane wrońskiany rzędów $1\le p\le r$ mają właściwy ścisły znak już na poziomie $m=0$. Własność utrzymuje się po całkowaniach ogonowych. Poniższa ocena wzmacnia stałą z wcześniejszej noty o końcu półosi; nie wymaga RH ani roboczej granicy $m(r)\le2r$.

W jądrze $\Phi(t+s+h)$ zmieniamy współrzędne na $u=\sqrt X(e^{4s}-1)$ i $v=\sqrt X(e^{4h}-1)$. Po usunięciu dodatnich w zerze czynników jednej zmiennej oraz wspólnej dodatniej stałej otrzymujemy sumę po $q=n^2$, $d=q-1$,
\[
q\,[2qX(1+u/\sqrt X)(1+v/\sqrt X)-3]\,g_q(u,v),
\qquad
g_q=e^{-dX-d\sqrt X(u+v)-quv}.
\]
Istotnie czynniki usunięte to $Xe^t e^{s+h}(1+u/\sqrt X)(1+v/\sqrt X)e^{-X-\sqrt X(u+v)}$. Zmiana zmiennej oraz mnożenie przez funkcję jednej zmiennej działają trójkątnie, z dodatnimi przekątnymi. Znak wrońskianu zgadza się ze znakiem wyznacznika początkowego bloku współczynników w bazie $u^i/\sqrt{i!}$ po obu stronach. Niech $S_{i,i-1}=\sqrt i$ będzie przesunięciem w bloku $p\times p$, $P=1+S/\sqrt X$ i $J=\mathrm{diag}((-1)^i)$. Niech $G_q$ będzie blokiem współczynników $g_q$. Mnożenie przez $1+u/\sqrt X$ zachowuje początkowy blok podczas obcinania. Macierz składnika ma więc postać $B_n=q(2qX PG_qP^\top-3G_q)$. Dla $q=1$ mamy $G_1=J$, a część symetryczna $B_1J$ to $(2X-3)I-2SS^\top$. Jej najmniejsza wartość własna wynosi $2X-2p-1$.

Dla $q\ge4$ i $\rho=9/(10q)$ wprowadźmy niezależne standardowe zespolone zmienne gaussowskie $U,V$ o gęstości $\pi^{-1}e^{-|u|^2}$. Ortogonalność jednomianów daje
\[
\|G_q\|^2\le \rho^{-2(p-1)}\mathbb E|g_q(\sqrt\rho U,\sqrt\rho V)|^2
=\frac{\rho^{-2(p-1)}}{1-q^2\rho^2}
  \exp\!\left(-2dX+\frac{2d^2 X\rho}{1+q\rho}\right).
\]
Pierwsza nierówność przechodzi przez kwadrat normy Frobeniusa bloku. Dla uzasadnienia sumowania można najpierw uśrednić po kątach na dwóch okręgach (Parseval), a następnie użyć Tonellego dla sumy nieujemnej po promieniach. W ostatniej równości dwie rzeczywiste współrzędne mają w wykładniku formę $x^2+2q\rho xz+z^2$ i wyraz liniowy $-2d\sqrt{X\rho}(x+z)$; dla urojonych znak wyrazu mieszanego jest odwrotny, bez części liniowej. Domknięcie kwadratów daje wzór.

Ponieważ $\rho/(1+q\rho)<1/(2q)$, przy $X\ge r$ otrzymujemy $\|G_q\|\le3e^{-qX/12}$. Użyto
\[
 (q-q^{-1})/2-\log(10q/9)>q/12\quad(q\ge4),
\]
co wynika przez sprawdzenie $q=4$ i dodatniość pochodnej różnicy. Mamy $\|P\|\le2$. Dla naszego zakresu daje to $\sum_{n\ge2}\|B_n\|\le 27X\sum_{n\ge2} n^4 e^{-n^2X/12}$. Przy $X\ge144$ jest to poniżej 1: każdy wyraz po uwzględnieniu czynnika $X$ maleje w $X$, a dla $X=144$ pierwszy wynosi $27\cdot144\cdot16e^{-48}$ i iloraz następnych nie przekracza $(3/2)^4e^{-60}$. Przy $X\ge r+2$ margines pierwszego składnika wynosi co najmniej 3. Część symetryczna pełnej sumy po pomnożeniu przez $J$ jest dodatnio określona i jej macierz ma dodatni wyznacznik (odcinek do identyczności składa się z macierzy odwracalnych). Ponieważ $\det J=(-1)^{p(p-1)/2}$, dostajemy właściwy znak.

Przejście z $g$ do $f(t)=\int_t^\infty g(s)ds$ zachowuje tu ścisłe znaki na przedziale $[T,\infty)$. Pierwszy wiersz wrońskianu dla $f$ jest całką z wiersza $(g(s),\dots,g^{(p-1)}(s))$, a pozostałe to ujemne wiersze kolejnych pochodnych $g$ w $t$. Przesunięcie pierwszego wiersza na koniec usuwa ich znaki minus. Wewnątrz całki stoi wyznacznik z węzłem $t$ o krotności $p-1$ i węzłem $s>t$. Niezerowość kolejnych początkowych wrońskianów $g,\dots,g^{(p-1)}$ daje rozszerzony układ Czebyszewa na przedziale (rekurencyjne dzielenie przez pierwszą funkcję i twierdzenie Rolle'a z krotnościami). Wyznacznik nie znika dla $s>t$, a jego znak przy $s\downarrow t$ jest znakiem wrońskianu rzędu $p$. Po scałkowaniu znak jest więc nadal ścisły. Powtarzamy dla dowolnej liczby całkowań.
