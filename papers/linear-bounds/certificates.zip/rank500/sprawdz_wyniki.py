"""Check coverage and summarize the bundled numerical and interval-verification logs."""
from fractions import Fraction
from pathlib import Path

base = Path(__file__).resolve().parent
points = set()
for name, first_level, last_level, last_index, denominator in [
    ("dense500.log", 766, 771, 679, 512),
    ("fine500a.log", 730, 810, 40, 1024),
    ("detail500.log", 764, 775, 48, 8192),
    ("valid142.log", 195, 198, 126, 128),
]:
    rows = [list(map(int, line.split())) for line in (base / name).read_text().splitlines()]
    assert sorted(row[0] for row in rows) == list(range(last_index + 1)), name
    assert all(len(row) == last_level - first_level + 2 for row in rows)
    level = 197 if name == "valid142.log" else 768
    assert all(row[1 + level - first_level] == 0 for row in rows), name
    failures = sorted((row[0], row[level - first_level]) for row in rows if row[level - first_level])
    print(f"{name}: {len(rows)} points pass at m={level}; failures at m={level-1}: {failures}")
    if level == 768:
        points.update(Fraction(row[0], denominator) for row in rows)
for name, expected in [
    ("witness500.log", {767: 500, 768: 0}),
    ("replay_witness.log", {767: 500, 768: 0}),
    ("certzero768.log", {768: 0}),
    ("cert_high.log", {768: 0}),
    ("cert142.log", {196: 142, 197: 0}),
]:
    results = [line.split() for line in (base / name).read_text().splitlines() if line.startswith("m ")]
    assert {int(row[1]): int(row[3]) for row in results} == expected, name
print(f"Distinct r=500 points: {len(points)}. Expected interval results confirmed.")
