#pragma once
extern "C" long mpfr_get_exp(mpfr_srcptr);
static size_t bitlen(const Z&x){return mpz_sizeinbase(x.get_mpz_t(),2);}
static Z pack(const std::vector<Z>&a,size_t stride,bool flip=false){
    std::vector<unsigned long> pos(stride*a.size()),neg(pos.size());
    for(size_t i=0;i<a.size();i++){
        size_t count;auto &v=a[i]>=0?pos:neg;
        size_t j=flip?a.size()-1-i:i;
        mpz_export(v.data()+j*stride,&count,-1,sizeof(unsigned long),0,0,a[i].get_mpz_t());
        if(count>stride)std::abort();
    }
    Z x,y;mpz_import(x.get_mpz_t(),pos.size(),-1,sizeof(unsigned long),0,0,pos.data());
    mpz_import(y.get_mpz_t(),neg.size(),-1,sizeof(unsigned long),0,0,neg.data());return x-y;
}
